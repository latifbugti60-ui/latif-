import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Latif AI — ElevenLabs Personal Voice Synthesis & Red/Black Neural Studio",
  description:
    "Full-stack personal AI voice generation, voice cloning from your own samples, and an animated Red & Black neural studio powered by Latif AI & ElevenLabs.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        {/* Fonts load in the browser (no build-time download); system fonts are the fallback. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap"
        />
      </head>
      <body className="bg-[#080505] text-[#FFF1F1] antialiased selection:bg-[#B91C1C]/35 selection:text-white">
        {children}
      </body>
    </html>
  );
}
