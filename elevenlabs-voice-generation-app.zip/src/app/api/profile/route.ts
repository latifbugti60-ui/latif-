import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { asc, eq } from "drizzle-orm";

const MAX_AVATAR_CHARS = 3_000_000; // ~2.2 MB of base64
const AVATAR_PATTERN = /^data:image\/(png|jpe?g|webp);base64,[A-Za-z0-9+/=]+$/;

export async function GET() {
  try {
    await ensureSeeded();
    const [user] = await db
      .select({
        name: users.name,
        email: users.email,
        avatarData: users.avatarData,
      })
      .from(users)
      .orderBy(asc(users.id))
      .limit(1);

    return NextResponse.json({
      name: user?.name ?? "Latif Bugti",
      email: user?.email ?? "",
      avatarData: user?.avatarData ?? null,
    });
  } catch (error) {
    console.error("GET /api/profile error:", error);
    return NextResponse.json(
      { error: "Failed to load profile" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const avatarData: string | null =
      typeof body.avatarData === "string" ? body.avatarData : null;

    if (avatarData !== null) {
      if (avatarData.length > MAX_AVATAR_CHARS) {
        return NextResponse.json(
          { error: "Photo is too large. Please choose a smaller image." },
          { status: 413 }
        );
      }
      if (!AVATAR_PATTERN.test(avatarData)) {
        return NextResponse.json(
          { error: "Only PNG, JPEG or WebP images are supported." },
          { status: 400 }
        );
      }
    }

    const [user] = await db
      .select({ id: users.id })
      .from(users)
      .orderBy(asc(users.id))
      .limit(1);
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    await db
      .update(users)
      .set({ avatarData })
      .where(eq(users.id, user.id));

    return NextResponse.json({ avatarData });
  } catch (error) {
    console.error("PUT /api/profile error:", error);
    return NextResponse.json(
      { error: "Failed to save photo" },
      { status: 500 }
    );
  }
}
