import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, voices } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { asc } from "drizzle-orm";
import { publicVoiceColumns } from "@/lib/voice-columns";
import {
  cloneVoiceOnElevenLabs,
  type StoredSample,
} from "@/lib/elevenlabs-clone";
import {
  generateSilentPlaceholderWav,
  synthesizeVoiceAudio,
} from "@/lib/audio-engine";

export const maxDuration = 120;

const MAX_FILES = 3;
const MAX_FILE_BYTES = 12 * 1024 * 1024;

function num(value: FormDataEntryValue | null, fallback: number): number {
  const n = Number(value);
  return value !== null && value !== "" && Number.isFinite(n) ? n : fallback;
}

function str(value: FormDataEntryValue | null, fallback: string): string {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const form = await request.formData();

    const name = str(form.get("name"), "");
    if (!name) {
      return NextResponse.json(
        { error: "Voice name is required" },
        { status: 400 }
      );
    }

    const files = form
      .getAll("samples")
      .filter((f): f is File => typeof f !== "string" && f.size > 0)
      .slice(0, MAX_FILES);

    if (files.length === 0) {
      return NextResponse.json(
        { error: "Upload or record at least one voice sample to clone." },
        { status: 400 }
      );
    }

    const samples: StoredSample[] = [];
    for (const file of files) {
      if (file.size > MAX_FILE_BYTES) {
        return NextResponse.json(
          { error: `"${file.name}" is larger than 12 MB.` },
          { status: 413 }
        );
      }
      const buf = Buffer.from(await file.arrayBuffer());
      samples.push({
        name: file.name || "sample.wav",
        mime: file.type || "audio/wav",
        data: buf.toString("base64"),
      });
    }

    const gender = str(form.get("gender"), "Male");
    const pitchShift = num(form.get("pitchShift"), 1.0);
    const measuredPitchHz = num(form.get("measuredPitchHz"), 0) || null;
    const stability = num(form.get("defaultStability"), 0.55);
    const similarity = num(form.get("defaultSimilarity"), 0.86);
    const style = num(form.get("defaultStyle"), 0.2);
    const description = str(
      form.get("description"),
      "Personal voice clone created from my own uploaded voice samples."
    );
    const previewScript = str(
      form.get("sampleScript"),
      `Hello, I am ${name}. This is my cloned voice speaking.`
    );

    const [activeUser] = await db
      .select()
      .from(users)
      .orderBy(asc(users.id))
      .limit(1);
    const apiKey = (
      activeUser?.elevenlabsApiKey ||
      process.env.ELEVENLABS_API_KEY ||
      ""
    ).trim();

    let cloneStatus: "elevenlabs_cloned" | "local_profile" = "local_profile";
    let elevenlabsVoiceId = "pNInz6obpgDQGcFmaJgB"; // stock placeholder, only used if not cloned
    let message: string;

    if (apiKey.length > 10) {
      const result = await cloneVoiceOnElevenLabs({
        apiKey,
        name,
        description,
        samples,
      });
      if (result.ok) {
        cloneStatus = "elevenlabs_cloned";
        elevenlabsVoiceId = result.voiceId;
        message =
          "Real voice clone created on ElevenLabs! Every take you generate with this voice now speaks in YOUR cloned voice.";
      } else {
        message = `ElevenLabs could not clone this voice (${result.message}). Saved as a local pitch-matched profile instead — instant voice cloning requires a paid ElevenLabs plan. Fix the key/plan, then press "Upgrade to real clone".`;
      }
    } else {
      message =
        "Sample saved as a local pitch-matched profile. A TRUE clone needs your ElevenLabs API key — add it in ElevenLabs API & Setup, then press 'Upgrade to real clone' on this voice.";
    }

    // Preview: real cloned-voice MP3 if cloning worked, otherwise local WAV.
    let previewAudioUrl: string;
    if (cloneStatus === "elevenlabs_cloned") {
      const preview = await synthesizeVoiceAudio({
        text: previewScript,
        elevenlabsVoiceId,
        gender,
        pitchShift,
        modelId: "eleven_multilingual_v2",
        stability,
        similarityBoost: similarity,
        styleExaggeration: style,
        speakerBoost: true,
        apiKey,
        baseF0Hz: measuredPitchHz,
      });
      previewAudioUrl = preview.audioData;
    } else {
      previewAudioUrl = generateSilentPlaceholderWav({
        text: previewScript,
        gender,
        pitchShift,
        stability,
        style,
        baseF0Hz: measuredPitchHz,
      }).audioData;
    }

    const [created] = await db
      .insert(voices)
      .values({
        name,
        elevenlabsVoiceId,
        category: "cloned",
        accent: str(form.get("accent"), "Urdu / International English"),
        gender,
        age: str(form.get("age"), "Young"),
        description,
        useCase: str(form.get("useCase"), "Personal Voice Clone"),
        previewAudioUrl,
        defaultStability: stability,
        defaultSimilarity: similarity,
        defaultStyle: style,
        speakerBoost: form.get("speakerBoost") !== "false",
        pitchShift,
        isFavorite: true,
        sampleCount: samples.length,
        qualityScore: cloneStatus === "elevenlabs_cloned" ? 99 : 80,
        cloneStatus,
        measuredPitchHz,
        sampleFiles: JSON.stringify(samples),
      })
      .returning(publicVoiceColumns);

    return NextResponse.json(
      { voice: created, cloneStatus, message },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/voices/clone error:", error);
    return NextResponse.json(
      { error: "Failed to clone voice" },
      { status: 500 }
    );
  }
}
