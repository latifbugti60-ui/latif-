import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voices } from "@/db/schema";
import { eq } from "drizzle-orm";
import { publicVoiceColumns } from "@/lib/voice-columns";

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const voiceId = Number(id);
    if (!voiceId) {
      return NextResponse.json({ error: "Invalid voice ID" }, { status: 400 });
    }

    const body = await request.json();
    const updateData: Partial<typeof voices.$inferInsert> = {};

    if (body.name !== undefined) updateData.name = String(body.name).trim();
    if (body.elevenlabsVoiceId !== undefined)
      updateData.elevenlabsVoiceId = String(body.elevenlabsVoiceId).trim();
    if (body.category !== undefined) updateData.category = body.category;
    if (body.accent !== undefined)
      updateData.accent = String(body.accent).trim();
    if (body.gender !== undefined) updateData.gender = body.gender;
    if (body.age !== undefined) updateData.age = body.age;
    if (body.description !== undefined)
      updateData.description = String(body.description).trim();
    if (body.useCase !== undefined)
      updateData.useCase = String(body.useCase).trim();
    if (body.defaultStability !== undefined)
      updateData.defaultStability = Number(body.defaultStability);
    if (body.defaultSimilarity !== undefined)
      updateData.defaultSimilarity = Number(body.defaultSimilarity);
    if (body.defaultStyle !== undefined)
      updateData.defaultStyle = Number(body.defaultStyle);
    if (body.speakerBoost !== undefined)
      updateData.speakerBoost = Boolean(body.speakerBoost);
    if (body.pitchShift !== undefined)
      updateData.pitchShift = Number(body.pitchShift);
    if (body.isFavorite !== undefined)
      updateData.isFavorite = Boolean(body.isFavorite);
    if (body.sampleCount !== undefined)
      updateData.sampleCount = Number(body.sampleCount);

    const [updated] = await db
      .update(voices)
      .set(updateData)
      .where(eq(voices.id, voiceId))
      .returning(publicVoiceColumns);

    if (!updated) {
      return NextResponse.json({ error: "Voice not found" }, { status: 404 });
    }

    return NextResponse.json({ voice: updated });
  } catch (error) {
    console.error("PATCH /api/voices/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to update voice" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const voiceId = Number(id);
    if (!voiceId) {
      return NextResponse.json({ error: "Invalid voice ID" }, { status: 400 });
    }

    const [deleted] = await db
      .delete(voices)
      .where(eq(voices.id, voiceId))
      .returning();

    if (!deleted) {
      return NextResponse.json({ error: "Voice not found" }, { status: 404 });
    }

    return NextResponse.json({ deletedId: voiceId });
  } catch (error) {
    console.error("DELETE /api/voices/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to delete voice" },
      { status: 500 }
    );
  }
}
