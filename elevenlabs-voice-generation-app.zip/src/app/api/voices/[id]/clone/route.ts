import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, voices } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { publicVoiceColumns } from "@/lib/voice-columns";
import {
  cloneVoiceOnElevenLabs,
  type StoredSample,
} from "@/lib/elevenlabs-clone";
import { synthesizeVoiceAudio } from "@/lib/audio-engine";

export const maxDuration = 120;

const MAX_FILES = 3;
const MAX_FILE_BYTES = 12 * 1024 * 1024;

/**
 * Upgrade an existing voice (local pitch-matched profile) into a REAL ElevenLabs clone,
 * using either newly uploaded samples (multipart) or the samples stored earlier.
 */
export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const voiceId = Number(id);
    if (!voiceId) {
      return NextResponse.json({ error: "Invalid voice ID" }, { status: 400 });
    }

    const [voice] = await db
      .select()
      .from(voices)
      .where(eq(voices.id, voiceId));
    if (!voice) {
      return NextResponse.json({ error: "Voice not found" }, { status: 404 });
    }

    let samples: StoredSample[] = [];
    const contentType = request.headers.get("content-type") || "";
    if (contentType.includes("multipart/form-data")) {
      const form = await request.formData();
      const files = form
        .getAll("samples")
        .filter((f): f is File => typeof f !== "string" && f.size > 0)
        .slice(0, MAX_FILES);
      for (const file of files) {
        if (file.size > MAX_FILE_BYTES) {
          return NextResponse.json(
            { error: `"${file.name}" is larger than 12 MB.` },
            { status: 413 }
          );
        }
        samples.push({
          name: file.name || "sample.wav",
          mime: file.type || "audio/wav",
          data: Buffer.from(await file.arrayBuffer()).toString("base64"),
        });
      }
    }

    if (samples.length === 0 && voice.sampleFiles) {
      try {
        samples = JSON.parse(voice.sampleFiles) as StoredSample[];
      } catch {
        samples = [];
      }
    }

    if (samples.length === 0) {
      return NextResponse.json(
        {
          error:
            "No voice sample stored for this voice. Edit the voice and upload or record a sample first.",
        },
        { status: 400 }
      );
    }

    const [activeUser] = await db
      .select()
      .from(users)
      .orderBy(asc(users.id))
      .limit(1);
    const apiKey = (
      activeUser?.elevenlabsApiKey ||
      process.env.ELEVENLABS_API_KEY ||
      ""
    ).trim();

    if (apiKey.length <= 10) {
      return NextResponse.json(
        {
          error:
            "Add your ElevenLabs API key first (sidebar → ElevenLabs API & Setup), then try again.",
        },
        { status: 400 }
      );
    }

    const result = await cloneVoiceOnElevenLabs({
      apiKey,
      name: voice.name,
      description: voice.description,
      samples,
    });

    if (!result.ok) {
      return NextResponse.json(
        {
          error: `ElevenLabs could not clone this voice: ${result.message}`,
        },
        { status: 502 }
      );
    }

    const preview = await synthesizeVoiceAudio({
      text: `Hello, I am ${voice.name.split("—")[0].trim()}. This is my cloned voice speaking.`,
      elevenlabsVoiceId: result.voiceId,
      gender: voice.gender,
      pitchShift: voice.pitchShift,
      modelId: "eleven_multilingual_v2",
      stability: voice.defaultStability,
      similarityBoost: voice.defaultSimilarity,
      styleExaggeration: voice.defaultStyle,
      speakerBoost: voice.speakerBoost,
      apiKey,
    });

    const [updated] = await db
      .update(voices)
      .set({
        elevenlabsVoiceId: result.voiceId,
        cloneStatus: "elevenlabs_cloned",
        category: "cloned",
        previewAudioUrl: preview.audioData,
        sampleCount: samples.length,
        qualityScore: 99,
        sampleFiles: JSON.stringify(samples),
      })
      .where(eq(voices.id, voiceId))
      .returning(publicVoiceColumns);

    return NextResponse.json({
      voice: updated,
      message:
        "Upgraded! This voice is now a REAL ElevenLabs clone of your uploaded sample.",
    });
  } catch (error) {
    console.error("POST /api/voices/[id]/clone error:", error);
    return NextResponse.json(
      { error: "Failed to upgrade voice clone" },
      { status: 500 }
    );
  }
}
