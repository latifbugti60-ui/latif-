import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voices } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { publicVoiceColumns } from "@/lib/voice-columns";
import { generateSilentPlaceholderWav } from "@/lib/audio-engine";
import { desc, asc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();
    const allVoices = await db
      .select(publicVoiceColumns)
      .from(voices)
      .orderBy(desc(voices.isFavorite), asc(voices.id));
    return NextResponse.json({ voices: allVoices });
  } catch (error) {
    console.error("GET /api/voices error:", error);
    return NextResponse.json(
      { error: "Failed to fetch voices" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();

    const name = (body.name || "").trim();
    if (!name) {
      return NextResponse.json(
        { error: "Voice name is required" },
        { status: 400 }
      );
    }

    const category = body.category || "cloned";
    const accent = (body.accent || "Urdu / International English").trim();
    const gender = body.gender || "Male";
    const age = body.age || "Young";
    const description =
      (body.description || "").trim() ||
      `Custom ${category} personal studio voice profile calibrated for expressive speech synthesis.`;
    const useCase = (body.useCase || "Personal Voice Clone").trim();
    const elevenlabsVoiceId =
      (body.elevenlabsVoiceId || "").trim() ||
      "pNInz6obpgDQGcFmaJgB";
    const defaultStability = Number(body.defaultStability ?? 0.52);
    const defaultSimilarity = Number(body.defaultSimilarity ?? 0.84);
    const defaultStyle = Number(body.defaultStyle ?? 0.2);
    const speakerBoost = Boolean(body.speakerBoost ?? true);
    const pitchShift = Number(body.pitchShift ?? 1.0);
    const sampleCount = Number(body.sampleCount ?? 4);

    const previewScript =
      body.sampleScript ||
      `Hello, I am ${name}. My voice profile is calibrated and ready for your personal studio scripts.`;

    const previewAudio = generateSilentPlaceholderWav({
      text: previewScript,
      gender,
      pitchShift,
      stability: defaultStability,
      style: defaultStyle,
    });

    const [created] = await db
      .insert(voices)
      .values({
        name,
        elevenlabsVoiceId,
        category,
        accent,
        gender,
        age,
        description,
        useCase,
        previewAudioUrl: previewAudio.audioData,
        defaultStability,
        defaultSimilarity,
        defaultStyle,
        speakerBoost,
        pitchShift,
        isFavorite: Boolean(body.isFavorite ?? true),
        sampleCount,
        qualityScore: 99,
      })
      .returning(publicVoiceColumns);

    return NextResponse.json({ voice: created }, { status: 201 });
  } catch (error) {
    console.error("POST /api/voices error:", error);
    return NextResponse.json(
      { error: "Failed to create voice profile" },
      { status: 500 }
    );
  }
}
