import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, voices } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { generateSilentPlaceholderWav } from "@/lib/audio-engine";
import { eq, asc } from "drizzle-orm";

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { action, email, name, password, elevenlabsApiKey } = body;

    if (action === "demo_login") {
      const allUsers = await db.select().from(users).orderBy(asc(users.id));
      const user = allUsers[0];
      return NextResponse.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          preferredEngine: user.preferredEngine,
          characterQuota: user.characterQuota,
          charactersUsed: user.charactersUsed,
          hasPersonalApiKey: Boolean(
            user.elevenlabsApiKey && user.elevenlabsApiKey.trim().length > 10
          ),
          maskedApiKey:
            user.elevenlabsApiKey && user.elevenlabsApiKey.trim().length > 10
              ? `xi-...${user.elevenlabsApiKey.slice(-6)}`
              : null,
        },
        message: "Signed in to Personal Studio workspace.",
      });
    }

    const cleanEmail = (email || "").trim().toLowerCase();
    if (!cleanEmail) {
      return NextResponse.json(
        { error: "Email address is required" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(users)
      .where(eq(users.email, cleanEmail));

    let activeUser = existing[0];

    if (!activeUser) {
      const [created] = await db
        .insert(users)
        .values({
          email: cleanEmail,
          name: (name || cleanEmail.split("@")[0] || "Studio Creator").trim(),
          passwordHash: password ? `hash_${password}` : "studio_auth_hash",
          elevenlabsApiKey: elevenlabsApiKey?.trim() || null,
          preferredEngine: "auto",
          characterQuota: 100000,
          charactersUsed: 1200,
        })
        .returning();
      activeUser = created;
    } else if (name || elevenlabsApiKey !== undefined) {
      const [updated] = await db
        .update(users)
        .set({
          name: name ? name.trim() : activeUser.name,
          elevenlabsApiKey:
            elevenlabsApiKey !== undefined
              ? elevenlabsApiKey.trim() || null
              : activeUser.elevenlabsApiKey,
        })
        .where(eq(users.id, activeUser.id))
        .returning();
      activeUser = updated;
    }

    return NextResponse.json({
      user: {
        id: activeUser.id,
        email: activeUser.email,
        name: activeUser.name,
        preferredEngine: activeUser.preferredEngine,
        characterQuota: activeUser.characterQuota,
        charactersUsed: activeUser.charactersUsed,
        hasPersonalApiKey: Boolean(
          activeUser.elevenlabsApiKey &&
            activeUser.elevenlabsApiKey.trim().length > 10
        ),
        maskedApiKey:
          activeUser.elevenlabsApiKey &&
          activeUser.elevenlabsApiKey.trim().length > 10
            ? `xi-...${activeUser.elevenlabsApiKey.slice(-6)}`
            : null,
      },
      message: "Authenticated successfully.",
    });
  } catch (error) {
    console.error("POST /api/auth error:", error);
    return NextResponse.json(
      { error: "Authentication failed" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const {
      userId,
      name,
      elevenlabsApiKey,
      preferredEngine,
      syncVoicesFromElevenLabs,
    } = body;

    const allUsers = await db.select().from(users).orderBy(asc(users.id));
    const targetUser =
      allUsers.find((u) => u.id === Number(userId)) || allUsers[0];

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const updatedFields: Partial<typeof users.$inferInsert> = {};
    if (name !== undefined && name.trim()) updatedFields.name = name.trim();
    if (preferredEngine !== undefined)
      updatedFields.preferredEngine = preferredEngine;
    if (elevenlabsApiKey !== undefined) {
      updatedFields.elevenlabsApiKey = elevenlabsApiKey.trim() || null;
    }

    const [updatedUser] = await db
      .update(users)
      .set(updatedFields)
      .where(eq(users.id, targetUser.id))
      .returning();

    let syncResultMessage = "Studio settings saved.";
    let importedCount = 0;

    const activeKey =
      updatedUser.elevenlabsApiKey || process.env.ELEVENLABS_API_KEY || "";

    if (syncVoicesFromElevenLabs && activeKey.trim().length > 10) {
      try {
        const res = await fetch("https://api.elevenlabs.io/v1/voices", {
          headers: {
            "xi-api-key": activeKey.trim(),
          },
        });
        if (res.ok) {
          const data = await res.json();
          const remoteVoices = Array.isArray(data.voices)
            ? data.voices.slice(0, 8)
            : [];
          const currentVoices = await db.select().from(voices);
          const existingIds = new Set(
            currentVoices.map((v) => v.elevenlabsVoiceId)
          );

          for (const rv of remoteVoices) {
            if (rv.voice_id && !existingIds.has(rv.voice_id)) {
              const fallbackPreview = generateSilentPlaceholderWav({
                text: `Hello, I am ${rv.name}, synced from your live ElevenLabs account.`,
                gender: rv.labels?.gender || "Neutral",
              });
              await db.insert(voices).values({
                name: `${rv.name} (ElevenLabs Live)`,
                elevenlabsVoiceId: rv.voice_id,
                category: rv.category === "cloned" ? "cloned" : "premade",
                accent: rv.labels?.accent || "International",
                gender: rv.labels?.gender
                  ? rv.labels.gender.charAt(0).toUpperCase() +
                    rv.labels.gender.slice(1)
                  : "Neutral",
                age: rv.labels?.age || "Young",
                description:
                  rv.description ||
                  `Synced directly from your live ElevenLabs account (${
                    rv.category || "voice"
                  }).`,
                useCase: rv.labels?.use_case || "Personal Voice Clone",
                previewAudioUrl: rv.preview_url || fallbackPreview.audioData,
                defaultStability: 0.55,
                defaultSimilarity: 0.8,
                defaultStyle: 0.15,
                speakerBoost: true,
                pitchShift: 1.0,
                isFavorite: true,
                sampleCount: 5,
                qualityScore: 99,
              });
              importedCount++;
            }
          }
          syncResultMessage = `Connected to ElevenLabs API! Synced ${importedCount} new voice(s) from your account.`;
        } else {
          syncResultMessage = `Saved settings. Note: ElevenLabs API responded with status ${res.status} when verifying key.`;
        }
      } catch {
        syncResultMessage =
          "Settings saved. Could not reach ElevenLabs remote server to sync voices.";
      }
    }

    const hasUserKey = Boolean(
      updatedUser.elevenlabsApiKey &&
        updatedUser.elevenlabsApiKey.trim().length > 10
    );

    return NextResponse.json({
      user: {
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        preferredEngine: updatedUser.preferredEngine,
        characterQuota: updatedUser.characterQuota,
        charactersUsed: updatedUser.charactersUsed,
        hasPersonalApiKey: hasUserKey,
        maskedApiKey: hasUserKey
          ? `xi-...${updatedUser.elevenlabsApiKey!.slice(-6)}`
          : null,
      },
      importedCount,
      message: syncResultMessage,
    });
  } catch (error) {
    console.error("PATCH /api/auth error:", error);
    return NextResponse.json(
      { error: "Failed to update settings" },
      { status: 500 }
    );
  }
}
