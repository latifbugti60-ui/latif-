import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const genId = Number(id);
    if (!genId) {
      return NextResponse.json(
        { error: "Invalid generation ID" },
        { status: 400 }
      );
    }

    const body = await request.json();
    const updateData: Partial<typeof generations.$inferInsert> = {};

    if (body.title !== undefined) updateData.title = String(body.title).trim();
    if (body.projectId !== undefined)
      updateData.projectId = body.projectId ? Number(body.projectId) : null;
    if (body.isFavorite !== undefined)
      updateData.isFavorite = Boolean(body.isFavorite);
    if (body.notes !== undefined) updateData.notes = String(body.notes).trim();
    if (body.promptText !== undefined)
      updateData.promptText = String(body.promptText).trim();

    const [updated] = await db
      .update(generations)
      .set(updateData)
      .where(eq(generations.id, genId))
      .returning();

    if (!updated) {
      return NextResponse.json(
        { error: "Generation not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({ generation: updated });
  } catch (error) {
    console.error("PATCH /api/generations/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to update generation" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const genId = Number(id);
    if (!genId) {
      return NextResponse.json(
        { error: "Invalid generation ID" },
        { status: 400 }
      );
    }

    const [deleted] = await db
      .delete(generations)
      .where(eq(generations.id, genId))
      .returning();

    if (!deleted) {
      return NextResponse.json(
        { error: "Generation not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({ deletedId: genId });
  } catch (error) {
    console.error("DELETE /api/generations/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to delete generation" },
      { status: 500 }
    );
  }
}
