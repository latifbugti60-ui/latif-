import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { generations, voices, users } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { publicVoiceColumns } from "@/lib/voice-columns";
import { synthesizeVoiceAudio } from "@/lib/audio-engine";
import { desc, eq, asc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();
    const allGenerations = await db
      .select()
      .from(generations)
      .orderBy(desc(generations.createdAt));
    return NextResponse.json({ generations: allGenerations });
  } catch (error) {
    console.error("GET /api/generations error:", error);
    return NextResponse.json(
      { error: "Failed to fetch generations" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();

    const promptText = String(body.promptText || "").trim();
    if (!promptText) {
      return NextResponse.json(
        { error: "Prompt script text is required" },
        { status: 400 }
      );
    }

    const voiceId = Number(body.voiceId);
    const allVoices = await db.select(publicVoiceColumns).from(voices);
    const selectedVoice =
      allVoices.find((v) => v.id === voiceId) || allVoices[0];

    if (!selectedVoice) {
      return NextResponse.json(
        { error: "No voice profile available for synthesis" },
        { status: 400 }
      );
    }

    const allUsers = await db.select().from(users).orderBy(asc(users.id));
    const activeUser = allUsers[0];

    const stability = Number(
      body.stability ?? selectedVoice.defaultStability ?? 0.5
    );
    const similarityBoost = Number(
      body.similarityBoost ?? selectedVoice.defaultSimilarity ?? 0.75
    );
    const styleExaggeration = Number(
      body.styleExaggeration ?? selectedVoice.defaultStyle ?? 0.15
    );
    const speakerBoost = Boolean(
      body.speakerBoost ?? selectedVoice.speakerBoost ?? true
    );
    const speed = Number(body.speed ?? 1.0);
    const modelId = String(body.modelId || "eleven_multilingual_v2");
    const projectId = body.projectId ? Number(body.projectId) : null;
    const title =
      String(body.title || "").trim() ||
      `${selectedVoice.name.split("—")[0].trim()} — ${promptText
        .slice(0, 32)
        .trim()}...`;

    const synthesis = await synthesizeVoiceAudio({
      text: promptText,
      elevenlabsVoiceId: selectedVoice.elevenlabsVoiceId,
      voiceName: selectedVoice.name,
      gender: selectedVoice.gender,
      pitchShift: selectedVoice.pitchShift,
      modelId,
      stability,
      similarityBoost,
      styleExaggeration,
      speakerBoost,
      speed,
      apiKey: body.apiKey || activeUser?.elevenlabsApiKey || null,
      // A local pitch-matched profile must NOT be sent to ElevenLabs with a stock voice ID,
      // otherwise the output would be someone else's voice.
      forceLocal:
        selectedVoice.cloneStatus === "local_profile" ||
        activeUser?.preferredEngine === "browser_neural",
      baseF0Hz: selectedVoice.measuredPitchHz,
    });

    const [created] = await db
      .insert(generations)
      .values({
        voiceId: selectedVoice.id,
        projectId,
        title,
        promptText,
        modelId,
        stability,
        similarityBoost,
        styleExaggeration,
        speakerBoost,
        speed,
        audioData: synthesis.audioData,
        durationMs: synthesis.durationMs,
        characterCount: promptText.length,
        engineUsed: synthesis.engineUsed,
        isFavorite: Boolean(body.isFavorite ?? false),
        notes: String(body.notes || "").trim(),
      })
      .returning();

    if (activeUser) {
      await db
        .update(users)
        .set({
          charactersUsed: activeUser.charactersUsed + promptText.length,
        })
        .where(eq(users.id, activeUser.id));
    }

    return NextResponse.json(
      {
        generation: created,
        engineUsed: synthesis.engineUsed,
        errorNote:
          synthesis.errorNote ??
          (selectedVoice.cloneStatus === "local_profile"
            ? "This voice is a local pitch-matched profile (not a true clone). Add your ElevenLabs API key and press 'Upgrade to real clone' on the voice card for your actual cloned voice."
            : undefined),
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/generations error:", error);
    return NextResponse.json(
      { error: "Failed to synthesize speech" },
      { status: 500 }
    );
  }
}
