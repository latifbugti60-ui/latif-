import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, voices, projects, generations } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { publicVoiceColumns } from "@/lib/voice-columns";
import { desc, asc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();

    const [allUsers, allVoices, allProjects, allGenerations] = await Promise.all([
      db.select().from(users).orderBy(asc(users.id)),
      db
        .select(publicVoiceColumns)
        .from(voices)
        .orderBy(desc(voices.isFavorite), asc(voices.id)),
      db.select().from(projects).orderBy(desc(projects.createdAt)),
      db.select().from(generations).orderBy(desc(generations.createdAt)),
    ]);

    const currentUser = allUsers[0] || null;
    const hasServerKey = Boolean(
      process.env.ELEVENLABS_API_KEY &&
        process.env.ELEVENLABS_API_KEY.trim().length > 10
    );
    const hasUserKey = Boolean(
      currentUser?.elevenlabsApiKey &&
        currentUser.elevenlabsApiKey.trim().length > 10
    );

    return NextResponse.json({
      user: currentUser
        ? {
            id: currentUser.id,
            email: currentUser.email,
            name: currentUser.name,
            preferredEngine: currentUser.preferredEngine,
            characterQuota: currentUser.characterQuota,
            charactersUsed: currentUser.charactersUsed,
            hasPersonalApiKey: hasUserKey,
            maskedApiKey: hasUserKey
              ? `xi-...${currentUser.elevenlabsApiKey!.slice(-6)}`
              : null,
          }
        : null,
      hasLiveElevenLabsKey: hasServerKey || hasUserKey,
      voices: allVoices,
      projects: allProjects,
      generations: allGenerations,
    });
  } catch (error) {
    console.error("GET /api/studio error:", error);
    return NextResponse.json(
      { error: "Failed to load studio workspace data" },
      { status: 500 }
    );
  }
}
