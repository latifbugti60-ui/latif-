import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();
    const allProjects = await db
      .select()
      .from(projects)
      .orderBy(desc(projects.createdAt));
    return NextResponse.json({ projects: allProjects });
  } catch (error) {
    console.error("GET /api/projects error:", error);
    return NextResponse.json(
      { error: "Failed to fetch projects" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();

    const title = String(body.title || "").trim();
    if (!title) {
      return NextResponse.json(
        { error: "Project title is required" },
        { status: 400 }
      );
    }

    const description =
      String(body.description || "").trim() ||
      "Multi-take studio audio production workspace.";
    const category = String(body.category || "Audiobook").trim();
    const status = String(body.status || "active").trim();
    const targetLanguage = String(
      body.targetLanguage || "English & Urdu"
    ).trim();

    const [created] = await db
      .insert(projects)
      .values({
        title,
        description,
        category,
        status,
        targetLanguage,
      })
      .returning();

    return NextResponse.json({ project: created }, { status: 201 });
  } catch (error) {
    console.error("POST /api/projects error:", error);
    return NextResponse.json(
      { error: "Failed to create project" },
      { status: 500 }
    );
  }
}
