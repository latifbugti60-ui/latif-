"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  StudioUser,
  VoiceProfile,
  StudioProject,
  VoiceGeneration,
  ActiveTrack,
} from "@/types/studio";
import VoiceLabModal, { VoiceFormPayload } from "@/components/VoiceLabModal";
import DeveloperAvatar from "@/components/DeveloperAvatar";
import AuthSettingsModal from "@/components/AuthSettingsModal";
import BottomWaveformPlayer from "@/components/BottomWaveformPlayer";
import LatifAiVisualizer from "@/components/LatifAiVisualizer";
import { speakWithBrowserNeural } from "@/lib/browser-speech";
import {
  Mic,
  Sparkles,
  History,
  FolderKanban,
  Sliders,
  Play,
  Pause,
  Plus,
  Trash2,
  Edit3,
  Heart,
  Download,
  Search,
  Key,
  CheckCircle2,
  Volume2,
  Radio,
  Wand2,
  Menu,
  X,
  UserCheck,
  RotateCcw,
  HelpCircle,
} from "lucide-react";

type NavSection = "synthesis" | "voices" | "history" | "projects";

const SCRIPT_PRESETS = [
  {
    label: "🔴🟢 Latif Bugti Intro (Roman Urdu)",
    title: "Latif Bugti — Real Voice Confirmation",
    text: "Assalam-o-Alaikum! Main Latif Bugti hoon. Is Latif AI Red and Black Neural Studio app mein aap 100 percent real voice generate kar sakte hain. Aap apni ElevenLabs API key lagakar original AI cloned MP3 bana sakte hain, ya Latif AI Real Speech Engine se foran bolti hui aawaz sun sakte hain!",
  },
  {
    label: "🎙️ Latif Bugti YouTube Intro",
    title: "Latif Bugti YouTube Channel Intro Take",
    text: "Welcome back to the channel! Today I'm testing my personal Latif Bugti ElevenLabs voice clone right inside Latif AI Red and Black Studio. Let's dive into how neural speech synthesis is transforming content creation.",
  },
  {
    label: "📖 Sci-Fi Audiobook",
    title: "Kepler-442b Chapter Opening",
    text: "The rain against the glass of the high-altitude observatory wasn't merely weather; it was a relentless metronome counting down the final hours before the first signal arrived from deep space.",
  },
  {
    label: "🎧 Bilingual Podcast Hook",
    title: "Latif Bugti Late Night Podcast",
    text: "Assalam-o-Alaikum dosto! Aaj ki is episode mein hum baat karenge ke kis tarah Latif Bugti AI personal voice cloning solo creators ke liye ek mukammal audio production studio ban chuka hai.",
  },
];

export default function StudioDashboard() {
  const [activeNav, setActiveNav] = useState<NavSection>("synthesis");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Core studio data from PostgreSQL
  const [user, setUser] = useState<StudioUser | null>(null);
  const [hasLiveElevenLabsKey, setHasLiveElevenLabsKey] = useState(false);
  const [voices, setVoices] = useState<VoiceProfile[]>([]);
  const [projects, setProjects] = useState<StudioProject[]>([]);
  const [generations, setGenerations] = useState<VoiceGeneration[]>([]);

  // Synthesis Studio state
  const [selectedVoiceId, setSelectedVoiceId] = useState<number>(1);
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [takeTitle, setTakeTitle] = useState("Latif Bugti Studio Voiceover Take");
  const [promptText, setPromptText] = useState(
    "Assalam-o-Alaikum! Main Latif Bugti hoon. Is Latif AI Red and Black Neural Studio app se real voice generate hoti hai. Click 'Generate Speech' or click the glowing Latif Bugti Orb above to hear this script spoken out loud right now!"
  );
  const [modelId, setModelId] = useState("eleven_multilingual_v2");
  const [stability, setStability] = useState(0.52);
  const [similarityBoost, setSimilarityBoost] = useState(0.86);
  const [styleExaggeration, setStyleExaggeration] = useState(0.22);
  const [speakerBoost, setSpeakerBoost] = useState(true);
  const [speed, setSpeed] = useState(1.0);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [upgradingVoiceId, setUpgradingVoiceId] = useState<number | null>(null);
  const cloneFileInputRef = useRef<HTMLInputElement | null>(null);
  const [pendingCloneFiles, setPendingCloneFiles] = useState<File[]>([]);

  // Filters & search
  const [voiceCategoryFilter, setVoiceCategoryFilter] = useState("all");
  const [voiceSearch, setVoiceSearch] = useState("");
  const [historySearch, setHistorySearch] = useState("");
  const [historyVoiceFilter, setHistoryVoiceFilter] = useState<string>("all");
  const [historyProjectFilter, setHistoryProjectFilter] = useState<string>("all");
  const [historyFavoritesOnly, setHistoryFavoritesOnly] = useState(false);

  // Project CRUD form state
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [editingProject, setEditingProject] = useState<StudioProject | null>(null);
  const [projectTitle, setProjectTitle] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [projectCategory, setProjectCategory] = useState("YouTube Automation");
  const [projectLanguage, setProjectLanguage] = useState("English & Urdu");
  const [projectStatus, setProjectStatus] = useState("active");

  // Inline editing for generation title
  const [editingGenId, setEditingGenId] = useState<number | null>(null);
  const [editingGenTitle, setEditingGenTitle] = useState("");

  // Modals
  const [voiceModalOpen, setVoiceModalOpen] = useState(false);
  const [editingVoice, setEditingVoice] = useState<VoiceProfile | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<"engine" | "auth">("engine");

  // Active Audio Player State
  const [activeTrack, setActiveTrack] = useState<ActiveTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Toast feedback
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "info";
  } | null>(null);

  const showToast = (message: string, type: "success" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4200);
  };

  const fetchStudioData = async () => {
    try {
      const res = await fetch("/api/studio");
      if (!res.ok) throw new Error("Failed to load studio");
      const data = await res.json();
      setUser(data.user);
      setHasLiveElevenLabsKey(Boolean(data.hasLiveElevenLabsKey));
      setVoices(data.voices || []);
      setProjects(data.projects || []);
      setGenerations(data.generations || []);

      if (data.voices?.length > 0) {
        const firstVoice = data.voices[0];
        setSelectedVoiceId(firstVoice.id);
        setStability(firstVoice.defaultStability);
        setSimilarityBoost(firstVoice.defaultSimilarity);
        setStyleExaggeration(firstVoice.defaultStyle);
        setSpeakerBoost(firstVoice.speakerBoost);
      }
      if (data.projects?.length > 0) {
        setSelectedProjectId(data.projects[0].id);
      }
      if (data.generations?.length > 0 && !activeTrack) {
        const latest = data.generations[0];
        const v =
          data.voices?.find((x: VoiceProfile) => x.id === latest.voiceId) ||
          data.voices?.[0];
        setActiveTrack({
          id: `gen-${latest.id}`,
          title: latest.title,
          subtitle: latest.modelId,
          promptText: latest.promptText,
          audioData: latest.audioData,
          durationMs: latest.durationMs,
          voiceName: v?.name || "Latif Bugti — Personal Voice Clone",
          gender: v?.gender || "Male",
          pitchShift: v?.pitchShift || 1.0,
          speed: latest.speed || 1.0,
          engineUsed: latest.engineUsed,
        });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStudioData();
  }, []);

  // "Clone My Voice" buttons open the PC file picker right away (inside the click).
  const openCloneFlow = () => {
    setMobileMenuOpen(false);
    cloneFileInputRef.current?.click();
  };

  // If the user closes the PC file dialog without choosing, still open the Voice Lab
  // so they can record with the microphone instead.
  useEffect(() => {
    const input = cloneFileInputRef.current;
    if (!input) return;
    const onCancel = () => {
      setEditingVoice(null);
      setPendingCloneFiles([]);
      setVoiceModalOpen(true);
    };
    input.addEventListener("cancel", onCancel);
    return () => input.removeEventListener("cancel", onCancel);
  }, []);

  const selectedVoice = useMemo(
    () => voices.find((v) => v.id === selectedVoiceId) || voices[0] || null,
    [voices, selectedVoiceId]
  );

  const handleSelectVoiceForStudio = (voice: VoiceProfile) => {
    setSelectedVoiceId(voice.id);
    setStability(voice.defaultStability);
    setSimilarityBoost(voice.defaultSimilarity);
    setStyleExaggeration(voice.defaultStyle);
    setSpeakerBoost(voice.speakerBoost);
    showToast(`Loaded Latif Bugti voice profile: ${voice.name}`);
  };

  const handlePlayGeneration = (gen: VoiceGeneration) => {
    const voice = voices.find((v) => v.id === gen.voiceId) || voices[0];
    const trackId = `gen-${gen.id}`;
    if (activeTrack?.id === trackId) {
      setIsPlaying((prev) => !prev);
      return;
    }
    setActiveTrack({
      id: trackId,
      title: gen.title,
      subtitle: gen.modelId,
      promptText: gen.promptText,
      audioData: gen.audioData,
      durationMs: gen.durationMs,
      voiceName: voice?.name || "Latif Bugti — Personal Voice Clone",
      gender: voice?.gender || "Male",
      pitchShift: voice?.pitchShift || 1.0,
      speed: gen.speed || 1.0,
      engineUsed: gen.engineUsed,
    });
    setIsPlaying(true);
  };

  const handleAuditionVoice = (voice: VoiceProfile) => {
    const trackId = `voice-preview-${voice.id}`;
    if (activeTrack?.id === trackId) {
      setIsPlaying((prev) => !prev);
      return;
    }
    const sampleLine = `Hello! I am ${voice.name.split("—")[0].trim()} on Latif Bugti Red and Black Studio. ${
      voice.description
    }`;
    setActiveTrack({
      id: trackId,
      title: `Voice Preview — ${voice.name}`,
      subtitle: voice.category,
      promptText: sampleLine,
      audioData: voice.previewAudioUrl,
      durationMs: 4200,
      voiceName: voice.name,
      gender: voice.gender,
      pitchShift: voice.pitchShift,
      speed: 1.0,
      engineUsed: voice.previewAudioUrl.startsWith("data:audio/wav")
        ? "studio_neural"
        : "elevenlabs_live",
    });
    setIsPlaying(true);
  };

  // Synthesize New Take (POST /api/generations)
  const handleSynthesizeSpeech = async () => {
    if (!promptText.trim() || !selectedVoice) return;
    setIsSynthesizing(true);
    try {
      const res = await fetch("/api/generations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voiceId: selectedVoice.id,
          projectId: selectedProjectId,
          title:
            takeTitle.trim() ||
            `${selectedVoice.name.split("—")[0].trim()} Studio Take`,
          promptText: promptText.trim(),
          modelId,
          stability,
          similarityBoost,
          styleExaggeration,
          speakerBoost,
          speed,
        }),
      });

      if (!res.ok) throw new Error("Failed to synthesize speech");
      const data = await res.json();
      const createdGen: VoiceGeneration = data.generation;

      setGenerations((prev) => [createdGen, ...prev]);
      if (user) {
        setUser({
          ...user,
          charactersUsed: user.charactersUsed + promptText.trim().length,
        });
      }

      // Immediately play the newly generated take!
      setActiveTrack({
        id: `gen-${createdGen.id}`,
        title: createdGen.title,
        subtitle: createdGen.modelId,
        promptText: createdGen.promptText,
        audioData: createdGen.audioData,
        durationMs: createdGen.durationMs,
        voiceName: selectedVoice.name,
        gender: selectedVoice.gender,
        pitchShift: selectedVoice.pitchShift,
        speed: createdGen.speed,
        engineUsed: createdGen.engineUsed,
      });
      setIsPlaying(true);

      if (data.engineUsed === "elevenlabs_live") {
        showToast("Latif Bugti AI synthesized live MP3 via ElevenLabs Neural API!");
      } else {
        showToast(
          data.errorNote ||
            "Take saved. Speaking it now with the built-in live voice (no tone)."
        );
      }
    } catch {
      showToast("Error during speech synthesis", "info");
    } finally {
      setIsSynthesizing(false);
    }
  };

  // Voice CRUD handlers
  const handleSaveVoice = async (payload: VoiceFormPayload): Promise<boolean> => {
    const { samples, measuredPitchHz, sampleCount, ...fields } = payload;
    void sampleCount;

    const buildForm = () => {
      const form = new FormData();
      Object.entries({ ...fields, measuredPitchHz: measuredPitchHz ?? "" }).forEach(
        ([key, value]) => form.append(key, String(value))
      );
      samples.forEach((file) => form.append("samples", file, file.name));
      return form;
    };

    try {
      // ---- Edit an existing voice ----
      if (editingVoice) {
        const { sampleScript, ...patchFields } = fields;
        void sampleScript;
        const res = await fetch(`/api/voices/${editingVoice.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patchFields),
        });
        if (!res.ok) throw new Error("Failed to update voice settings");
        const { voice } = await res.json();
        setVoices((prev) => prev.map((v) => (v.id === voice.id ? voice : v)));

        if (samples.length > 0) {
          const cloneRes = await fetch(`/api/voices/${editingVoice.id}/clone`, {
            method: "POST",
            body: buildForm(),
          });
          const data = await cloneRes.json().catch(() => ({}));
          if (cloneRes.ok && data.voice) {
            setVoices((prev) =>
              prev.map((v) => (v.id === data.voice.id ? data.voice : v))
            );
            showToast(data.message || "Voice re-cloned from your new sample");
          } else {
            showToast(data.error || "Could not re-clone this voice", "info");
            return false;
          }
        } else {
          showToast(`Updated voice settings: ${voice.name}`);
        }
        return true;
      }

      // ---- New voice cloned from the user's own uploaded / recorded sample ----
      if (fields.category === "cloned" && samples.length > 0) {
        const res = await fetch("/api/voices/clone", {
          method: "POST",
          body: buildForm(),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.voice) {
          showToast(data.error || "Voice cloning failed", "info");
          return false;
        }
        setVoices((prev) => [data.voice, ...prev]);
        handleSelectVoiceForStudio(data.voice);
        setActiveNav("synthesis");
        showToast(
          data.message || "Voice created",
          data.cloneStatus === "elevenlabs_cloned" ? "success" : "info"
        );
        return true;
      }

      // ---- Premade / designed voice (no samples) ----
      const res = await fetch("/api/voices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(fields),
      });
      if (!res.ok) throw new Error("Failed to create voice");
      const { voice } = await res.json();
      setVoices((prev) => [voice, ...prev]);
      setSelectedVoiceId(voice.id);
      showToast(`Created voice: ${voice.name}`);
      return true;
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : "Something went wrong saving this voice",
        "info"
      );
      return false;
    }
  };

  // Turn a stored local sample into a REAL ElevenLabs clone
  const handleUpgradeClone = async (voice: VoiceProfile) => {
    if (!hasLiveElevenLabsKey) {
      setAuthModalTab("engine");
      setAuthModalOpen(true);
      showToast(
        "Pehle apni ElevenLabs API key save karein, phir 'Upgrade to real clone' dabayein.",
        "info"
      );
      return;
    }
    setUpgradingVoiceId(voice.id);
    try {
      const res = await fetch(`/api/voices/${voice.id}/clone`, { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.voice) {
        setVoices((prev) => prev.map((v) => (v.id === data.voice.id ? data.voice : v)));
        showToast(data.message || "Voice upgraded to a real clone");
      } else {
        showToast(data.error || "Could not upgrade this voice", "info");
      }
    } catch {
      showToast("Network error while cloning voice", "info");
    } finally {
      setUpgradingVoiceId(null);
    }
  };

  const renderCloneBadge = (voice: VoiceProfile) => (
    <div className="mt-2 flex flex-wrap items-center gap-2">
      <span
        className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
          voice.cloneStatus === "elevenlabs_cloned"
            ? "border-[#B91C1C]/60 bg-[#B91C1C]/20 text-[#FCA5A5]"
            : voice.cloneStatus === "local_profile"
            ? "border-[#EF4444]/60 bg-[#EF4444]/15 text-[#FCA5A5]"
            : "border-[#B91C1C]/25 bg-[#0C0909] text-[#FCA5A5]/70"
        }`}
      >
        {voice.cloneStatus === "elevenlabs_cloned"
          ? "✓ Real clone of your voice"
          : voice.cloneStatus === "local_profile"
          ? "Pitch-matched profile (not a true clone)"
          : "Stock / premade voice"}
      </span>
      {voice.cloneStatus === "local_profile" && voice.hasSamples && (
        <button
          type="button"
          disabled={upgradingVoiceId === voice.id}
          onClick={() => handleUpgradeClone(voice)}
          className="rounded-md bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-2.5 py-0.5 text-[10px] font-bold text-[#FFF1F1] hover:opacity-95 disabled:opacity-60"
        >
          {upgradingVoiceId === voice.id ? "Cloning…" : "Upgrade to real clone"}
        </button>
      )}
    </div>
  );

  const handleToggleVoiceFavorite = async (voice: VoiceProfile) => {
    const nextFav = !voice.isFavorite;
    setVoices((prev) =>
      prev.map((v) => (v.id === voice.id ? { ...v, isFavorite: nextFav } : v))
    );
    await fetch(`/api/voices/${voice.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isFavorite: nextFav }),
    });
  };

  const handleDeleteVoice = async (voiceId: number) => {
    if (voices.length <= 1) {
      showToast("At least one Latif Bugti voice profile must remain active.", "info");
      return;
    }
    const target = voices.find((v) => v.id === voiceId);
    setVoices((prev) => prev.filter((v) => v.id !== voiceId));
    setGenerations((prev) => prev.filter((g) => g.voiceId !== voiceId));
    await fetch(`/api/voices/${voiceId}`, { method: "DELETE" });
    showToast(`Deleted voice profile: ${target?.name || ""}`);
  };

  // Generation CRUD handlers
  const handleToggleGenFavorite = async (gen: VoiceGeneration) => {
    const nextFav = !gen.isFavorite;
    setGenerations((prev) =>
      prev.map((g) => (g.id === gen.id ? { ...g, isFavorite: nextFav } : g))
    );
    await fetch(`/api/generations/${gen.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isFavorite: nextFav }),
    });
  };

  const handleUpdateGeneration = async (
    genId: number,
    updates: Partial<VoiceGeneration>
  ) => {
    setGenerations((prev) =>
      prev.map((g) => (g.id === genId ? { ...g, ...updates } : g))
    );
    await fetch(`/api/generations/${genId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    setEditingGenId(null);
    showToast("Saved generation metadata");
  };

  const handleDeleteGeneration = async (genId: number) => {
    setGenerations((prev) => prev.filter((g) => g.id !== genId));
    await fetch(`/api/generations/${genId}`, { method: "DELETE" });
    showToast("Removed audio take from Latif Bugti history");
  };

  // Project CRUD handlers
  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectTitle.trim()) return;

    if (editingProject) {
      const res = await fetch(`/api/projects/${editingProject.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: projectTitle,
          description: projectDescription,
          category: projectCategory,
          targetLanguage: projectLanguage,
          status: projectStatus,
        }),
      });
      if (res.ok) {
        const { project } = await res.json();
        setProjects((prev) =>
          prev.map((p) => (p.id === project.id ? project : p))
        );
        showToast(`Updated project: ${project.title}`);
      }
    } else {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: projectTitle,
          description: projectDescription,
          category: projectCategory,
          targetLanguage: projectLanguage,
          status: projectStatus,
        }),
      });
      if (res.ok) {
        const { project } = await res.json();
        setProjects((prev) => [project, ...prev]);
        setSelectedProjectId(project.id);
        showToast(`Created Latif Bugti project: ${project.title}`);
      }
    }

    setShowProjectForm(false);
    setEditingProject(null);
    setProjectTitle("");
    setProjectDescription("");
  };

  const handleDeleteProject = async (projectId: number) => {
    setProjects((prev) => prev.filter((p) => p.id !== projectId));
    setGenerations((prev) =>
      prev.map((g) => (g.projectId === projectId ? { ...g, projectId: null } : g))
    );
    await fetch(`/api/projects/${projectId}`, { method: "DELETE" });
    showToast("Deleted studio project");
  };

  // Filtered lists
  const filteredVoices = useMemo(() => {
    return voices.filter((v) => {
      if (voiceCategoryFilter === "favorites" && !v.isFavorite) return false;
      if (
        voiceCategoryFilter !== "all" &&
        voiceCategoryFilter !== "favorites" &&
        v.category !== voiceCategoryFilter
      ) {
        return false;
      }
      if (voiceSearch.trim()) {
        const q = voiceSearch.toLowerCase();
        return (
          v.name.toLowerCase().includes(q) ||
          v.accent.toLowerCase().includes(q) ||
          v.useCase.toLowerCase().includes(q) ||
          v.description.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [voices, voiceCategoryFilter, voiceSearch]);

  const filteredGenerations = useMemo(() => {
    return generations.filter((g) => {
      if (historyFavoritesOnly && !g.isFavorite) return false;
      if (
        historyVoiceFilter !== "all" &&
        g.voiceId !== Number(historyVoiceFilter)
      )
        return false;
      if (
        historyProjectFilter !== "all" &&
        g.projectId !== Number(historyProjectFilter)
      )
        return false;
      if (historySearch.trim()) {
        const q = historySearch.toLowerCase();
        return (
          g.title.toLowerCase().includes(q) ||
          g.promptText.toLowerCase().includes(q) ||
          g.notes.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [
    generations,
    historyFavoritesOnly,
    historyVoiceFilter,
    historyProjectFilter,
    historySearch,
  ]);

  const quotaPercentage = user
    ? Math.min(100, Math.round((user.charactersUsed / user.characterQuota) * 100))
    : 18;

  return (
    <div className="min-h-screen bg-[#080505] text-[#FFF1F1] flex flex-col pb-[88px] relative overflow-x-hidden">
      {/* Ambient Background Animated LATIF BUGTI Red-Black Watermark */}
      <div className="pointer-events-none fixed inset-0 z-0 flex items-center justify-center opacity-[0.045] select-none overflow-hidden">
        <div className="rotate-[-12deg] text-center space-y-6">
          <p className="font-display text-7xl sm:text-9xl font-black tracking-widest uppercase animate-latif-bugti-text">
            LATIF BUGTI
          </p>
          <p className="font-display text-5xl sm:text-7xl font-extrabold tracking-widest uppercase animate-latif-bugti-text">
            LATIF AI • RED &amp; BLACK STUDIO
          </p>
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2.5 rounded-xl border border-[#B91C1C]/60 bg-gradient-to-r from-[#1E080B]/95 to-[#0E0B0B]/95 px-4 py-3 text-xs font-medium text-[#FFF1F1] shadow-[0_0_30px_rgba(185,28,28,0.35)] backdrop-blur-md">
          <CheckCircle2 className="h-4 w-4 text-[#F87171] shrink-0" />
          <span>{toast.message}</span>
        </div>
      )}

      <div className="relative z-10 flex flex-1">
        {/* Left Fixed Desktop Sidebar (260px) — Red & Black Mix Theme */}
        <aside
          className={`fixed inset-y-0 left-0 z-40 w-[260px] border-r border-[#B91C1C]/30 bg-gradient-to-b from-[#160709] via-[#0B0808] to-[#120608] flex flex-col justify-between pb-[84px] transition-transform duration-200 lg:translate-x-0 ${
            mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="p-5 space-y-6">
            {/* Latif Bugti / Latif AI Brand Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative flex h-10 w-10 items-center justify-center rounded-xl animate-latif-bugti-bg text-[#FFF1F1] shadow-lg shadow-[#B91C1C]/30 border border-[#F87171]/50">
                  <Radio className="h-5 w-5 stroke-[2.2] animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-display text-base font-extrabold tracking-tight animate-latif-bugti-text">
                      Latif Bugti
                    </span>
                    <span className="rounded bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-1.5 py-0.5 font-mono-tech text-[9px] font-bold text-[#FFF1F1] shadow-sm">
                      AI
                    </span>
                  </div>
                  <p className="text-[11px] text-[#FCA5A5]">
                    Latif AI Red &amp; Black Studio
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="lg:hidden rounded-lg p-1.5 text-[#FCA5A5] hover:text-[#EF4444]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Quick Action: Clone Personal Voice */}
            <button
              type="button"
              onClick={openCloneFlow}
              className="w-full flex items-center justify-center gap-2 rounded-xl animate-latif-bugti-bg px-4 py-2.5 text-xs font-bold text-[#FFF1F1] border border-[#F87171]/40 hover:opacity-95 transition shadow-lg shadow-[#EF4444]/25"
            >
              <Plus className="h-4 w-4 stroke-[2.5]" />
              Clone My Voice (Upload from PC)
            </button>

            {/* Primary Navigation */}
            <nav className="space-y-1.5">
              {[
                {
                  id: "synthesis" as NavSection,
                  label: "Latif AI Synthesis",
                  icon: Wand2,
                  badge: "LIVE",
                },
                {
                  id: "voices" as NavSection,
                  label: "Voice Lab & Clones",
                  icon: Mic,
                  badge: String(voices.length),
                },
                {
                  id: "history" as NavSection,
                  label: "Generation History",
                  icon: History,
                  badge: String(generations.length),
                },
                {
                  id: "projects" as NavSection,
                  label: "Studio Projects",
                  icon: FolderKanban,
                  badge: String(projects.length),
                },
              ].map((item) => {
                const Icon = item.icon;
                const active = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveNav(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-medium transition ${
                      active
                        ? "bg-gradient-to-r from-[#EF4444]/25 to-[#B91C1C]/25 text-[#FFF1F1] border-l-[3px] border-[#B91C1C] shadow-sm"
                        : "text-[#FDBABA]/75 hover:bg-[#B91C1C]/10 hover:text-[#FFF1F1]"
                    }`}
                  >
                    <span className="flex items-center gap-3 whitespace-nowrap">
                      <Icon
                        className={`h-4 w-4 ${
                          active ? "text-[#EF4444]" : "text-[#F87171]"
                        }`}
                      />
                      {item.label}
                    </span>
                    <span
                      className={`font-mono-tech rounded-md px-1.5 py-0.5 text-[10px] ${
                        active
                          ? "bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] text-[#FFF1F1] font-bold"
                          : "bg-[#0B0808] text-[#FCA5A5]"
                      }`}
                    >
                      {item.badge}
                    </span>
                  </button>
                );
              })}

              <button
                type="button"
                onClick={() => {
                  setAuthModalTab("engine");
                  setAuthModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-medium text-[#FDBABA]/75 hover:bg-[#B91C1C]/10 hover:text-[#FFF1F1] transition"
              >
                <span className="flex items-center gap-3 whitespace-nowrap">
                  <Key className="h-4 w-4 text-[#EF4444]" />
                  ElevenLabs API &amp; Setup
                </span>
                <span
                  className={`h-2 w-2 rounded-full ${
                    hasLiveElevenLabsKey ? "bg-[#B91C1C]" : "bg-[#EF4444] animate-ping"
                  }`}
                />
              </button>
            </nav>
          </div>

          {/* Bottom Sidebar: Quota Meter & Authenticated User Card */}
          <div className="p-4 space-y-3 border-t border-[#B91C1C]/30 bg-[#0A0707]/90">
            <div className="rounded-xl border border-[#B91C1C]/30 bg-gradient-to-br from-[#19070A] to-[#0D0A0A] p-3.5 space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#FCA5A5] font-medium">
                  Latif Bugti Quota
                </span>
                <span className="font-mono-tech text-[#EF4444] font-semibold">
                  {quotaPercentage}%
                </span>
              </div>
              <div className="h-1.5 w-full rounded-full bg-[#080505] overflow-hidden">
                <div
                  style={{ width: `${quotaPercentage}%` }}
                  className="h-full rounded-full bg-gradient-to-r from-[#EF4444] via-[#7F1D1D] to-[#EF4444]"
                />
              </div>
              <div className="flex items-center justify-between font-mono-tech text-[10px] text-[#FCA5A5]/70">
                <span>
                  {(user?.charactersUsed || 18450).toLocaleString()} used
                </span>
                <span>
                  {(user?.characterQuota || 100000).toLocaleString()} limit
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setAuthModalTab("auth");
                setAuthModalOpen(true);
              }}
              className="w-full flex items-center justify-between rounded-xl border border-[#B91C1C]/35 bg-gradient-to-r from-[#1A080B] to-[#0E0B0B] px-3 py-2.5 text-left hover:border-[#EF4444] transition"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-[#EF4444] to-[#7F1D1D] text-xs font-bold text-[#FFF1F1] shadow">
                  LB
                </div>
                <div className="min-w-0">
                  <p className="truncate text-xs font-semibold text-[#FFF1F1]">
                    {user?.name || "Latif Bugti (Latif AI)"}
                  </p>
                  <p className="truncate text-[10px] text-[#FCA5A5]">
                    {user?.email || "latifbugti@latifai.studio"}
                  </p>
                </div>
              </div>
              <UserCheck className="h-4 w-4 text-[#F87171] shrink-0" />
            </button>
          </div>
        </aside>

        {/* Main Workspace Container */}
        <div className="flex-1 lg:pl-[260px] flex flex-col min-w-0">
          {/* Top Studio Utility Header (64px) */}
          <header className="sticky top-0 z-30 h-16 border-b border-[#B91C1C]/30 bg-gradient-to-r from-[#140608]/90 via-[#0B0808]/90 to-[#140608]/90 backdrop-blur-xl px-4 lg:px-8 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden rounded-lg border border-[#B91C1C]/40 bg-[#0D0A0A] p-2 text-[#FCA5A5]"
              >
                <Menu className="h-5 w-5" />
              </button>
              <div className="flex items-center gap-2.5">
                <DeveloperAvatar />
                <span className="hidden sm:inline-block h-2.5 w-2.5 rounded-full bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] shadow-[0_0_12px_#B91C1C] animate-pulse" />
                <h1 className="font-display text-base sm:text-lg font-extrabold tracking-tight animate-latif-bugti-text">
                  {activeNav === "synthesis" &&
                    "LATIF BUGTI — Latif AI Red & Black Voice Studio"}
                  {activeNav === "voices" &&
                    "LATIF BUGTI Voice Lab — Personal Clones & Personas"}
                  {activeNav === "history" &&
                    "LATIF BUGTI Generation Archive & Multi-Take Log"}
                  {activeNav === "projects" &&
                    "LATIF BUGTI Studio Production Projects"}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              {/* Engine Status Pill */}
              <button
                type="button"
                onClick={() => {
                  setAuthModalTab("engine");
                  setAuthModalOpen(true);
                }}
                className="hidden md:inline-flex items-center gap-2 rounded-full border border-[#B91C1C]/50 bg-gradient-to-r from-[#EF4444]/20 to-[#B91C1C]/20 px-3 py-1.5 text-[11px] font-mono-tech font-semibold text-[#FCA5A5] hover:from-[#EF4444]/35 hover:to-[#B91C1C]/35 transition"
              >
                <span className="h-2 w-2 rounded-full bg-[#B91C1C] animate-ping" />
                <span>
                  {hasLiveElevenLabsKey
                    ? "LATIF BUGTI • ELEVENLABS LIVE"
                    : "LATIF BUGTI • RED + BLACK AI"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthModalTab("engine");
                  setAuthModalOpen(true);
                }}
                className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-[#EF4444]/50 bg-gradient-to-r from-[#EF4444]/15 to-[#B91C1C]/15 px-3 py-1.5 text-xs font-medium text-[#FFF1F1] hover:border-[#B91C1C] transition"
              >
                <HelpCircle className="h-3.5 w-3.5 text-[#EF4444]" />
                <span>API &amp; Voice Info</span>
              </button>
            </div>
          </header>

          {/* Main Content Body */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto space-y-6">
            {/* Interactive Animated Red & Black Latif Bugti Neural Core & Equalizer Visualizer */}
            <LatifAiVisualizer
              isPlaying={isPlaying}
              isSynthesizing={isSynthesizing}
              activeVoiceName={
                selectedVoice?.name || "Latif Bugti — Personal Voice Clone"
              }
              activeVoiceGender={selectedVoice?.gender || "Male"}
              activeVoicePitch={selectedVoice?.pitchShift || 0.98}
              promptText={promptText}
              onTriggerGenerate={handleSynthesizeSpeech}
            />

            {/* VIEW 1: SPEECH SYNTHESIS STUDIO */}
            {activeNav === "synthesis" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Left 7 Columns: Prompt Script Composer & Recent Takes */}
                <div className="lg:col-span-7 xl:col-span-8 space-y-6">
                  {/* Script Editor Card */}
                  <div className="relative overflow-hidden rounded-xl border border-[#B91C1C]/35 bg-gradient-to-br from-[#170709] via-[#0C0909] to-[#140709] p-5 sm:p-6 shadow-xl space-y-4">
                    {/* Top Row: Voice Quick Selector & Project Selector */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#B91C1C]/25">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <div className="flex items-center gap-2 rounded-lg border border-[#EF4444]/50 bg-[#14080A] px-3 py-1.5">
                          <Mic className="h-3.5 w-3.5 text-[#EF4444]" />
                          <select
                            value={selectedVoiceId}
                            onChange={(e) => {
                              const v = voices.find(
                                (x) => x.id === Number(e.target.value)
                              );
                              if (v) handleSelectVoiceForStudio(v);
                            }}
                            className="bg-transparent text-xs font-semibold text-[#FFF1F1] focus:outline-none cursor-pointer"
                          >
                            {voices.map((v) => (
                              <option
                                key={v.id}
                                value={v.id}
                                className="bg-[#0C0909] text-[#FFF1F1]"
                              >
                                {v.name} ({v.category.toUpperCase()})
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="flex items-center gap-2 rounded-lg border border-[#B91C1C]/40 bg-[#0C0909] px-3 py-1.5">
                          <FolderKanban className="h-3.5 w-3.5 text-[#F87171]" />
                          <select
                            value={selectedProjectId || ""}
                            onChange={(e) =>
                              setSelectedProjectId(
                                e.target.value ? Number(e.target.value) : null
                              )
                            }
                            className="bg-transparent text-xs text-[#FCA5A5] focus:outline-none cursor-pointer"
                          >
                            <option value="" className="bg-[#0C0909]">
                              No Project Linked
                            </option>
                            {projects.map((p) => (
                              <option
                                key={p.id}
                                value={p.id}
                                className="bg-[#0C0909] text-[#FFF1F1]"
                              >
                                {p.title}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          selectedVoice && handleAuditionVoice(selectedVoice)
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#B91C1C]/45 bg-gradient-to-r from-[#EF4444]/20 to-[#B91C1C]/20 px-3 py-1.5 text-xs font-medium text-[#FCA5A5] hover:border-[#EF4444] transition"
                      >
                        <Volume2 className="h-3.5 w-3.5 text-[#EF4444]" />
                        Audition Voice
                      </button>
                    </div>

                    {/* Take Title Input */}
                    <div>
                      <label className="block text-[11px] font-medium uppercase tracking-wider text-[#FCA5A5] mb-1.5">
                        Take Title / Scene Marker
                      </label>
                      <input
                        type="text"
                        value={takeTitle}
                        onChange={(e) => setTakeTitle(e.target.value)}
                        placeholder="e.g., Latif Bugti Chapter 1 Intro — Personal Voice Clone Take"
                        className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3.5 py-2 text-xs font-medium text-[#FFF1F1] placeholder-[#FCA5A5]/40 focus:border-[#EF4444] focus:outline-none"
                      />
                    </div>

                    {/* Preset Script Pills */}
                    <div className="space-y-1.5">
                      <span className="text-[11px] text-[#FCA5A5]">
                        Load Latif Bugti Script Preset (English / Roman Urdu):
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {SCRIPT_PRESETS.map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              setTakeTitle(preset.title);
                              setPromptText(preset.text);
                            }}
                            className="rounded-lg border border-[#B91C1C]/35 bg-gradient-to-r from-[#EF4444]/15 to-[#B91C1C]/15 px-2.5 py-1 text-[11px] text-[#FFF1F1] hover:border-[#EF4444] transition"
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Main Script Textarea with Animated LATIF BUGTI Watermark */}
                    <div className="relative">
                      <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-15 select-none">
                        <span className="font-display text-3xl sm:text-5xl font-black tracking-widest uppercase animate-latif-bugti-text">
                          LATIF BUGTI
                        </span>
                      </div>
                      <textarea
                        rows={6}
                        value={promptText}
                        onChange={(e) => setPromptText(e.target.value)}
                        placeholder="Type or paste your English, Urdu, or Hindi voiceover script for Latif Bugti AI..."
                        className="relative z-10 w-full rounded-xl border border-[#B91C1C]/40 bg-[#090606]/85 p-4 text-sm leading-relaxed text-[#FFF1F1] placeholder-[#FCA5A5]/40 focus:border-[#EF4444] focus:ring-2 focus:ring-[#B91C1C]/25 focus:outline-none resize-y"
                      />
                      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-[#FCA5A5] font-mono-tech">
                        <span>
                          {promptText.length} characters • ~
                          {Math.max(
                            1,
                            Math.round(
                              promptText.trim().split(/\s+/).filter(Boolean)
                                .length / 2.6
                            )
                          )}
                          s estimated duration
                        </span>
                        <span className="text-[#FCA5A5]">Model: {modelId}</span>
                      </div>
                    </div>

                    {/* Primary Action Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#B91C1C]/25">
                      <button
                        type="button"
                        onClick={() => {
                          speakWithBrowserNeural({
                            text: promptText,
                            gender: selectedVoice?.gender || "Male",
                            pitchShift: selectedVoice?.pitchShift || 1.0,
                            speed,
                          });
                          showToast("Latif Bugti AI Live Speaking Script Out Loud!");
                        }}
                        className="inline-flex items-center gap-2 rounded-xl border border-[#B91C1C]/50 bg-gradient-to-r from-[#EF4444]/20 to-[#B91C1C]/20 px-4 py-2.5 text-xs font-semibold text-[#FCA5A5] hover:from-[#EF4444]/35 hover:to-[#B91C1C]/35 transition"
                      >
                        <Volume2 className="h-4 w-4 text-[#EF4444]" />
                        Instant Live Speak Preview
                      </button>

                      <button
                        type="button"
                        disabled={isSynthesizing || !promptText.trim()}
                        onClick={handleSynthesizeSpeech}
                        className="inline-flex items-center gap-2 rounded-xl animate-latif-bugti-bg px-6 py-3 text-xs sm:text-sm font-bold text-[#FFF1F1] border border-[#F87171]/50 hover:opacity-95 disabled:opacity-50 transition shadow-lg shadow-[#B91C1C]/30"
                      >
                        <Sparkles
                          className={`h-4 w-4 ${
                            isSynthesizing ? "animate-spin" : ""
                          }`}
                        />
                        {isSynthesizing
                          ? "Latif Bugti AI Synthesizing..."
                          : "Generate Speech & Save Take"}
                      </button>
                    </div>
                  </div>

                  {/* Recent Takes Feed right under editor */}
                  <div className="rounded-xl border border-[#B91C1C]/35 bg-gradient-to-br from-[#160709] via-[#0B0808] to-[#130608] p-5 sm:p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-display text-base font-bold animate-latif-bugti-text">
                          Recent Latif Bugti Generations
                        </h3>
                        <p className="text-xs text-[#FCA5A5]">
                          Click Play on any take to hear real spoken voice + animate the Red &amp; Black waveform
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveNav("history")}
                        className="text-xs font-semibold text-[#F87171] hover:underline"
                      >
                        View All ({generations.length}) →
                      </button>
                    </div>

                    {isLoading ? (
                      <div className="space-y-3">
                        {[1, 2, 3].map((n) => (
                          <div
                            key={n}
                            className="h-20 rounded-xl bg-[#0D0A0A] animate-pulse border border-[#B91C1C]/30"
                          />
                        ))}
                      </div>
                    ) : generations.length === 0 ? (
                      <div className="rounded-xl border border-dashed border-[#B91C1C]/35 p-8 text-center">
                        <p className="text-sm text-[#FCA5A5]">
                          No voice takes generated yet. Enter a script above and click Generate Speech!
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {generations.slice(0, 4).map((gen) => {
                          const v = voices.find((x) => x.id === gen.voiceId);
                          const isThisPlaying =
                            activeTrack?.id === `gen-${gen.id}` && isPlaying;
                          return (
                            <div
                              key={gen.id}
                              className={`rounded-xl border p-4 transition ${
                                isThisPlaying
                                  ? "border-[#B91C1C] bg-gradient-to-r from-[#24090D] to-[#100D0D] shadow-[0_0_25px_rgba(185,28,28,0.25)]"
                                  : "border-[#B91C1C]/25 bg-[#0B0808]/80 hover:border-[#EF4444]/50"
                              }`}
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex items-start gap-3 min-w-0">
                                  <button
                                    type="button"
                                    onClick={() => handlePlayGeneration(gen)}
                                    className={`mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition ${
                                      isThisPlaying
                                        ? "bg-gradient-to-br from-[#EF4444] to-[#7F1D1D] text-[#FFF1F1] shadow-lg"
                                        : "bg-[#090606] text-[#F87171] border border-[#B91C1C]/40 hover:bg-gradient-to-br hover:from-[#EF4444] hover:to-[#7F1D1D] hover:text-[#FFF1F1]"
                                    }`}
                                  >
                                    {isThisPlaying ? (
                                      <Pause className="h-4 w-4 fill-current" />
                                    ) : (
                                      <Play className="h-4 w-4 fill-current ml-0.5" />
                                    )}
                                  </button>

                                  <div className="min-w-0 space-y-1">
                                    <div className="flex flex-wrap items-center gap-2">
                                      <span className="text-xs font-bold text-[#FFF1F1]">
                                        {gen.title}
                                      </span>
                                      <span className="rounded-md bg-gradient-to-r from-[#EF4444]/25 to-[#B91C1C]/25 border border-[#B91C1C]/40 px-2 py-0.5 text-[10px] font-semibold text-[#FCA5A5]">
                                        {v?.name.split("—")[0].trim() || "Latif Bugti"}
                                      </span>
                                      <span className="font-mono-tech text-[10px] text-[#FCA5A5]">
                                        {(gen.durationMs / 1000).toFixed(1)}s •{" "}
                                        {gen.characterCount} chars
                                      </span>
                                    </div>
                                    <p className="text-xs text-[#FCD5D5]/85 line-clamp-2">
                                      &ldquo;{gen.promptText}&rdquo;
                                    </p>
                                  </div>
                                </div>

                                <div className="flex items-center gap-1.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => handleToggleGenFavorite(gen)}
                                    className={`rounded-lg p-1.5 transition ${
                                      gen.isFavorite
                                        ? "text-[#EF4444]"
                                        : "text-[#FCA5A5]/60 hover:text-[#F87171]"
                                    }`}
                                  >
                                    <Heart
                                      className={`h-4 w-4 ${
                                        gen.isFavorite ? "fill-current" : ""
                                      }`}
                                    />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteGeneration(gen.id)}
                                    className="rounded-lg p-1.5 text-[#FCA5A5]/60 hover:text-[#EF4444] transition"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right 5 Columns: Acoustic Parameter Inspector & Active Voice Card */}
                <div className="lg:col-span-5 xl:col-span-4 space-y-6">
                  {/* Selected Voice Profile Card */}
                  {selectedVoice && (
                    <div className="rounded-xl border border-[#B91C1C]/35 bg-gradient-to-br from-[#18070A] via-[#0C0909] to-[#140709] p-5 space-y-4">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#EF4444]/25 to-[#B91C1C]/25 border border-[#B91C1C]/40 px-2 py-0.5 text-[10px] font-mono-tech font-semibold uppercase text-[#FCA5A5]">
                            {selectedVoice.category} • {selectedVoice.qualityScore}% Match
                          </span>
                          <h3 className="font-display text-base font-bold animate-latif-bugti-text mt-1.5">
                            {selectedVoice.name}
                          </h3>
                          <p className="font-mono-tech text-[11px] text-[#EF4444]">
                            ID: {selectedVoice.elevenlabsVoiceId}
                          </p>
                          {renderCloneBadge(selectedVoice)}
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingVoice(selectedVoice);
                            setVoiceModalOpen(true);
                          }}
                          className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] p-2 text-[#FCA5A5] hover:border-[#EF4444] transition"
                          title="Calibrate Voice Profile"
                        >
                          <Edit3 className="h-4 w-4" />
                        </button>
                      </div>

                      <p className="text-xs text-[#FCD5D5]/85 leading-relaxed">
                        {selectedVoice.description}
                      </p>

                      <div className="flex flex-wrap gap-1.5">
                        {[
                          selectedVoice.gender,
                          selectedVoice.age,
                          selectedVoice.accent,
                          selectedVoice.useCase,
                        ].map((tag, i) => (
                          <span
                            key={i}
                            className="rounded-md bg-[#0C0909] border border-[#B91C1C]/30 px-2 py-0.5 text-[11px] text-[#FCA5A5]"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ElevenLabs Acoustic Parameter Inspector */}
                  <div className="rounded-xl border border-[#B91C1C]/35 bg-gradient-to-br from-[#160709] via-[#0C0909] to-[#130608] p-5 space-y-5">
                    <div className="flex items-center justify-between border-b border-[#B91C1C]/25 pb-3">
                      <div className="flex items-center gap-2">
                        <Sliders className="h-4 w-4 text-[#EF4444]" />
                        <h3 className="font-display text-sm font-bold text-[#FFF1F1]">
                          Latif Bugti Acoustic Inspector
                        </h3>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (selectedVoice) {
                            setStability(selectedVoice.defaultStability);
                            setSimilarityBoost(selectedVoice.defaultSimilarity);
                            setStyleExaggeration(selectedVoice.defaultStyle);
                            setSpeakerBoost(selectedVoice.speakerBoost);
                            setSpeed(1.0);
                            showToast("Reset sliders to Latif Bugti defaults");
                          }
                        }}
                        className="inline-flex items-center gap-1 text-[11px] text-[#FCA5A5] hover:text-[#EF4444]"
                      >
                        <RotateCcw className="h-3 w-3" />
                        Reset
                      </button>
                    </div>

                    {/* Model Selector */}
                    <div>
                      <label className="block text-xs font-medium text-[#FCA5A5] mb-1.5">
                        Latif Bugti / ElevenLabs Synthesis Model
                      </label>
                      <select
                        value={modelId}
                        onChange={(e) => setModelId(e.target.value)}
                        className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs font-medium text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
                      >
                        <option value="eleven_multilingual_v2">
                          Eleven Multilingual v2 (29 Languages • Best Quality)
                        </option>
                        <option value="eleven_turbo_v2_5">
                          Eleven Turbo v2.5 (Low Latency • High Precision)
                        </option>
                        <option value="eleven_flash_v2_5">
                          Eleven Flash v2.5 (Ultra-Fast 75ms Conversational)
                        </option>
                      </select>
                    </div>

                    {/* Slider 1: Stability */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#FCD5D5] font-medium">
                          Stability (Expressive ↔ Consistent)
                        </span>
                        <span className="font-mono-tech text-[#EF4444] font-semibold">
                          {Math.round(stability * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={stability}
                        onChange={(e) => setStability(parseFloat(e.target.value))}
                        className="w-full studio-slider"
                      />
                    </div>

                    {/* Slider 2: Similarity Boost */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#FCD5D5] font-medium">
                          Clarity + Similarity Boost
                        </span>
                        <span className="font-mono-tech text-[#F87171] font-semibold">
                          {Math.round(similarityBoost * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={similarityBoost}
                        onChange={(e) =>
                          setSimilarityBoost(parseFloat(e.target.value))
                        }
                        className="w-full studio-slider"
                      />
                    </div>

                    {/* Slider 3: Style Exaggeration */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#FCD5D5] font-medium">
                          Style Exaggeration
                        </span>
                        <span className="font-mono-tech text-[#FCA5A5]">
                          {Math.round(styleExaggeration * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={styleExaggeration}
                        onChange={(e) =>
                          setStyleExaggeration(parseFloat(e.target.value))
                        }
                        className="w-full studio-slider"
                      />
                    </div>

                    {/* Slider 4: Pacing / Speed */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#FCD5D5] font-medium">
                          Delivery Speed
                        </span>
                        <span className="font-mono-tech text-[#F87171]">
                          {speed.toFixed(2)}x
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.75"
                        max="1.35"
                        step="0.05"
                        value={speed}
                        onChange={(e) => setSpeed(parseFloat(e.target.value))}
                        className="w-full studio-slider"
                      />
                    </div>

                    {/* Speaker Boost Toggle (Zero White Background — Red & Black Mix) */}
                    <div className="flex items-center justify-between pt-2 border-t border-[#B91C1C]/25">
                      <div>
                        <p className="text-xs font-semibold text-[#FFF1F1]">
                          Speaker Boost
                        </p>
                        <p className="text-[11px] text-[#FCA5A5]">
                          Enhances Latif Bugti clone harmonic similarity
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSpeakerBoost((prev) => !prev)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${
                          speakerBoost
                            ? "bg-gradient-to-r from-[#EF4444] to-[#7F1D1D]"
                            : "bg-[#1B0C0E]"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-[#0B0808] border border-[#F87171] transition ${
                            speakerBoost ? "translate-x-6" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* VIEW 2: VOICE LAB & CLONES (Full CRUD) */}
            {activeNav === "voices" && (
              <div className="space-y-6">
                {/* Filter & Search Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-[#B91C1C]/35 bg-gradient-to-r from-[#160709] via-[#0C0909] to-[#140709] p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    {[
                      { id: "all", label: "All Voices" },
                      { id: "cloned", label: "Latif Bugti Clones" },
                      { id: "premade", label: "ElevenLabs Premade" },
                      { id: "designed", label: "Voice Design" },
                      { id: "favorites", label: "★ Favorites" },
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setVoiceCategoryFilter(tab.id)}
                        className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                          voiceCategoryFilter === tab.id
                            ? "bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] text-[#FFF1F1] font-semibold shadow-sm"
                            : "bg-[#0C0909] text-[#FCA5A5] hover:text-[#FFF1F1]"
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2.5">
                    <div className="relative flex-1 sm:w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#F87171]" />
                      <input
                        type="text"
                        value={voiceSearch}
                        onChange={(e) => setVoiceSearch(e.target.value)}
                        placeholder="Search Latif Bugti voices..."
                        className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] pl-8 pr-3 py-1.5 text-xs text-[#FFF1F1] placeholder-[#FCA5A5]/50 focus:border-[#EF4444] focus:outline-none"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={openCloneFlow}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-3.5 py-2 text-xs font-semibold text-[#FFF1F1] hover:opacity-95 transition shrink-0 shadow-lg"
                    >
                      <Plus className="h-4 w-4" />
                      New Voice Clone
                    </button>
                  </div>
                </div>

                {/* Voices Grid */}
                {filteredVoices.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-[#B91C1C]/35 bg-[#0C0909] p-12 text-center space-y-3">
                    <Mic className="h-8 w-8 text-[#EF4444] mx-auto" />
                    <h3 className="font-display text-base font-bold text-[#FFF1F1]">
                      No Matching Voice Profiles Found
                    </h3>
                    <p className="text-xs text-[#FCA5A5] max-w-md mx-auto">
                      Create a new Instant Latif Bugti Personal Voice Clone from microphone or reference audio samples.
                    </p>
                    <button
                      type="button"
                      onClick={openCloneFlow}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-4 py-2 text-xs font-semibold text-[#FFF1F1]"
                    >
                      <Plus className="h-4 w-4" />
                      Clone My Voice (Upload)
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                    {filteredVoices.map((voice) => {
                      const isAuditioning =
                        activeTrack?.id === `voice-preview-${voice.id}` &&
                        isPlaying;
                      return (
                        <div
                          key={voice.id}
                          className="rounded-xl border border-[#B91C1C]/35 bg-gradient-to-br from-[#18070A] via-[#0C0909] to-[#130608] p-5 flex flex-col justify-between gap-4 hover:border-[#EF4444] transition shadow-lg"
                        >
                          <div className="space-y-3">
                            {/* Top Badges & Actions */}
                            <div className="flex items-start justify-between gap-2">
                              <span className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#EF4444]/25 to-[#B91C1C]/25 border border-[#B91C1C]/40 px-2 py-0.5 font-mono-tech text-[10px] font-semibold uppercase text-[#FCA5A5]">
                                {voice.category} • {voice.sampleCount} samples
                              </span>

                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleToggleVoiceFavorite(voice)}
                                  className={`rounded-lg p-1.5 transition ${
                                    voice.isFavorite
                                      ? "text-[#EF4444]"
                                      : "text-[#FCA5A5]/60 hover:text-[#F87171]"
                                  }`}
                                >
                                  <Heart
                                    className={`h-4 w-4 ${
                                      voice.isFavorite ? "fill-current" : ""
                                    }`}
                                  />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingVoice(voice);
                                    setVoiceModalOpen(true);
                                  }}
                                  className="rounded-lg p-1.5 text-[#FCA5A5] hover:text-[#FFF1F1] transition"
                                  title="Edit Voice Calibration"
                                >
                                  <Edit3 className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteVoice(voice.id)}
                                  className="rounded-lg p-1.5 text-[#FCA5A5]/60 hover:text-[#EF4444] transition"
                                  title="Delete Voice"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>

                            <div>
                              <h3 className="font-display text-base font-bold text-[#FFF1F1]">
                                {voice.name}
                              </h3>
                              <p className="font-mono-tech text-[11px] text-[#EF4444] mt-0.5">
                                ElevenLabs ID: {voice.elevenlabsVoiceId}
                              </p>
                              {renderCloneBadge(voice)}
                            </div>

                            <p className="text-xs text-[#FCD5D5]/85 line-clamp-2 leading-relaxed">
                              {voice.description}
                            </p>

                            <div className="flex flex-wrap gap-1.5">
                              <span className="rounded bg-[#0A0707] border border-[#B91C1C]/25 px-2 py-0.5 text-[11px] text-[#FCA5A5]">
                                {voice.gender} • {voice.age}
                              </span>
                              <span className="rounded bg-[#0A0707] border border-[#B91C1C]/25 px-2 py-0.5 text-[11px] text-[#FCA5A5]">
                                {voice.accent}
                              </span>
                              <span className="rounded bg-[#18070A] border border-[#EF4444]/30 px-2 py-0.5 text-[11px] text-[#FCA5A5]">
                                {voice.useCase}
                              </span>
                            </div>
                          </div>

                          {/* Card Footer Actions */}
                          <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#B91C1C]/25">
                            <button
                              type="button"
                              onClick={() => handleAuditionVoice(voice)}
                              className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition ${
                                isAuditioning
                                  ? "border-[#B91C1C] bg-[#B91C1C]/25 text-[#FCA5A5]"
                                  : "border-[#B91C1C]/35 bg-[#0A0707] text-[#FFF1F1] hover:border-[#EF4444]"
                              }`}
                            >
                              {isAuditioning ? (
                                <Pause className="h-3.5 w-3.5" />
                              ) : (
                                <Play className="h-3.5 w-3.5" />
                              )}
                              {isAuditioning ? "Playing..." : "Audition"}
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                handleSelectVoiceForStudio(voice);
                                setActiveNav("synthesis");
                              }}
                              className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-3 py-2 text-xs font-semibold text-[#FFF1F1] hover:opacity-95 transition shadow"
                            >
                              <Wand2 className="h-3.5 w-3.5" />
                              Use in Studio
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* VIEW 3: GENERATION HISTORY (Full CRUD + Search + Filters) */}
            {activeNav === "history" && (
              <div className="space-y-6">
                {/* Filter Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#B91C1C]/35 bg-gradient-to-r from-[#160709] via-[#0C0909] to-[#140709] p-4">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <div className="relative w-60">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#F87171]" />
                      <input
                        type="text"
                        value={historySearch}
                        onChange={(e) => setHistorySearch(e.target.value)}
                        placeholder="Search prompt script or take title..."
                        className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] pl-8 pr-3 py-1.5 text-xs text-[#FFF1F1] placeholder-[#FCA5A5]/50 focus:border-[#EF4444] focus:outline-none"
                      />
                    </div>

                    <select
                      value={historyVoiceFilter}
                      onChange={(e) => setHistoryVoiceFilter(e.target.value)}
                      className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] px-3 py-1.5 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
                    >
                      <option value="all">All Voices</option>
                      {voices.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name}
                        </option>
                      ))}
                    </select>

                    <select
                      value={historyProjectFilter}
                      onChange={(e) => setHistoryProjectFilter(e.target.value)}
                      className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] px-3 py-1.5 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
                    >
                      <option value="all">All Projects</option>
                      {projects.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.title}
                        </option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => setHistoryFavoritesOnly((prev) => !prev)}
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition ${
                        historyFavoritesOnly
                          ? "border-[#EF4444] bg-[#EF4444]/20 text-[#FCA5A5]"
                          : "border-[#B91C1C]/35 bg-[#0C0909] text-[#FCA5A5]"
                      }`}
                    >
                      <Heart className="h-3.5 w-3.5" />
                      Favorites Only
                    </button>
                  </div>

                  <span className="font-mono-tech text-xs text-[#FCA5A5]">
                    Showing {filteredGenerations.length} of {generations.length} takes
                  </span>
                </div>

                {/* Generations List */}
                <div className="space-y-3">
                  {filteredGenerations.map((gen) => {
                    const v = voices.find((x) => x.id === gen.voiceId);
                    const proj = projects.find((p) => p.id === gen.projectId);
                    const isThisPlaying =
                      activeTrack?.id === `gen-${gen.id}` && isPlaying;

                    return (
                      <div
                        key={gen.id}
                        className={`rounded-xl border p-5 transition ${
                          isThisPlaying
                            ? "border-[#B91C1C] bg-gradient-to-r from-[#22080C] to-[#100D0D]"
                            : "border-[#B91C1C]/30 bg-gradient-to-r from-[#140709] to-[#0B0808] hover:border-[#EF4444]/60"
                        }`}
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex items-start gap-3.5 min-w-0 flex-1">
                            <button
                              type="button"
                              onClick={() => handlePlayGeneration(gen)}
                              className={`mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition ${
                                isThisPlaying
                                  ? "bg-gradient-to-br from-[#EF4444] to-[#7F1D1D] text-[#FFF1F1] shadow-lg"
                                  : "bg-[#0C0909] text-[#F87171] border border-[#B91C1C]/40 hover:bg-gradient-to-br hover:from-[#EF4444] hover:to-[#7F1D1D] hover:text-[#FFF1F1]"
                              }`}
                            >
                              {isThisPlaying ? (
                                <Pause className="h-5 w-5 fill-current" />
                              ) : (
                                <Play className="h-5 w-5 fill-current ml-0.5" />
                              )}
                            </button>

                            <div className="min-w-0 flex-1 space-y-1.5">
                              <div className="flex flex-wrap items-center gap-2">
                                {editingGenId === gen.id ? (
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={editingGenTitle}
                                      onChange={(e) =>
                                        setEditingGenTitle(e.target.value)
                                      }
                                      className="rounded border border-[#B91C1C] bg-[#090606] px-2.5 py-1 text-xs text-[#FFF1F1]"
                                    />
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleUpdateGeneration(gen.id, {
                                          title: editingGenTitle,
                                        })
                                      }
                                      className="rounded bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-2.5 py-1 text-xs font-semibold text-[#FFF1F1]"
                                    >
                                      Save
                                    </button>
                                  </div>
                                ) : (
                                  <span className="font-display text-sm font-bold text-[#FFF1F1]">
                                    {gen.title}
                                  </span>
                                )}

                                <span className="rounded-md bg-gradient-to-r from-[#EF4444]/25 to-[#B91C1C]/25 border border-[#B91C1C]/40 px-2 py-0.5 text-[11px] font-semibold text-[#FCA5A5]">
                                  {v?.name || "Latif Bugti Voice"}
                                </span>

                                {proj && (
                                  <span className="rounded-md bg-[#0C0909] border border-[#B91C1C]/30 px-2 py-0.5 text-[11px] text-[#FCA5A5]">
                                    {proj.title}
                                  </span>
                                )}

                                <span className="font-mono-tech text-[11px] text-[#FCA5A5]/70">
                                  Stab: {Math.round(gen.stability * 100)}% • Sim:{" "}
                                  {Math.round(gen.similarityBoost * 100)}% •{" "}
                                  {(gen.durationMs / 1000).toFixed(1)}s
                                </span>
                              </div>

                              <p className="text-xs text-[#FCD5D5]/85 leading-relaxed">
                                &ldquo;{gen.promptText}&rdquo;
                              </p>
                            </div>
                          </div>

                          {/* Right Actions */}
                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            <select
                              value={gen.projectId || ""}
                              onChange={(e) =>
                                handleUpdateGeneration(gen.id, {
                                  projectId: e.target.value
                                    ? Number(e.target.value)
                                    : null,
                                })
                              }
                              className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] px-2.5 py-1.5 text-[11px] text-[#FCA5A5] focus:border-[#EF4444] focus:outline-none"
                            >
                              <option value="">Assign Project...</option>
                              {projects.map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.title}
                                </option>
                              ))}
                            </select>

                            <button
                              type="button"
                              onClick={() => {
                                setEditingGenId(gen.id);
                                setEditingGenTitle(gen.title);
                              }}
                              className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] p-2 text-[#FCA5A5] hover:text-[#FFF1F1]"
                              title="Rename Take"
                            >
                              <Edit3 className="h-3.5 w-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleToggleGenFavorite(gen)}
                              className={`rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] p-2 ${
                                gen.isFavorite
                                  ? "text-[#EF4444]"
                                  : "text-[#FCA5A5] hover:text-[#FFF1F1]"
                              }`}
                            >
                              <Heart
                                className={`h-3.5 w-3.5 ${
                                  gen.isFavorite ? "fill-current" : ""
                                }`}
                              />
                            </button>
                            {gen.audioData.startsWith("data:audio/mpeg") ? (
                              <a
                                href={gen.audioData}
                                download={`${gen.title
                                  .toLowerCase()
                                  .replace(/[^a-z0-9]+/g, "-")}.mp3`}
                                className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] p-2 text-[#FCA5A5] hover:text-[#EF4444]"
                                title="Download MP3"
                              >
                                <Download className="h-3.5 w-3.5" />
                              </a>
                            ) : (
                              <span
                                className="cursor-not-allowed rounded-lg border border-[#B91C1C]/15 bg-[#0C0909] p-2 text-[#FCA5A5]/30"
                                title="Built-in live voice has no audio file. Add an ElevenLabs key to get downloadable MP3 takes."
                              >
                                <Download className="h-3.5 w-3.5" />
                              </span>
                            )}

                            <button
                              type="button"
                              onClick={() => handleDeleteGeneration(gen.id)}
                              className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] p-2 text-[#FCA5A5]/70 hover:text-[#EF4444]"
                              title="Delete Take"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* VIEW 4: STUDIO PROJECTS (Full CRUD) */}
            {activeNav === "projects" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between rounded-xl border border-[#B91C1C]/35 bg-gradient-to-r from-[#160709] via-[#0C0909] to-[#140709] p-4">
                  <div>
                    <h2 className="font-display text-base font-bold animate-latif-bugti-text">
                      Latif Bugti Multi-Take Production Projects
                    </h2>
                    <p className="text-xs text-[#FCA5A5]">
                      Organize audiobooks, YouTube voiceover pipelines, and bilingual podcast episodes
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingProject(null);
                      setProjectTitle("");
                      setProjectDescription("");
                      setProjectCategory("YouTube Automation");
                      setProjectLanguage("English & Urdu");
                      setProjectStatus("active");
                      setShowProjectForm(true);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-4 py-2 text-xs font-semibold text-[#FFF1F1] hover:opacity-95 transition shadow-lg"
                  >
                    <Plus className="h-4 w-4" />
                    New Latif Bugti Project
                  </button>
                </div>

                {showProjectForm && (
                  <form
                    onSubmit={handleSaveProject}
                    className="rounded-xl border border-[#B91C1C]/50 bg-gradient-to-br from-[#19070A] to-[#0D0A0A] p-5 space-y-4 shadow-xl"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-display text-sm font-bold text-[#FFF1F1]">
                        {editingProject
                          ? `Edit Project — ${editingProject.title}`
                          : "Create New Latif Bugti Project"}
                      </h3>
                      <button
                        type="button"
                        onClick={() => setShowProjectForm(false)}
                        className="text-[#FCA5A5] hover:text-[#EF4444]"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs text-[#FCA5A5] mb-1">
                          Project Title *
                        </label>
                        <input
                          type="text"
                          required
                          value={projectTitle}
                          onChange={(e) => setProjectTitle(e.target.value)}
                          placeholder="e.g., Latif Bugti Documentary Series"
                          className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-[#FCA5A5] mb-1">
                          Category
                        </label>
                        <select
                          value={projectCategory}
                          onChange={(e) => setProjectCategory(e.target.value)}
                          className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1]"
                        >
                          <option value="YouTube Automation">
                            YouTube Automation
                          </option>
                          <option value="Audiobook">Audiobook</option>
                          <option value="Podcast">Podcast</option>
                          <option value="Commercial">Commercial</option>
                          <option value="Course">E-Learning Course</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-[#FCA5A5] mb-1">
                          Target Language
                        </label>
                        <input
                          type="text"
                          value={projectLanguage}
                          onChange={(e) => setProjectLanguage(e.target.value)}
                          placeholder="English & Urdu"
                          className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs text-[#FCA5A5] mb-1">
                        Production Notes &amp; Synopsis
                      </label>
                      <textarea
                        rows={2}
                        value={projectDescription}
                        onChange={(e) => setProjectDescription(e.target.value)}
                        className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1]"
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setShowProjectForm(false)}
                        className="rounded-lg border border-[#B91C1C]/35 px-4 py-1.5 text-xs text-[#FCA5A5]"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-5 py-1.5 text-xs font-semibold text-[#FFF1F1]"
                      >
                        Save Project
                      </button>
                    </div>
                  </form>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {projects.map((proj) => {
                    const projectTakes = generations.filter(
                      (g) => g.projectId === proj.id
                    );
                    return (
                      <div
                        key={proj.id}
                        className="rounded-xl border border-[#B91C1C]/35 bg-gradient-to-br from-[#18070A] via-[#0C0909] to-[#130608] p-5 flex flex-col justify-between gap-4 hover:border-[#EF4444] transition"
                      >
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="rounded-md bg-gradient-to-r from-[#EF4444]/25 to-[#B91C1C]/25 border border-[#B91C1C]/40 px-2.5 py-0.5 text-[11px] font-semibold text-[#FCA5A5]">
                              {proj.category} • {proj.targetLanguage}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingProject(proj);
                                  setProjectTitle(proj.title);
                                  setProjectDescription(proj.description);
                                  setProjectCategory(proj.category);
                                  setProjectLanguage(proj.targetLanguage);
                                  setProjectStatus(proj.status);
                                  setShowProjectForm(true);
                                }}
                                className="rounded-lg p-1.5 text-[#FCA5A5] hover:text-[#FFF1F1]"
                              >
                                <Edit3 className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteProject(proj.id)}
                                className="rounded-lg p-1.5 text-[#FCA5A5]/70 hover:text-[#EF4444]"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>

                          <h3 className="font-display text-base font-bold text-[#FFF1F1]">
                            {proj.title}
                          </h3>
                          <p className="text-xs text-[#FCD5D5]/85 leading-relaxed">
                            {proj.description}
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-3 border-t border-[#B91C1C]/25">
                          <span className="font-mono-tech text-xs text-[#F87171] font-semibold">
                            {projectTakes.length} recorded audio take(s)
                          </span>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setHistoryProjectFilter(String(proj.id));
                                setActiveNav("history");
                              }}
                              className="rounded-lg border border-[#B91C1C]/35 bg-[#0A0707] px-3 py-1.5 text-xs text-[#FCA5A5] hover:border-[#EF4444]"
                            >
                              Inspect Takes
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedProjectId(proj.id);
                                setActiveNav("synthesis");
                              }}
                              className="rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-3 py-1.5 text-xs font-semibold text-[#FFF1F1]"
                            >
                              Record Take
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Modals */}
      <input
        ref={cloneFileInputRef}
        type="file"
        accept="audio/*,.mp3,.wav,.m4a,.ogg,.flac,.webm"
        multiple
        className="hidden"
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = "";
          if (files.length === 0) return;
          setEditingVoice(null);
          setPendingCloneFiles(files);
          setVoiceModalOpen(true);
        }}
      />

      <VoiceLabModal
        isOpen={voiceModalOpen}
        onClose={() => {
          setVoiceModalOpen(false);
          setPendingCloneFiles([]);
        }}
        editingVoice={editingVoice}
        initialFiles={pendingCloneFiles}
        onSave={handleSaveVoice}
      />

      <AuthSettingsModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        user={user}
        hasLiveElevenLabsKey={hasLiveElevenLabsKey}
        initialTab={authModalTab}
        onUpdateSettings={async (payload) => {
          const res = await fetch("/api/auth", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId: user?.id, ...payload }),
          });
          const data = await res.json();
          if (data.user) {
            setUser(data.user);
            setHasLiveElevenLabsKey(Boolean(data.user.hasPersonalApiKey));
          }
          if (data.importedCount > 0) {
            await fetchStudioData();
          }
          showToast(data.message || "Latif Bugti settings updated");
          return data.message || "Settings saved.";
        }}
        onAuthenticate={async (payload) => {
          const res = await fetch("/api/auth", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
          const data = await res.json();
          if (data.user) {
            setUser(data.user);
            setHasLiveElevenLabsKey(Boolean(data.user.hasPersonalApiKey));
          }
          showToast(data.message || "Signed in to Latif Bugti Studio");
        }}
      />

      {/* Persistent Bottom Waveform Player Bar */}
      <BottomWaveformPlayer
        track={activeTrack}
        isPlaying={isPlaying}
        onTogglePlay={() => setIsPlaying((prev) => !prev)}
      />
    </div>
  );
}
