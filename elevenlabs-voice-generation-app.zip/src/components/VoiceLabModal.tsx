"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { VoiceProfile } from "@/types/studio";
import {
  X,
  Mic,
  Square,
  Upload,
  Sparkles,
  CheckCircle2,
  Sliders,
  Volume2,
  Radio,
  Trash2,
  AlertTriangle,
  Loader2,
} from "lucide-react";
import { speakWithBrowserNeural } from "@/lib/browser-speech";
import {
  analyzeVoiceSample,
  convertBlobToWavFile,
  pitchToVoiceProfile,
} from "@/lib/pitch-analysis";

export interface VoiceFormPayload {
  name: string;
  category: string;
  elevenlabsVoiceId: string;
  accent: string;
  gender: string;
  age: string;
  useCase: string;
  description: string;
  defaultStability: number;
  defaultSimilarity: number;
  defaultStyle: number;
  pitchShift: number;
  speakerBoost: boolean;
  sampleCount: number;
  sampleScript: string;
  samples: File[];
  measuredPitchHz: number | null;
}

interface VoiceLabModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingVoice: VoiceProfile | null;
  /** Audio files the user already picked from their PC (before the modal opened). */
  initialFiles?: File[];
  onSave: (voiceData: VoiceFormPayload) => Promise<boolean>;
}

interface VoiceSample {
  id: string;
  name: string;
  file: File;
  source: "upload" | "mic";
  url: string;
  durationSec: number | null;
  pitchHz: number | null;
  analyzing: boolean;
}

const MAX_SAMPLES = 3;
const MAX_FILE_BYTES = 12 * 1024 * 1024;
const MAX_RECORD_SECONDS = 120;

const ELEVENLABS_PRESET_IDS = [
  { label: "Adam — Stock Male (pNInz6...)", id: "pNInz6obpgDQGcFmaJgB", gender: "Male" },
  { label: "Rachel — Studio Narrator (21m00T...)", id: "21m00Tcm4TlvDq8ikWAM", gender: "Female" },
  { label: "Bella — Expressive (EXAVIT...)", id: "EXAVITQu4vr4xnSDxMaL", gender: "Female" },
  { label: "Marcus — Deep Baritone (onwK4e...)", id: "onwK4e9ZLuTAKqWW03F9", gender: "Male" },
  { label: "Antoni — Warm (ErXwob...)", id: "ErXwobaYiN019PkySvjV", gender: "Male" },
];

const READ_ALOUD_SCRIPT =
  "Assalam-o-Alaikum! Mera naam Latif Bugti hai. Today I am recording my voice sample in a quiet room. I speak slowly and clearly, with natural emotion, so that my cloned voice sounds exactly like me — chahe English ho ya Urdu.";

export default function VoiceLabModal({
  isOpen,
  onClose,
  editingVoice,
  initialFiles,
  onSave,
}: VoiceLabModalProps) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("cloned");
  const [elevenlabsVoiceId, setElevenlabsVoiceId] = useState("pNInz6obpgDQGcFmaJgB");
  const [accent, setAccent] = useState("Urdu / International English");
  const [gender, setGender] = useState("Male");
  const [age, setAge] = useState("Young");
  const [useCase, setUseCase] = useState("Personal Voice Clone");
  const [description, setDescription] = useState("");
  const [defaultStability, setDefaultStability] = useState(0.55);
  const [defaultSimilarity, setDefaultSimilarity] = useState(0.85);
  const [defaultStyle, setDefaultStyle] = useState(0.2);
  const [pitchShift, setPitchShift] = useState(1.0);
  const [speakerBoost, setSpeakerBoost] = useState(true);
  const [sampleScript, setSampleScript] = useState(
    "Assalam-o-Alaikum! Main Latif Bugti hoon, aur yeh meri apni cloned awaaz hai."
  );
  const [samples, setSamples] = useState<VoiceSample[]>([]);
  const [measuredPitchHz, setMeasuredPitchHz] = useState<number | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [sampleError, setSampleError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const samplesRef = useRef<VoiceSample[]>([]);
  samplesRef.current = samples;
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const initialFilesRef = useRef<File[]>([]);
  initialFilesRef.current = initialFiles ?? [];
  const [dragActive, setDragActive] = useState(false);

  const releaseMic = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  const clearSamples = useCallback(() => {
    samplesRef.current.forEach((s) => URL.revokeObjectURL(s.url));
    samplesRef.current = []; // keep the ref in sync immediately (before the next render)
    setSamples([]);
    setMeasuredPitchHz(null);
  }, []);

  // Reset the form whenever the modal opens for a different voice.
  useEffect(() => {
    clearSamples();
    setSampleError(null);
    setIsRecording(false);
    setRecordingSeconds(0);
    if (editingVoice) {
      setName(editingVoice.name);
      setCategory(editingVoice.category);
      setElevenlabsVoiceId(editingVoice.elevenlabsVoiceId);
      setAccent(editingVoice.accent);
      setGender(editingVoice.gender);
      setAge(editingVoice.age);
      setUseCase(editingVoice.useCase);
      setDescription(editingVoice.description);
      setDefaultStability(editingVoice.defaultStability);
      setDefaultSimilarity(editingVoice.defaultSimilarity);
      setDefaultStyle(editingVoice.defaultStyle);
      setPitchShift(editingVoice.pitchShift);
      setSpeakerBoost(editingVoice.speakerBoost);
      setMeasuredPitchHz(editingVoice.measuredPitchHz ?? null);
    } else {
      setName("");
      setCategory("cloned");
      setElevenlabsVoiceId("pNInz6obpgDQGcFmaJgB");
      setAccent("Urdu / International English");
      setGender("Male");
      setAge("Young");
      setUseCase("Personal Voice Clone");
      setDescription(
        "My personal voice clone created from my own uploaded voice samples."
      );
      setDefaultStability(0.55);
      setDefaultSimilarity(0.86);
      setDefaultStyle(0.22);
      setPitchShift(1.0);
      setSpeakerBoost(true);
    }
    // Files chosen from the PC before the modal opened (sidebar "Clone My Voice" button)
    if (isOpen && initialFilesRef.current.length > 0) {
      void addSamples(initialFilesRef.current, "upload");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingVoice, isOpen]);

  // Recording timer + hard stop
  useEffect(() => {
    if (!isRecording) return;
    const interval = setInterval(() => {
      setRecordingSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isRecording]);

  useEffect(() => {
    if (isRecording && recordingSeconds >= MAX_RECORD_SECONDS) {
      recorderRef.current?.stop();
      setIsRecording(false);
    }
  }, [isRecording, recordingSeconds]);

  // Stop mic + free object URLs when unmounting
  useEffect(() => {
    return () => {
      try {
        if (recorderRef.current && recorderRef.current.state !== "inactive") {
          recorderRef.current.stop();
        }
      } catch {
        /* ignore */
      }
      streamRef.current?.getTracks().forEach((t) => t.stop());
      samplesRef.current.forEach((s) => URL.revokeObjectURL(s.url));
    };
  }, []);

  // Keep the aggregate measured pitch in sync with the samples
  useEffect(() => {
    const pitches = samples
      .map((s) => s.pitchHz)
      .filter((p): p is number => typeof p === "number");
    if (pitches.length === 0) return;
    pitches.sort((a, b) => a - b);
    setMeasuredPitchHz(pitches[Math.floor(pitches.length / 2)]);
  }, [samples]);

  const applyPitchProfile = (hz: number) => {
    const profile = pitchToVoiceProfile(hz);
    setGender(profile.gender);
    setPitchShift(profile.pitchShift);
  };

  const addSamples = async (files: File[], source: "upload" | "mic") => {
    setSampleError(null);
    const room = MAX_SAMPLES - samplesRef.current.length;
    if (room <= 0) {
      setSampleError(`Maximum ${MAX_SAMPLES} samples. Remove one to add another.`);
      return;
    }
    const accepted = files.slice(0, room).filter((f) => {
      if (f.size > MAX_FILE_BYTES) {
        setSampleError(`"${f.name}" is larger than 12 MB.`);
        return false;
      }
      return true;
    });

    for (const file of accepted) {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const url = URL.createObjectURL(file);
      setSamples((prev) => [
        ...prev,
        {
          id,
          name: file.name,
          file,
          source,
          url,
          durationSec: null,
          pitchHz: null,
          analyzing: true,
        },
      ]);
      try {
        const analysis = await analyzeVoiceSample(file);
        setSamples((prev) =>
          prev.map((s) =>
            s.id === id
              ? {
                  ...s,
                  durationSec: analysis.durationSec,
                  pitchHz: analysis.pitchHz,
                  analyzing: false,
                }
              : s
          )
        );
        if (analysis.pitchHz) applyPitchProfile(analysis.pitchHz);
      } catch {
        setSamples((prev) =>
          prev.map((s) => (s.id === id ? { ...s, analyzing: false } : s))
        );
        setSampleError(
          `Could not read "${file.name}" in this browser. Try a WAV or MP3 file.`
        );
      }
    }
  };

  // Opens the operating system file picker (the user's PC) to choose a voice file.
  const openFilePicker = () => {
    if (samplesRef.current.length >= MAX_SAMPLES) {
      setSampleError(`Maximum ${MAX_SAMPLES} samples. Remove one to add another.`);
      return;
    }
    setSampleError(null);
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files ? Array.from(e.target.files) : [];
    e.target.value = "";
    if (list.length) void addSamples(list, "upload");
  };

  const startRecording = async () => {
    setSampleError(null);
    if (
      typeof MediaRecorder === "undefined" ||
      !navigator.mediaDevices?.getUserMedia
    ) {
      setSampleError(
        "This browser can't record from the microphone. Please upload an audio file instead."
      );
      return;
    }
    if (samplesRef.current.length >= MAX_SAMPLES) {
      setSampleError(`Maximum ${MAX_SAMPLES} samples. Remove one first.`);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: true },
      });
      streamRef.current = stream;
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        releaseMic();
        const blob = new Blob(chunksRef.current, {
          type: recorder.mimeType || "audio/webm",
        });
        if (blob.size === 0) return;
        try {
          // Convert to WAV so every backend/browser accepts it.
          const wav = await convertBlobToWavFile(
            blob,
            `mic-recording-${new Date().toISOString().slice(11, 19).replace(/:/g, "")}.wav`
          );
          await addSamples([wav], "mic");
        } catch {
          setSampleError("Recording could not be processed. Please try again.");
        }
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecordingSeconds(0);
      setIsRecording(true);
    } catch {
      releaseMic();
      setSampleError(
        "Microphone permission was denied. Allow mic access in your browser, or upload an audio file."
      );
    }
  };

  const stopRecording = () => {
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const removeSample = (id: string) => {
    setSamples((prev) => {
      const target = prev.find((s) => s.id === id);
      if (target) URL.revokeObjectURL(target.url);
      return prev.filter((s) => s.id !== id);
    });
  };

  const handlePreviewTest = () => {
    speakWithBrowserNeural({
      text: sampleScript || `Hello, I am ${name || "your new voice clone"}.`,
      gender,
      pitchShift,
      speed: 1.0,
    });
  };

  const isCloneCategory = category === "cloned";
  const needsSample = isCloneCategory && !editingVoice && samples.length === 0;
  const stillAnalyzing = samples.some((s) => s.analyzing);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || needsSample || stillAnalyzing || isRecording) return;
    setIsSubmitting(true);
    try {
      const saved = await onSave({
        name: name.trim(),
        category,
        elevenlabsVoiceId: elevenlabsVoiceId.trim() || "pNInz6obpgDQGcFmaJgB",
        accent: accent.trim(),
        gender,
        age,
        useCase,
        description: description.trim(),
        defaultStability,
        defaultSimilarity,
        defaultStyle,
        pitchShift,
        speakerBoost,
        sampleCount: samples.length,
        sampleScript,
        samples: isCloneCategory ? samples.map((s) => s.file) : [],
        measuredPitchHz,
      });
      if (saved) onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const formatDuration = (sec: number | null) =>
    sec === null ? "…" : `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, "0")}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-xl border border-[#B91C1C]/40 bg-gradient-to-br from-[#160709] via-[#0B0808] to-[#120608] shadow-[0_0_50px_rgba(185,28,28,0.2)] overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#B91C1C]/30 bg-[#0C0909] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[#EF4444]/30 to-[#B91C1C]/30 border border-[#B91C1C]/50 text-[#F87171]">
              <Mic className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-[#FFF1F1]">
                {editingVoice
                  ? `Calibrate Voice — ${editingVoice.name}`
                  : "Clone Your Voice — Upload or Record"}
              </h2>
              <p className="text-xs text-[#FCA5A5]">
                Apni awaaz ka sample do, phir usi cloned voice se koi bhi script generate karo
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-[#FCA5A5] hover:bg-[#B91C1C]/15 hover:text-[#FFF1F1] transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*,.mp3,.wav,.m4a,.ogg,.flac,.webm"
            multiple
            onChange={handleFileChange}
            className="hidden"
          />

          {/* Category Selector */}
          <div className="grid grid-cols-3 gap-2.5">
            {[
              { id: "cloned", title: "My Voice Clone", sub: "Click → pick audio from my PC" },
              { id: "designed", title: "Voice Design", sub: "Custom timbre & pitch" },
              { id: "premade", title: "ElevenLabs Premade", sub: "Official voice ID link" },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setCategory(item.id);
                  if (item.id === "cloned") openFilePicker();
                }}
                className={`flex flex-col items-start rounded-lg border p-3 text-left transition ${
                  category === item.id
                    ? "border-[#B91C1C] bg-gradient-to-br from-[#EF4444]/15 to-[#B91C1C]/15 text-[#FFF1F1]"
                    : "border-[#B91C1C]/25 bg-[#0B0808] text-[#FCA5A5] hover:border-[#EF4444]/50"
                }`}
              >
                <span className="text-xs font-semibold">{item.title}</span>
                <span className="text-[11px] text-[#FCA5A5]/60 mt-0.5">{item.sub}</span>
              </button>
            ))}
          </div>

          {/* Clone samples — the real cloning input */}
          {isCloneCategory && (
            <div className="rounded-xl border border-[#B91C1C]/40 bg-[#090606] p-4 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Radio className="h-4 w-4 text-[#EF4444]" />
                  <span className="text-xs font-semibold text-[#FFF1F1]">
                    Your Voice Samples ({samples.length}/{MAX_SAMPLES})
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {isRecording ? (
                    <button
                      type="button"
                      onClick={stopRecording}
                      className="flex items-center gap-1.5 rounded-lg bg-[#EF4444] px-3 py-1.5 text-xs font-bold text-[#FFF1F1] animate-pulse"
                    >
                      <Square className="h-3.5 w-3.5 fill-current" />
                      Stop & Save ({Math.floor(recordingSeconds / 60)}:
                      {String(recordingSeconds % 60).padStart(2, "0")})
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={startRecording}
                      className="flex items-center gap-1.5 rounded-lg border border-[#EF4444]/50 bg-[#EF4444]/15 px-3 py-1.5 text-xs font-medium text-[#FCA5A5] hover:bg-[#EF4444]/25 transition"
                    >
                      <Mic className="h-3.5 w-3.5" />
                      Record With Mic
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={openFilePicker}
                    className="flex items-center gap-1.5 rounded-lg border border-[#EF4444]/60 bg-[#EF4444]/15 px-3 py-1.5 text-xs font-medium text-[#FCA5A5] hover:bg-[#EF4444]/30 transition"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    <span>Choose File From PC</span>
                  </button>
                </div>
              </div>

              {samples.length < MAX_SAMPLES && !isRecording && (
                <div
                  role="button"
                  tabIndex={0}
                  onClick={openFilePicker}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      openFilePicker();
                    }
                  }}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragActive(false);
                    const dropped = Array.from(e.dataTransfer.files).filter(
                      (f) =>
                        f.type.startsWith("audio/") ||
                        /\.(mp3|wav|m4a|ogg|flac|webm)$/i.test(f.name)
                    );
                    if (dropped.length) void addSamples(dropped, "upload");
                    else
                      setSampleError(
                        "Please drop an audio file (MP3, WAV, M4A, OGG or FLAC)."
                      );
                  }}
                  className={`flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed px-4 py-6 text-center transition ${
                    dragActive
                      ? "border-[#EF4444] bg-[#EF4444]/20"
                      : "border-[#EF4444]/45 bg-[#0A0A0A] hover:border-[#EF4444] hover:bg-[#EF4444]/10"
                  }`}
                >
                  <Upload className="h-6 w-6 text-[#EF4444]" />
                  <p className="text-sm font-semibold text-[#FFF1F1]">
                    Click karke apne PC se apni awaaz chunein
                  </p>
                  <p className="text-[11px] text-[#FCA5A5]/80">
                    ya audio file yahan drag &amp; drop karein • MP3, WAV, M4A, OGG, FLAC
                  </p>
                </div>
              )}

              {isRecording && (
                <div className="rounded-lg border border-[#EF4444]/40 bg-[#1A080B] p-3 space-y-1.5">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-[#FCA5A5]">
                    ● Recording — yeh script awaaz mein parhein:
                  </p>
                  <p className="text-xs leading-relaxed text-[#FFF1F1]">{READ_ALOUD_SCRIPT}</p>
                </div>
              )}

              {samples.length === 0 && !isRecording && (
                <p className="text-[11px] leading-relaxed text-[#FCA5A5]/80">
                  Tip: 1–2 minute ki saaf awaaz (shor ke baghair, ek hi speaker) upload ya record karein.
                  Behtar sample = behtar clone. Max {MAX_SAMPLES} files, har file 12 MB tak.
                </p>
              )}

              {sampleError && (
                <div className="flex items-start gap-2 rounded-lg border border-[#EF4444]/50 bg-[#EF4444]/10 px-3 py-2 text-xs text-[#FCA5A5]">
                  <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{sampleError}</span>
                </div>
              )}

              {samples.length > 0 && (
                <ul className="space-y-2">
                  {samples.map((s) => (
                    <li
                      key={s.id}
                      className="rounded-lg border border-[#B91C1C]/30 bg-[#0C0909] p-2.5 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex min-w-0 items-center gap-2">
                          {s.analyzing ? (
                            <Loader2 className="h-4 w-4 shrink-0 animate-spin text-[#F87171]" />
                          ) : (
                            <CheckCircle2 className="h-4 w-4 shrink-0 text-[#F87171]" />
                          )}
                          <span className="truncate font-mono-tech text-[11px] text-[#FFF1F1]">
                            {s.name}
                          </span>
                        </div>
                        <div className="flex shrink-0 items-center gap-3">
                          <span className="font-mono-tech text-[10px] text-[#FCA5A5]">
                            {s.analyzing
                              ? "analyzing…"
                              : `${formatDuration(s.durationSec)} • ${
                                  s.pitchHz ? `${s.pitchHz} Hz` : "pitch n/a"
                                }`}
                          </span>
                          <button
                            type="button"
                            onClick={() => removeSample(s.id)}
                            className="text-[#FCA5A5]/70 hover:text-[#EF4444]"
                            title="Remove sample"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <audio controls src={s.url} className="h-8 w-full" />
                    </li>
                  ))}
                </ul>
              )}

              {measuredPitchHz && (
                <div className="rounded-lg border border-[#B91C1C]/40 bg-gradient-to-r from-[#EF4444]/10 to-[#B91C1C]/10 px-3 py-2 text-[11px] text-[#FCD5D5]">
                  Detected voice pitch:{" "}
                  <strong className="text-[#F87171]">{measuredPitchHz} Hz</strong> →{" "}
                  <strong className="text-[#FCA5A5]">{gender}</strong>, pitch{" "}
                  <strong className="text-[#F87171]">{pitchShift.toFixed(2)}x</strong>{" "}
                  (auto-matched to your sample)
                </div>
              )}

              <p className="text-[11px] leading-relaxed text-[#FCA5A5]/75">
                Asli cloning ElevenLabs par hoti hai — iske liye aapki ElevenLabs API key (paid plan) chahiye.
                Key ke baghair sample save ho kar sirf pitch-match profile banta hai, jise baad mein
                &ldquo;Upgrade to real clone&rdquo; se asli clone bana sakte hain.
              </p>
            </div>
          )}

          {/* Primary Metadata */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#FCA5A5] mb-1.5">
                Voice Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Latif Bugti — My Real Voice"
                className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3.5 py-2.5 text-sm text-[#FFF1F1] placeholder-[#FCA5A5]/40 focus:border-[#EF4444] focus:outline-none"
              />
            </div>

            {!isCloneCategory && (
              <div>
                <label className="block text-xs font-medium text-[#FCA5A5] mb-1.5">
                  ElevenLabs Voice ID
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={elevenlabsVoiceId}
                    onChange={(e) => setElevenlabsVoiceId(e.target.value)}
                    placeholder="21m00Tcm4TlvDq8ikWAM"
                    className="w-full font-mono-tech rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2.5 text-xs text-[#FCA5A5] focus:border-[#EF4444] focus:outline-none"
                  />
                  <select
                    onChange={(e) => {
                      if (e.target.value) {
                        setElevenlabsVoiceId(e.target.value);
                        const found = ELEVENLABS_PRESET_IDS.find(
                          (p) => p.id === e.target.value
                        );
                        if (found) setGender(found.gender);
                      }
                    }}
                    value=""
                    className="rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] px-2 text-xs text-[#FCA5A5] focus:border-[#EF4444] focus:outline-none"
                  >
                    <option value="">Presets</option>
                    {ELEVENLABS_PRESET_IDS.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-medium text-[#FCA5A5] mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Neutral">Neutral</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#FCA5A5] mb-1">Age Profile</label>
              <select
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
              >
                <option value="Young">Young</option>
                <option value="Middle-Aged">Middle-Aged</option>
                <option value="Mature">Mature</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#FCA5A5] mb-1">Accent</label>
              <input
                type="text"
                value={accent}
                onChange={(e) => setAccent(e.target.value)}
                className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#FCA5A5] mb-1">Use Case</label>
              <select
                value={useCase}
                onChange={(e) => setUseCase(e.target.value)}
                className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3 py-2 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
              >
                <option value="Personal Voice Clone">Personal Voice Clone</option>
                <option value="YouTube & Reels">YouTube & Reels</option>
                <option value="Narration & Audiobooks">Narration & Audiobooks</option>
                <option value="Podcast Host">Podcast Host</option>
                <option value="Documentary & Trailers">Documentary & Trailers</option>
                <option value="Conversational AI">Conversational AI</option>
              </select>
            </div>
          </div>

          {/* Acoustic defaults */}
          <div className="rounded-xl border border-[#B91C1C]/30 bg-[#0B0808] p-4 space-y-4">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-[#FFF1F1]">
                <Sliders className="h-3.5 w-3.5 text-[#EF4444]" />
                Default Voice Settings
              </span>
              <button
                type="button"
                onClick={handlePreviewTest}
                className="flex items-center gap-1.5 rounded-lg border border-[#B91C1C]/50 bg-gradient-to-r from-[#EF4444]/15 to-[#B91C1C]/15 px-3 py-1 text-xs font-medium text-[#FCA5A5] hover:border-[#EF4444] transition"
              >
                <Volume2 className="h-3.5 w-3.5 text-[#EF4444]" />
                Quick Pitch Test
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { label: "Stability", value: defaultStability, set: setDefaultStability, min: 0, max: 1, fmt: (v: number) => `${Math.round(v * 100)}%` },
                { label: "Similarity Boost", value: defaultSimilarity, set: setDefaultSimilarity, min: 0, max: 1, fmt: (v: number) => `${Math.round(v * 100)}%` },
                { label: "Style Exaggeration", value: defaultStyle, set: setDefaultStyle, min: 0, max: 1, fmt: (v: number) => `${Math.round(v * 100)}%` },
                { label: "Pitch / Timbre", value: pitchShift, set: setPitchShift, min: 0.6, max: 1.5, fmt: (v: number) => `${v.toFixed(2)}x` },
              ].map((s) => (
                <div key={s.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#FCD5D5]">{s.label}</span>
                    <span className="font-mono-tech text-[#F87171]">{s.fmt(s.value)}</span>
                  </div>
                  <input
                    type="range"
                    min={s.min}
                    max={s.max}
                    step="0.01"
                    value={s.value}
                    onChange={(e) => s.set(parseFloat(e.target.value))}
                    className="w-full studio-slider"
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#FCA5A5] mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3.5 py-2 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
            />
          </div>

          {!editingVoice && (
            <div>
              <label className="block text-xs font-medium text-[#FCA5A5] mb-1">
                Preview line (spoken in the new voice after cloning)
              </label>
              <input
                type="text"
                value={sampleScript}
                onChange={(e) => setSampleScript(e.target.value)}
                className="w-full rounded-lg border border-[#B91C1C]/35 bg-[#090606] px-3.5 py-2 text-xs text-[#FFF1F1] focus:border-[#EF4444] focus:outline-none"
              />
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#B91C1C]/25">
            <span className="text-[11px] text-[#FCA5A5]">
              {needsSample
                ? "Clone ke liye kam az kam 1 voice sample upload ya record karein."
                : stillAnalyzing
                ? "Sample analyze ho raha hai…"
                : isRecording
                ? "Pehle recording stop karein."
                : ""}
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-[#B91C1C]/35 bg-transparent px-4 py-2 text-xs font-medium text-[#FCA5A5] hover:bg-[#B91C1C]/10 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || needsSample || stillAnalyzing || isRecording}
                className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-5 py-2 text-xs font-semibold text-[#FFF1F1] hover:opacity-95 disabled:opacity-50 transition shadow-lg"
              >
                {isSubmitting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="h-4 w-4" />
                )}
                {isSubmitting
                  ? "Uploading & cloning…"
                  : editingVoice
                  ? samples.length > 0
                    ? "Save & Re-clone From New Sample"
                    : "Save Voice Settings"
                  : isCloneCategory
                  ? "Clone My Voice"
                  : "Create Voice"}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
