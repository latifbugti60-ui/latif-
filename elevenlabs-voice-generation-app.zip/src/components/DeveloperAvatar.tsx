"use client";

import React, { useEffect, useRef, useState } from "react";
import { X, Camera, Loader2, Trash2 } from "lucide-react";

const STATIC_FALLBACK = "/developer.jpg";
const MAX_DIMENSION = 1000;

async function fileToResizedDataUri(file: File): Promise<string> {
  const bitmapUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("Could not read image"));
      el.src = bitmapUrl;
    });
    const scale = Math.min(1, MAX_DIMENSION / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.88);
  } finally {
    URL.revokeObjectURL(bitmapUrl);
  }
}

export default function DeveloperAvatar() {
  const [name, setName] = useState("Latif Bugti");
  const [avatarData, setAvatarData] = useState<string | null>(null);
  const [staticFailed, setStaticFailed] = useState(false);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/profile")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (cancelled || !data) return;
        if (typeof data.avatarData === "string") setAvatarData(data.avatarData);
        if (typeof data.name === "string") {
          setName(data.name.replace(/\s*\(.*\)\s*$/, "").trim() || "Latif Bugti");
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const src = avatarData ?? (staticFailed ? null : STATIC_FALLBACK);
  const initials = name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const persist = async (value: string | null) => {
    setSaving(true);
    setError(null);
    const previous = avatarData;
    setAvatarData(value); // optimistic
    try {
      const res = await fetch("/api/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarData: value }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.error || "Could not save photo");
      }
    } catch (err) {
      setAvatarData(previous);
      setError(err instanceof Error ? err.message : "Could not save photo");
    } finally {
      setSaving(false);
    }
  };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file (JPG, PNG or WebP).");
      return;
    }
    try {
      const dataUri = await fileToResizedDataUri(file);
      await persist(dataUri);
    } catch {
      setError("Could not read this image. Try another photo.");
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        title={`${name} — Developer`}
        aria-label="Open developer photo"
        className="group relative h-10 w-10 shrink-0 rounded-full p-[2px] animate-latif-bugti-bg shadow-[0_0_14px_rgba(185,28,28,0.5)] transition hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F87171]"
      >
        <span className="flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-[#0B0808]">
          {src ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={src}
              alt={`${name} — developer`}
              onError={() => {
                if (!avatarData) setStaticFailed(true);
              }}
              className="h-full w-full object-cover object-[50%_22%]"
            />
          ) : (
            <span className="font-display text-xs font-extrabold text-[#F87171]">
              {initials}
            </span>
          )}
        </span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 p-4 backdrop-blur-md"
          onClick={() => setOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Developer photo"
        >
          <div
            className="relative w-full max-w-md overflow-hidden rounded-2xl border border-[#B91C1C]/50 bg-gradient-to-br from-[#1A080B] via-[#0D0A0A] to-[#150709] shadow-[0_0_60px_rgba(239,68,68,0.25),0_0_60px_rgba(185,28,28,0.25)]"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="absolute right-3 top-3 z-10 rounded-full bg-black/60 p-1.5 text-[#FFF1F1] hover:bg-[#EF4444]/80 transition"
              aria-label="Close photo"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="flex max-h-[68vh] min-h-[260px] items-center justify-center bg-[#080505]">
              {src ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={src}
                  alt={`${name} — developer`}
                  className="max-h-[68vh] w-full object-contain"
                />
              ) : (
                <div className="flex flex-col items-center gap-3 p-10 text-center">
                  <span className="flex h-28 w-28 items-center justify-center rounded-full animate-latif-bugti-bg font-display text-4xl font-black text-[#FFF1F1]">
                    {initials}
                  </span>
                  <p className="text-xs leading-relaxed text-[#FCA5A5]">
                    Photo abhi upload nahi hui. Neeche &ldquo;Upload my photo&rdquo; dabayein — ek baar
                    save hone ke baad header mein hamesha nazar aayegi.
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-3 p-4">
              <div className="text-center">
                <p className="font-display text-lg font-extrabold animate-latif-bugti-text">
                  {name}
                </p>
                <p className="text-xs text-[#FCA5A5]">Developer &amp; Creator — Latif AI Studio</p>
              </div>

              {error && (
                <p className="rounded-lg border border-[#EF4444]/50 bg-[#EF4444]/10 px-3 py-2 text-center text-xs text-[#FCA5A5]">
                  {error}
                </p>
              )}

              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => fileRef.current?.click()}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-4 py-2 text-xs font-semibold text-[#FFF1F1] hover:opacity-95 disabled:opacity-50 transition"
                >
                  {saving ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Camera className="h-4 w-4" />
                  )}
                  {avatarData ? "Change photo" : "Upload my photo"}
                </button>
                {avatarData && (
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => persist(null)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#B91C1C]/35 px-3 py-2 text-xs font-medium text-[#FCA5A5] hover:border-[#EF4444] disabled:opacity-50 transition"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Remove
                  </button>
                )}
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleFile}
                  className="hidden"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
