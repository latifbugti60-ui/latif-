"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { ActiveTrack } from "@/types/studio";
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Download,
  Sparkles,
  Radio,
} from "lucide-react";
import {
  speakWithBrowserNeural,
  stopBrowserSpeech,
} from "@/lib/browser-speech";

interface BottomWaveformPlayerProps {
  track: ActiveTrack | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
}

/**
 * Two playback paths, never mixed:
 *  - ElevenLabs MP3 tracks  -> plain <audio> element.
 *  - Built-in engine tracks -> ONLY the browser's speech voice. No generated tone/beep
 *    is ever played; the <audio> element stays empty for these.
 */
export default function BottomWaveformPlayer({
  track,
  isPlaying,
  onTogglePlay,
}: BottomWaveformPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(4.2);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [speechRatio, setSpeechRatio] = useState(0);
  const [speechError, setSpeechError] = useState<string | null>(null);

  const isSpeechTrack = !!track && track.engineUsed !== "elevenlabs_live";

  // Latest-value refs so speech callbacks never use stale state.
  const speechTokenRef = useRef(0);
  const lastCharRef = useRef(0);
  const lastBoundaryAtRef = useRef(0);
  const trackRef = useRef(track);
  const isPlayingRef = useRef(isPlaying);
  const onToggleRef = useRef(onTogglePlay);
  const speedRef = useRef(playbackSpeed);
  const volumeRef = useRef(isMuted ? 0 : volume);
  trackRef.current = track;
  isPlayingRef.current = isPlaying;
  onToggleRef.current = onTogglePlay;
  speedRef.current = playbackSpeed;
  volumeRef.current = isMuted ? 0 : volume;

  const speechDuration = useMemo(() => {
    if (!track) return 4.2;
    const words = track.promptText.trim().split(/\s+/).filter(Boolean).length;
    const rate = Math.max(0.65, Math.min(1.5, playbackSpeed * (track.speed || 1)));
    return Math.max(1.5, words / (2.6 * rate) + 0.4);
  }, [track, playbackSpeed]);

  const displayDuration = isSpeechTrack ? speechDuration : duration;
  const displayTime = isSpeechTrack ? speechRatio * speechDuration : currentTime;
  const progressRatio =
    displayDuration > 0 ? Math.min(1, displayTime / displayDuration) : 0;

  // Deterministic 48-bar acoustic waveform heights derived from the script
  const waveformBars = useMemo(() => {
    const seedText =
      track?.promptText || "Latif Bugti Red and Black Studio Acoustic Waveform";
    const bars: number[] = [];
    for (let i = 0; i < 48; i++) {
      const charCode = seedText.charCodeAt(i % seedText.length) || 72;
      const wave =
        Math.sin(i * 0.45) * 0.3 +
        Math.cos(i * 0.9 + charCode) * 0.25 +
        ((charCode * (i + 3)) % 37) / 100;
      bars.push(
        Math.max(18, Math.min(96, Math.round(35 + Math.abs(wave) * 60)))
      );
    }
    return bars;
  }, [track?.promptText]);

  const stopSpeech = useCallback(() => {
    speechTokenRef.current += 1; // invalidates callbacks of the utterance being cancelled
    stopBrowserSpeech();
  }, []);

  const startSpeech = useCallback(() => {
    const t = trackRef.current;
    if (!t) return;

    const fullText = t.promptText;
    const offset = Math.min(lastCharRef.current, fullText.length);
    const remaining = fullText.slice(offset);

    if (!remaining.trim()) {
      lastCharRef.current = 0;
      setSpeechRatio(0);
      if (isPlayingRef.current) onToggleRef.current();
      return;
    }

    const token = ++speechTokenRef.current;
    setSpeechError(null);
    lastBoundaryAtRef.current = Date.now();

    const ok = speakWithBrowserNeural({
      text: remaining,
      gender: t.gender,
      pitchShift: t.pitchShift,
      speed: speedRef.current * (t.speed || 1),
      volume: volumeRef.current,
      onBoundary: (idx) => {
        if (token !== speechTokenRef.current) return;
        const abs = offset + idx;
        lastCharRef.current = abs;
        lastBoundaryAtRef.current = Date.now();
        setSpeechRatio(Math.min(1, abs / Math.max(1, fullText.length)));
      },
      onEnd: () => {
        if (token !== speechTokenRef.current) return;
        lastCharRef.current = 0;
        setSpeechRatio(0);
        if (isPlayingRef.current) onToggleRef.current();
      },
    });

    if (!ok) {
      speechTokenRef.current += 1;
      setSpeechError(
        "This browser can't speak aloud. Use Chrome, Edge or Safari — or add an ElevenLabs key for real MP3 audio."
      );
      if (isPlayingRef.current) onToggleRef.current();
    }
  }, []);

  // New track: reset everything and load the right playback path.
  useEffect(() => {
    stopSpeech();
    lastCharRef.current = 0;
    setSpeechRatio(0);
    setSpeechError(null);
    setCurrentTime(0);

    const audio = audioRef.current;
    if (!audio) return;
    if (!track || isSpeechTrack) {
      audio.pause();
      audio.removeAttribute("src");
      audio.load();
      return;
    }
    audio.src = track.audioData;
    audio.playbackRate = speedRef.current;
    audio.volume = volumeRef.current;
    setDuration(Math.max(1.5, (track.durationMs || 4200) / 1000));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [track?.id]);

  // Play / pause
  useEffect(() => {
    if (!track) return;
    const audio = audioRef.current;
    if (isSpeechTrack) {
      if (audio && !audio.paused) audio.pause();
      if (isPlaying) startSpeech();
      else stopSpeech();
    } else {
      stopSpeech();
      if (!audio) return;
      if (isPlaying) audio.play().catch(() => {});
      else audio.pause();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying, track?.id]);

  // Smooth progress for browsers that don't emit word-boundary events
  useEffect(() => {
    if (!isSpeechTrack || !isPlaying) return;
    const id = setInterval(() => {
      if (Date.now() - lastBoundaryAtRef.current < 700) return;
      setSpeechRatio((r) => Math.min(0.97, r + 0.1 / Math.max(1, speechDuration)));
    }, 100);
    return () => clearInterval(id);
  }, [isSpeechTrack, isPlaying, speechDuration]);

  // Never leave speech running after the player unmounts
  useEffect(() => {
    return () => {
      speechTokenRef.current += 1;
      stopBrowserSpeech();
    };
  }, []);

  const restartSpeechIfPlaying = () => {
    if (isSpeechTrack && isPlayingRef.current) startSpeech();
  };

  const handleSeek = (ratio: number) => {
    const clamped = Math.max(0, Math.min(1, ratio));

    if (isSpeechTrack && track) {
      const text = track.promptText;
      let pos = Math.floor(clamped * text.length);
      while (pos > 0 && !/\s/.test(text[pos - 1])) pos -= 1; // snap to a word start
      lastCharRef.current = pos;
      setSpeechRatio(pos / Math.max(1, text.length));
      restartSpeechIfPlaying();
      return;
    }

    if (!audioRef.current || !duration) return;
    const target = clamped * duration;
    audioRef.current.currentTime = target;
    setCurrentTime(target);
  };

  const canDownload =
    !!track && !isSpeechTrack && track.audioData.startsWith("data:");

  const handleDownload = () => {
    if (!track || !canDownload) return;
    const link = document.createElement("a");
    link.href = track.audioData;
    const ext = track.audioData.startsWith("data:audio/mpeg") ? "mp3" : "wav";
    const safeName = track.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
    link.download = `${safeName || "latif-bugti-take"}.${ext}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    const tenths = Math.floor((sec % 1) * 10);
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(
      2,
      "0"
    )}.${tenths}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 h-[84px] border-t border-[#B91C1C]/35 bg-gradient-to-r from-[#140709]/95 via-[#0B0808]/95 to-[#140709]/95 backdrop-blur-xl px-4 lg:px-6 flex items-center justify-between gap-4 shadow-[0_-10px_35px_rgba(185,28,28,0.14)]">
      {/* Only ever holds real ElevenLabs MP3 audio */}
      <audio
        ref={audioRef}
        onTimeUpdate={(e) => {
          if (!isSpeechTrack) setCurrentTime(e.currentTarget.currentTime);
        }}
        onLoadedMetadata={(e) => {
          const d = e.currentTarget.duration;
          if (!isSpeechTrack && d && isFinite(d) && d > 0) setDuration(d);
        }}
        onEnded={() => {
          setCurrentTime(0);
          if (isPlayingRef.current) onToggleRef.current();
        }}
      />

      {/* Left: Active Track Metadata */}
      <div className="flex items-center gap-3 min-w-[180px] max-w-[270px] sm:w-[260px]">
        <div
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${
            isPlaying
              ? "border-[#B91C1C] bg-gradient-to-br from-[#EF4444]/30 to-[#B91C1C]/30 text-[#F87171] shadow-lg shadow-[#B91C1C]/25"
              : "border-[#B91C1C]/30 bg-[#0C0909] text-[#FCA5A5]"
          }`}
        >
          <Radio className={`h-5 w-5 ${isPlaying ? "animate-pulse" : ""}`} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-semibold text-[#FFF1F1]">
            {track ? track.title : "Latif Bugti Monitor Ready"}
          </p>
          <p
            className={`truncate text-[11px] ${
              speechError ? "text-[#FCA5A5]" : "text-[#FCA5A5]"
            }`}
            title={speechError ?? undefined}
          >
            {speechError
              ? speechError
              : track
              ? `${track.voiceName} • ${
                  isSpeechTrack ? "Live speech voice" : "ElevenLabs MP3"
                }`
              : "Select any voice or generation take to audition"}
          </p>
        </div>
      </div>

      {/* Center: Transport & 48-Bar Red & Black Waveform Scrubber */}
      <div className="flex flex-1 items-center justify-center gap-3 sm:gap-5 max-w-3xl">
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={!track}
            onClick={() => handleSeek(0)}
            title="Restart Take"
            className="rounded-lg p-2 text-[#FCA5A5] hover:bg-[#B91C1C]/15 hover:text-[#F87171] disabled:opacity-40 transition"
          >
            <RotateCcw className="h-4 w-4" />
          </button>

          <button
            type="button"
            disabled={!track}
            onClick={onTogglePlay}
            className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-[#EF4444] to-[#7F1D1D] text-[#FFF1F1] hover:opacity-95 disabled:opacity-40 transition shadow-lg shadow-[#EF4444]/40"
          >
            {isPlaying ? (
              <Pause className="h-5 w-5 fill-current" />
            ) : (
              <Play className="h-5 w-5 fill-current ml-0.5" />
            )}
          </button>
        </div>

        <div className="hidden md:flex flex-1 items-center gap-3">
          <span className="font-mono-tech text-[11px] text-[#EF4444] w-14 text-right">
            {formatTime(displayTime)}
          </span>

          <div
            className="relative flex flex-1 items-center justify-between gap-[3px] h-10 px-2 rounded-lg bg-[#090606] border border-[#B91C1C]/35 cursor-pointer select-none overflow-hidden"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              handleSeek((e.clientX - rect.left) / rect.width);
            }}
          >
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-20">
              <span className="font-display text-xs font-extrabold tracking-widest uppercase animate-latif-bugti-text">
                ★ LATIF BUGTI • LATIF AI ★
              </span>
            </div>

            {waveformBars.map((barHeight, idx) => {
              const barRatio = idx / waveformBars.length;
              const isPlayed = barRatio <= progressRatio;
              const isPlayhead =
                Math.abs(barRatio - progressRatio) < 1 / waveformBars.length;
              const isAccent = idx % 2 === 0;
              return (
                <div
                  key={idx}
                  style={{
                    height: `${
                      isPlaying
                        ? Math.min(
                            96,
                            Math.max(
                              16,
                              barHeight +
                                ((idx * 13 + Math.floor(displayTime * 10)) % 22) -
                                11
                            )
                          )
                        : barHeight
                    }%`,
                  }}
                  className={`relative z-10 w-1.5 rounded-full transition-all duration-150 ${
                    isPlayhead
                      ? "bg-gradient-to-b from-[#EF4444] to-[#7F1D1D] shadow-[0_0_12px_#B91C1C]"
                      : isPlayed
                      ? isAccent
                        ? "bg-[#B91C1C]"
                        : "bg-[#EF4444]"
                      : isAccent
                      ? "bg-[#B91C1C]/30 hover:bg-[#B91C1C]/70"
                      : "bg-[#EF4444]/30 hover:bg-[#EF4444]/70"
                  }`}
                />
              );
            })}
          </div>

          <span className="font-mono-tech text-[11px] text-[#F87171] w-14">
            {formatTime(displayDuration)}
          </span>
        </div>
      </div>

      {/* Right: engine badge, speed, volume & download */}
      <div className="flex items-center gap-2.5">
        <span
          title={
            isSpeechTrack
              ? "Built-in engine: clean spoken voice only — no generated tone."
              : "Real ElevenLabs audio."
          }
          className={`hidden sm:inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold ${
            !track || isSpeechTrack
              ? "border-[#B91C1C]/50 bg-gradient-to-r from-[#EF4444]/15 to-[#B91C1C]/15 text-[#FCA5A5]"
              : "border-[#B91C1C]/70 bg-[#B91C1C]/20 text-[#F87171]"
          }`}
        >
          <Sparkles className="h-3.5 w-3.5 text-[#EF4444]" />
          <span>
            {!track ? "Ready" : isSpeechTrack ? "Live Voice" : "ElevenLabs MP3"}
          </span>
        </span>

        <button
          type="button"
          onClick={() => {
            const speeds = [0.85, 1.0, 1.15, 1.25];
            const next =
              speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.length];
            setPlaybackSpeed(next);
            speedRef.current = next;
            if (audioRef.current) audioRef.current.playbackRate = next;
            restartSpeechIfPlaying();
          }}
          className="hidden lg:inline-flex font-mono-tech rounded-lg border border-[#B91C1C]/35 bg-[#0C0909] px-2.5 py-1.5 text-[11px] text-[#FCA5A5] hover:border-[#EF4444] transition"
        >
          {playbackSpeed.toFixed(2)}x
        </button>

        <div className="hidden xl:flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              const nextMute = !isMuted;
              setIsMuted(nextMute);
              volumeRef.current = nextMute ? 0 : volume;
              if (audioRef.current)
                audioRef.current.volume = nextMute ? 0 : volume;
              restartSpeechIfPlaying();
            }}
            className="text-[#FCA5A5] hover:text-[#EF4444] p-1"
          >
            {isMuted ? (
              <VolumeX className="h-4 w-4 text-[#EF4444]" />
            ) : (
              <Volume2 className="h-4 w-4" />
            )}
          </button>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={isMuted ? 0 : volume}
            onChange={(e) => {
              const v = parseFloat(e.target.value);
              setVolume(v);
              setIsMuted(v === 0);
              volumeRef.current = v;
              if (audioRef.current) audioRef.current.volume = v;
            }}
            // Speech volume applies when an utterance starts, so re-apply on release.
            onPointerUp={restartSpeechIfPlaying}
            className="w-16 studio-slider"
          />
        </div>

        <button
          type="button"
          disabled={!canDownload}
          onClick={handleDownload}
          title={
            canDownload
              ? "Download this take"
              : isSpeechTrack
              ? "Built-in live voice has no audio file. Add an ElevenLabs key to get downloadable MP3 takes."
              : "Nothing to download"
          }
          className="inline-flex items-center gap-1.5 rounded-lg border border-[#B91C1C]/40 bg-gradient-to-r from-[#EF4444]/20 to-[#B91C1C]/20 px-3 py-2 text-xs font-medium text-[#FFF1F1] hover:border-[#B91C1C] hover:text-[#F87171] disabled:opacity-40 disabled:cursor-not-allowed transition"
        >
          <Download className="h-3.5 w-3.5 text-[#F87171]" />
          <span className="hidden sm:inline">Download</span>
        </button>
      </div>
    </div>
  );
}
