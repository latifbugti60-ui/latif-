"use client";

import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Volume2,
  Radio,
  Activity,
  Cpu,
  Zap,
  Waves,
} from "lucide-react";
import { speakWithBrowserNeural, stopBrowserSpeech } from "@/lib/browser-speech";

interface LatifAiVisualizerProps {
  isPlaying: boolean;
  isSynthesizing: boolean;
  activeVoiceName: string;
  activeVoiceGender?: string;
  activeVoicePitch?: number;
  promptText: string;
  onTriggerGenerate?: () => void;
}

type AnimationStyle = "orb" | "matrix" | "cyberwave";

export default function LatifAiVisualizer({
  isPlaying,
  isSynthesizing,
  activeVoiceName,
  activeVoiceGender = "Male",
  activeVoicePitch = 0.98,
  promptText,
  onTriggerGenerate,
}: LatifAiVisualizerProps) {
  const [animStyle, setAnimStyle] = useState<AnimationStyle>("orb");
  const [isAiSpeakingLive, setIsAiSpeakingLive] = useState(false);
  const [tick, setTick] = useState(0);

  const isActive = isPlaying || isSynthesizing || isAiSpeakingLive;

  useEffect(() => {
    const interval = setInterval(
      () => {
        setTick((t) => (t + 1) % 1000);
      },
      isActive ? 90 : 260
    );
    return () => clearInterval(interval);
  }, [isActive]);

  const handleTriggerLatifAiVoice = () => {
    if (isAiSpeakingLive) {
      stopBrowserSpeech();
      setIsAiSpeakingLive(false);
      return;
    }

    const spokenText =
      promptText.trim() ||
      "Assalam-o-Alaikum! Main Latif Bugti AI hoon, aapka personal red and black neural voice generator. Aap jo bhi script likhenge, main usay asali bolti hui aawaz mein generate karunga!";

    setIsAiSpeakingLive(true);
    const started = speakWithBrowserNeural({
      text: spokenText,
      gender: activeVoiceGender,
      pitchShift: activeVoicePitch,
      speed: 1.0,
      onStart: () => setIsAiSpeakingLive(true),
      onEnd: () => setIsAiSpeakingLive(false),
    });

    if (!started) {
      setTimeout(() => setIsAiSpeakingLive(false), 3500);
    }
  };

  // Generate 32 dynamic Red & Black equalizer bars
  const eqBars = Array.from({ length: 32 }, (_, idx) => {
    const centerDist = Math.abs(idx - 15.5) / 16;
    if (isActive) {
      const dynamic =
        Math.sin(tick * 0.45 + idx * 0.6) * 38 +
        Math.cos(tick * 0.8 - idx * 0.4) * 28;
      return Math.max(
        18,
        Math.min(98, Math.round((1 - centerDist * 0.45) * 65 + Math.abs(dynamic)))
      );
    }
    const idleWave = Math.sin(tick * 0.18 + idx * 0.35) * 16;
    return Math.max(
      16,
      Math.min(56, Math.round((1 - centerDist * 0.5) * 30 + Math.abs(idleWave)))
    );
  });

  return (
    <div className="relative overflow-hidden rounded-2xl border border-[#B91C1C]/45 bg-gradient-to-br from-[#20070B] via-[#0D0A0A] to-[#1A0609] p-5 sm:p-6 shadow-[0_0_50px_rgba(239,68,68,0.22),0_0_50px_rgba(185,28,28,0.18)]">
      {/* Ambient Red & Black Background Glows */}
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-[#EF4444]/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-[#B91C1C]/25 blur-3xl" />
      <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 select-none opacity-15">
        <span className="font-display text-6xl sm:text-8xl font-extrabold tracking-widest uppercase animate-latif-bugti-text whitespace-nowrap">
          LATIF BUGTI
        </span>
      </div>

      {/* Top Animated LATIF BUGTI Red & Black Ribbon Banner */}
      <div className="relative z-10 mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#B91C1C]/40 animate-latif-bugti-bg px-4 py-2.5 shadow-lg">
        <div className="flex items-center gap-2.5">
          <span className="inline-flex h-3 w-3 rounded-full bg-[#B91C1C] shadow-[0_0_12px_#B91C1C] animate-ping" />
          <span className="font-display text-sm sm:text-base font-extrabold tracking-wider uppercase text-[#FFF1F1] drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
            ★ LATIF BUGTI — LATIF AI RED &amp; BLACK NEURAL STUDIO ★
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-[#080505]/80 border border-[#EF4444]/60 px-3 py-0.5 font-mono-tech text-[11px] font-bold text-[#F87171]">
            RED + BLACK EDITION
          </span>
        </div>
      </div>

      <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6">
        {/* Left: Interactive Animated Red & Black Latif Bugti Orb / Core */}
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="relative flex h-36 w-36 shrink-0 items-center justify-center">
            {/* Expanding Red & Black Sonic Ripples when Active */}
            {isActive && (
              <>
                <div className="absolute inset-0 rounded-full border-2 border-[#EF4444]/70 animate-latif-ripple" />
                <div
                  className="absolute inset-2 rounded-full border-2 border-[#B91C1C]/70 animate-latif-ripple"
                  style={{ animationDelay: "0.7s" }}
                />
              </>
            )}

            {/* Outer Rotating Cybernetic Red Ring */}
            <div
              className={`absolute inset-0 rounded-full border-2 border-dashed border-[#EF4444]/75 ${
                isActive ? "animate-latif-orbit-fast" : "animate-latif-orbit"
              }`}
            />

            {/* Middle Counter-Rotating Crimson & Black Ring */}
            <div className="absolute inset-3 rounded-full border-2 border-[#B91C1C]/60 border-t-[#EF4444] border-b-[#B91C1C] animate-latif-orbit-reverse" />

            {/* Inner Glowing Red & Black Mix AI Core Button (Zero White Background) */}
            <button
              type="button"
              onClick={handleTriggerLatifAiVoice}
              title="Click to activate Latif Bugti Live Voice Animation"
              className={`relative z-10 flex h-24 w-24 flex-col items-center justify-center rounded-full animate-latif-bugti-bg text-[#FFF1F1] border border-[#F87171]/60 transition cursor-pointer ${
                isActive ? "animate-latif-speaking" : "animate-latif-idle"
              }`}
            >
              {/* Mini Dynamic Red & Black Equalizer inside the Orb */}
              <div className="flex items-end justify-center gap-1 h-7 mb-1">
                {[0, 1, 2, 3, 4, 5, 6].map((barIdx) => {
                  const h = isActive
                    ? 35 + ((tick * 19 + barIdx * 23) % 65)
                    : 25 + ((tick * 7 + barIdx * 15) % 30);
                  const isAccentBar = barIdx % 2 === 0;
                  return (
                    <span
                      key={barIdx}
                      style={{ height: `${h}%` }}
                      className={`w-1 rounded-full transition-all duration-100 ${
                        isAccentBar
                          ? "bg-[#F87171] shadow-[0_0_8px_#B91C1C]"
                          : "bg-[#F87171] shadow-[0_0_8px_#EF4444]"
                      }`}
                    />
                  );
                })}
              </div>
              <span className="font-display text-[9px] font-extrabold tracking-wider uppercase text-[#FDBABA] drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
                LATIF BUGTI
              </span>
              <span className="font-mono-tech text-[8px] font-bold text-[#FCA5A5]">
                {isSynthesizing
                  ? "GENERATING"
                  : isActive
                  ? "SPEAKING"
                  : "LATIF AI"}
              </span>
            </button>
          </div>

          {/* Center-Left Info & Controls */}
          <div className="text-center sm:text-left space-y-2.5 max-w-lg">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] px-3 py-0.5 text-[11px] font-bold tracking-wide text-[#FFF1F1] shadow-lg shadow-[#B91C1C]/30">
                <Zap className="h-3 w-3 fill-current" />
                LATIF BUGTI • LATIF AI CORE
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-[#B91C1C]/50 bg-[#2A0606]/50 px-2.5 py-0.5 font-mono-tech text-[11px] text-[#FCA5A5]">
                <span
                  className={`h-2 w-2 rounded-full ${
                    isActive
                      ? "bg-[#B91C1C] animate-ping"
                      : "bg-[#EF4444]"
                  }`}
                />
                {isSynthesizing
                  ? "SYNTHESIZING RED-BLACK WAVE..."
                  : isActive
                  ? "LATIF BUGTI LIVE STREAMING"
                  : "RED & BLACK ENGINE READY"}
              </span>
            </div>

            {/* Animated LATIF BUGTI Headline */}
            <h2 className="font-display text-xl sm:text-2xl font-extrabold tracking-tight animate-latif-bugti-text">
              LATIF BUGTI — Latif AI Voice Synthesizer
            </h2>

            <p className="text-xs text-[#FCD5D5] leading-relaxed">
              Active Persona:{" "}
              <strong className="text-[#F87171]">{activeVoiceName}</strong>.
              Click the glowing{" "}
              <strong className="text-[#F87171]">Latif Bugti Red &amp; Black Core</strong>{" "}
              or press <strong className="text-[#F87171]">Activate Latif AI Voice</strong> to watch the Red &amp; Black equalizer animate while speaking your script!
            </p>

            {/* Interactive Controls Row (Zero White Background — Red & Black Mix) */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
              <button
                type="button"
                onClick={handleTriggerLatifAiVoice}
                className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition shadow-lg ${
                  isAiSpeakingLive
                    ? "bg-gradient-to-r from-[#7F1D1D] via-[#450A0A] to-[#EF4444] text-[#FFF1F1] shadow-[#B91C1C]/40 border border-[#F87171]"
                    : "bg-gradient-to-r from-[#EF4444] via-[#DC2626] to-[#7F1D1D] text-[#FFF1F1] hover:opacity-95 shadow-[#EF4444]/35"
                }`}
              >
                <Volume2 className="h-4 w-4" />
                {isAiSpeakingLive
                  ? "Stop Latif Bugti Voice"
                  : "Activate Latif AI Voice"}
              </button>

              {onTriggerGenerate && (
                <button
                  type="button"
                  onClick={onTriggerGenerate}
                  disabled={isSynthesizing}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-[#B91C1C]/50 bg-gradient-to-r from-[#EF4444]/20 to-[#B91C1C]/20 px-3.5 py-2 text-xs font-semibold text-[#FCA5A5] hover:from-[#EF4444]/35 hover:to-[#B91C1C]/35 transition"
                >
                  <Sparkles className="h-3.5 w-3.5 text-[#EF4444]" />
                  Generate & Save Take
                </button>
              )}

              {/* Animation Mode Switcher */}
              <div className="inline-flex items-center rounded-xl border border-[#B91C1C]/40 bg-[#0B0808] p-1">
                {[
                  { id: "orb" as AnimationStyle, label: "Orb", icon: Radio },
                  { id: "matrix" as AnimationStyle, label: "Matrix", icon: Activity },
                  { id: "cyberwave" as AnimationStyle, label: "Wave", icon: Waves },
                ].map((mode) => {
                  const Icon = mode.icon;
                  return (
                    <button
                      key={mode.id}
                      type="button"
                      onClick={() => setAnimStyle(mode.id)}
                      className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-medium transition ${
                        animStyle === mode.id
                          ? "bg-gradient-to-r from-[#EF4444] to-[#7F1D1D] text-[#FFF1F1] shadow"
                          : "text-[#FCA5A5]/70 hover:text-[#FCA5A5]"
                      }`}
                    >
                      <Icon className="h-3 w-3" />
                      {mode.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right: 32-Band Animated Red & Black Acoustic Spectrum Visualizer */}
        <div className="w-full lg:w-[360px] xl:w-[420px] rounded-xl border border-[#B91C1C]/40 bg-gradient-to-b from-[#17070A]/95 to-[#0B0808]/95 p-4 space-y-3 shadow-inner">
          <div className="flex items-center justify-between text-[11px] font-mono-tech">
            <span className="flex items-center gap-1.5 text-[#F87171] font-bold">
              <Cpu className="h-3.5 w-3.5 text-[#EF4444]" />
              LATIF BUGTI SONIC SPECTRUM
            </span>
            <span className="text-[#FCA5A5]">
              {isActive ? "99.4 dB • LIVE MIX" : "RED + BLACK READY"}
            </span>
          </div>

          {animStyle === "cyberwave" ? (
            /* Cyber Wave Oscilloscope Mode — Red & Black Mix */
            <div className="relative h-24 w-full flex items-center justify-center overflow-hidden rounded-lg bg-[#0A0707] border border-[#B91C1C]/30 px-2">
              <div className="flex items-center justify-between w-full gap-1 h-full">
                {eqBars.map((val, idx) => (
                  <div
                    key={idx}
                    className="flex-1 flex flex-col items-center justify-center h-full"
                  >
                    <div
                      style={{ height: `${val}%` }}
                      className={`w-full rounded-full transition-all duration-100 ${
                        idx % 2 === 0
                          ? "bg-gradient-to-b from-[#EF4444] via-[#7F1D1D] to-[#EF4444] shadow-[0_0_10px_#B91C1C]"
                          : "bg-gradient-to-b from-[#7F1D1D] via-[#EF4444] to-[#450A0A] shadow-[0_0_10px_#EF4444]"
                      }`}
                    />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Red & Black Matrix / Orb Equalizer Bars */
            <div className="relative h-24 w-full flex items-end justify-between gap-[3px] rounded-lg bg-[#0A0707] border border-[#B91C1C]/30 p-2.5 overflow-hidden">
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-25">
                <span className="font-display text-lg font-extrabold tracking-widest uppercase animate-latif-bugti-text">
                  LATIF BUGTI AI
                </span>
              </div>
              {eqBars.map((val, idx) => {
                const isAccent = idx % 2 === 0;
                return (
                  <div
                    key={idx}
                    style={{ height: `${val}%` }}
                    className={`relative z-10 flex-1 rounded-t-sm transition-all duration-100 ${
                      isActive
                        ? isAccent
                          ? "bg-gradient-to-t from-[#450A0A] to-[#F87171] shadow-[0_0_10px_#B91C1C]"
                          : "bg-gradient-to-t from-[#991B1B] to-[#EF4444] shadow-[0_0_10px_#EF4444]"
                        : isAccent
                        ? "bg-[#B91C1C]/75 hover:bg-[#F87171]"
                        : "bg-[#EF4444]/75 hover:bg-[#F87171]"
                    }`}
                  />
                );
              })}
            </div>
          )}

          <div className="flex items-center justify-between font-mono-tech text-[10px] text-[#FCA5A5]">
            <span>F0: {Math.round(145 * activeVoicePitch)}Hz</span>
            <span className="text-[#FCA5A5]">LATIF BUGTI RED-BLACK</span>
            <span>38ms</span>
          </div>
        </div>
      </div>
    </div>
  );
}
