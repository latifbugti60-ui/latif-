"use client";

import React, { useState } from "react";
import { StudioUser } from "@/types/studio";
import {
  X,
  Key,
  ShieldCheck,
  UserCheck,
  RefreshCw,
  Volume2,
  CheckCircle2,
  Sparkles,
  LogIn,
} from "lucide-react";
import { speakWithBrowserNeural } from "@/lib/browser-speech";

interface AuthSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: StudioUser | null;
  hasLiveElevenLabsKey: boolean;
  initialTab?: "engine" | "auth";
  onUpdateSettings: (payload: {
    name?: string;
    elevenlabsApiKey?: string;
    preferredEngine?: string;
    syncVoicesFromElevenLabs?: boolean;
  }) => Promise<string>;
  onAuthenticate: (payload: {
    action?: string;
    email?: string;
    name?: string;
    password?: string;
    elevenlabsApiKey?: string;
  }) => Promise<void>;
}

export default function AuthSettingsModal({
  isOpen,
  onClose,
  user,
  hasLiveElevenLabsKey,
  initialTab = "engine",
  onUpdateSettings,
  onAuthenticate,
}: AuthSettingsModalProps) {
  const [activeTab, setActiveTab] = useState<"engine" | "auth">(initialTab);
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [preferredEngine, setPreferredEngine] = useState(
    user?.preferredEngine || "auto"
  );
  const [nameInput, setNameInput] = useState(user?.name || "Latif AI");
  const [emailInput, setEmailInput] = useState(
    user?.email || "creator@latifai.studio"
  );
  const [passwordInput, setPasswordInput] = useState("••••••••••••");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleSaveEngineSettings = async (syncVoices = false) => {
    setIsSaving(true);
    setStatusMessage(null);
    try {
      const msg = await onUpdateSettings({
        name: nameInput,
        elevenlabsApiKey: apiKeyInput.trim() ? apiKeyInput.trim() : undefined,
        preferredEngine,
        syncVoicesFromElevenLabs: syncVoices,
      });
      setStatusMessage(msg);
      if (apiKeyInput.trim()) setApiKeyInput("");
    } finally {
      setIsSaving(false);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMessage(null);
    try {
      await onAuthenticate({
        email: emailInput,
        name: nameInput,
        password: passwordInput,
        elevenlabsApiKey: apiKeyInput.trim() || undefined,
      });
      setStatusMessage("Signed in & Latif AI studio session synchronized.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSpeakUrduAnswer = () => {
    speakWithBrowserNeural({
      text: "Assalam-o-Alaikum! Main Latif AI hoon. Is Red Neural Studio app se 100 percent real voice generate hoti hai. Aap apni ElevenLabs API key lagakar live neural MP3 generate kar sakte hain, ya bina API key ke bhi Latif AI Real Speech Engine se foran asali bolti hui aawaz sun sakte hain.",
      gender: "Male",
      pitchShift: 0.98,
      speed: 1.0,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-xl border border-[#EF4444]/40 bg-[#12080A] shadow-[0_0_50px_rgba(239,68,68,0.2)] overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#36171B] bg-[#1B0C0E] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#EF4444]/20 border border-[#EF4444]/50 text-[#EF4444]">
              <Key className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-white">
                Latif AI Auth & Red Neural Voice Engine Setup
              </h2>
              <p className="text-xs text-[#A38B8E]">
                Connect your ElevenLabs API key, manage your Latif AI creator session, or test real voice output
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-[#A38B8E] hover:bg-white/5 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#36171B] bg-[#090607] px-6">
          <button
            type="button"
            onClick={() => setActiveTab("engine")}
            className={`flex items-center gap-2 border-b-2 py-3 px-4 text-xs font-semibold transition ${
              activeTab === "engine"
                ? "border-[#EF4444] text-[#EF4444]"
                : "border-transparent text-[#A38B8E] hover:text-white"
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            ElevenLabs API & Real Voice FAQ
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("auth")}
            className={`flex items-center gap-2 border-b-2 py-3 px-4 text-xs font-semibold transition ${
              activeTab === "auth"
                ? "border-[#EF4444] text-[#EF4444]"
                : "border-transparent text-[#A38B8E] hover:text-white"
            }`}
          >
            <UserCheck className="h-3.5 w-3.5" />
            Latif AI Account ({user?.name.split(" ")[0] || "Latif"})
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[78vh] overflow-y-auto">
          {statusMessage && (
            <div className="flex items-center gap-2 rounded-lg border border-[#EF4444]/50 bg-[#EF4444]/15 px-4 py-2.5 text-xs text-[#FCA5A5]">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[#EF4444]" />
              <span>{statusMessage}</span>
            </div>
          )}

          {activeTab === "engine" ? (
            <>
              {/* Bilingual Direct Answer Box for User's Question */}
              <div className="rounded-xl border border-[#EF4444]/40 bg-gradient-to-br from-[#EF4444]/15 via-[#1B0C0E] to-[#090607] p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-[#EF4444]/20 border border-[#EF4444]/50 px-2.5 py-0.5 text-[11px] font-semibold text-[#FCA5A5]">
                    Latif AI Red Neural Voice Engine — 100% Real Voice
                  </span>
                  <button
                    type="button"
                    onClick={handleSpeakUrduAnswer}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#EF4444] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#DC2626] transition shadow-lg shadow-[#EF4444]/30"
                  >
                    <Volume2 className="h-3.5 w-3.5" />
                    Sunain (Speak Latif AI Answer)
                  </button>
                </div>

                <div className="space-y-2 text-xs leading-relaxed text-white">
                  <p>
                    <strong className="text-[#EF4444]">
                      Jee Haan! Latif AI Mein 100% Real Voice Generate Hota Hai (2 Modes Mein):
                    </strong>
                  </p>
                  <ul className="list-disc pl-5 space-y-1 text-[#D6C4C7]">
                    <li>
                      <strong className="text-white">
                        Mode 1 — Live ElevenLabs Neural API (Original Cloned MP3):
                      </strong>{" "}
                      Jab aap neeche apni personal{" "}
                      <code className="font-mono-tech text-[#FCA5A5]">xi-api-key</code>{" "}
                      save karte hain, Latif AI seedha{" "}
                      <code className="font-mono-tech text-[#EF4444]">
                        api.elevenlabs.io/v1/text-to-speech
                      </code>{" "}
                      se aapki personal cloned voice mein real MP3 generate karta hai aur PostgreSQL database mein save karta hai.
                    </li>
                    <li>
                      <strong className="text-white">
                        Mode 2 — Built-in Live Speech Voice (saaf awaaz, koi beep nahi):
                      </strong>{" "}
                      Bina kisi API key ke bhi jab aap{" "}
                      <strong className="text-[#EF4444]">&ldquo;Generate Speech&rdquo;</strong> ya{" "}
                      <strong className="text-[#FCA5A5]">&ldquo;Play&rdquo;</strong> dabayenge, Latif AI aapke likhe hue English ya Roman Urdu script ko{" "}
                      <strong>aapke device/browser ki bolti hui awaaz</strong> mein sunata hai — koi tone ya beep add nahi hoti. Is mode mein audio file save nahi hoti, isliye download sirf ElevenLabs MP3 takes ka hota hai.
                    </li>
                  </ul>
                </div>
              </div>

              {/* Live ElevenLabs Key Input */}
              <div className="rounded-xl border border-[#36171B] bg-[#090607] p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-white">
                      Personal ElevenLabs API Key (`xi-api-key`)
                    </h3>
                    <p className="text-xs text-[#A38B8E]">
                      Stored securely in PostgreSQL for Latif AI server-side synthesis & voice cloning sync
                    </p>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-mono-tech font-medium ${
                      hasLiveElevenLabsKey
                        ? "bg-[#B91C1C]/15 text-[#F87171] border border-[#B91C1C]/40"
                        : "bg-[#EF4444]/15 text-[#FCA5A5] border border-[#EF4444]/40"
                    }`}
                  >
                    <ShieldCheck className="h-3.5 w-3.5" />
                    {hasLiveElevenLabsKey
                      ? `LIVE KEY ACTIVE (${user?.maskedApiKey || "ENV"})`
                      : "LATIF AI NEURAL ENGINE ACTIVE"}
                  </span>
                </div>

                <div>
                  <input
                    type="password"
                    value={apiKeyInput}
                    onChange={(e) => setApiKeyInput(e.target.value)}
                    placeholder={
                      user?.maskedApiKey
                        ? `Current saved key: ${user.maskedApiKey} (Enter new key to replace)`
                        : "Paste your xi-... or sk_... ElevenLabs API Key here"
                    }
                    className="w-full font-mono-tech rounded-lg border border-[#36171B] bg-[#12080A] px-3.5 py-2.5 text-xs text-white placeholder-[#6E5559] focus:border-[#EF4444] focus:outline-none"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-[#A38B8E]">Engine Mode:</label>
                    <select
                      value={preferredEngine}
                      onChange={(e) => setPreferredEngine(e.target.value)}
                      className="rounded-lg border border-[#36171B] bg-[#1B0C0E] px-3 py-1.5 text-xs text-white focus:border-[#EF4444] focus:outline-none"
                    >
                      <option value="auto">
                        Auto (ElevenLabs Live + Latif AI Real Speech)
                      </option>
                      <option value="elevenlabs">
                        ElevenLabs API Priority
                      </option>
                      <option value="browser_neural">
                        Built-in Live Speech Only (no ElevenLabs, no tone)
                      </option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => handleSaveEngineSettings(true)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-[#EF4444]/50 bg-[#EF4444]/15 px-3.5 py-2 text-xs font-semibold text-[#FCA5A5] hover:bg-[#EF4444]/25 transition"
                    >
                      <RefreshCw
                        className={`h-3.5 w-3.5 ${isSaving ? "animate-spin" : ""}`}
                      />
                      Save Key & Sync ElevenLabs Voices
                    </button>
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => handleSaveEngineSettings(false)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#EF4444] px-4 py-2 text-xs font-semibold text-white hover:bg-[#DC2626] transition shadow-lg shadow-[#EF4444]/30"
                    >
                      Save Engine Config
                    </button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div className="rounded-xl border border-[#36171B] bg-[#090607] p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-white">
                      Latif AI Creator Credentials
                    </h3>
                    <p className="text-xs text-[#A38B8E]">
                      Sign in or switch your personal Latif AI voice studio profile
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      setIsSaving(true);
                      try {
                        await onAuthenticate({ action: "demo_login" });
                        setStatusMessage("Switched to Latif AI Demo Studio Account.");
                      } finally {
                        setIsSaving(false);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#EF4444]/50 bg-[#EF4444]/15 px-3 py-1.5 text-xs font-medium text-[#FCA5A5] hover:bg-[#EF4444]/25 transition"
                  >
                    <LogIn className="h-3.5 w-3.5" />
                    1-Click Latif AI Sign-In
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#A38B8E] mb-1">
                      Studio Creator Name
                    </label>
                    <input
                      type="text"
                      required
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="w-full rounded-lg border border-[#36171B] bg-[#12080A] px-3.5 py-2 text-xs text-white focus:border-[#EF4444] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#A38B8E] mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="w-full rounded-lg border border-[#36171B] bg-[#12080A] px-3.5 py-2 text-xs text-white focus:border-[#EF4444] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#A38B8E] mb-1">
                    Studio Passkey / Password
                  </label>
                  <input
                    type="password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full rounded-lg border border-[#36171B] bg-[#12080A] px-3.5 py-2 text-xs text-white focus:border-[#EF4444] focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-[#7A6266] font-mono-tech">
                    Quota Used: {user?.charactersUsed.toLocaleString() || 18450} /{" "}
                    {user?.characterQuota.toLocaleString() || 100000} chars
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={isSaving}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#EF4444] px-4 py-2 text-xs font-semibold text-white hover:bg-[#DC2626] transition shadow-lg shadow-[#EF4444]/30"
                    >
                      <UserCheck className="h-4 w-4" />
                      {isSaving ? "Authenticating..." : "Save & Sign In"}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
