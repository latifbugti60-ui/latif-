import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  elevenlabsApiKey: text("elevenlabs_api_key"),
  preferredEngine: text("preferred_engine").notNull().default("auto"),
  characterQuota: integer("character_quota").notNull().default(100000),
  charactersUsed: integer("characters_used").notNull().default(14820),
  avatarData: text("avatar_data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const voices = pgTable("voices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  elevenlabsVoiceId: text("elevenlabs_voice_id").notNull(),
  category: text("category").notNull().default("cloned"), // 'cloned' | 'premade' | 'designed'
  accent: text("accent").notNull().default("American"),
  gender: text("gender").notNull().default("Neutral"),
  age: text("age").notNull().default("Young"),
  description: text("description").notNull(),
  useCase: text("use_case").notNull().default("Personal Voice Clone"),
  previewAudioUrl: text("preview_audio_url").notNull(),
  defaultStability: real("default_stability").notNull().default(0.5),
  defaultSimilarity: real("default_similarity").notNull().default(0.75),
  defaultStyle: real("default_style").notNull().default(0.15),
  speakerBoost: boolean("speaker_boost").notNull().default(true),
  pitchShift: real("pitch_shift").notNull().default(1.0),
  isFavorite: boolean("is_favorite").notNull().default(false),
  sampleCount: integer("sample_count").notNull().default(3),
  qualityScore: integer("quality_score").notNull().default(98),
  // 'none' = stock/premade voice, 'elevenlabs_cloned' = real ElevenLabs IVC clone,
  // 'local_profile' = uploaded sample stored + pitch matched locally (not a true clone)
  cloneStatus: text("clone_status").notNull().default("none"),
  measuredPitchHz: real("measured_pitch_hz"),
  // JSON array of { name, mime, data(base64) } — the user's uploaded reference samples
  sampleFiles: text("sample_files"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull().default("Audiobook"),
  status: text("status").notNull().default("active"), // 'active' | 'completed' | 'archived'
  targetLanguage: text("target_language").notNull().default("English & Urdu"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const generations = pgTable("generations", {
  id: serial("id").primaryKey(),
  voiceId: integer("voice_id")
    .references(() => voices.id, { onDelete: "cascade" })
    .notNull(),
  projectId: integer("project_id").references(() => projects.id, {
    onDelete: "set null",
  }),
  title: text("title").notNull().default("Studio Take"),
  promptText: text("prompt_text").notNull(),
  modelId: text("model_id").notNull().default("eleven_multilingual_v2"),
  stability: real("stability").notNull().default(0.5),
  similarityBoost: real("similarity_boost").notNull().default(0.75),
  styleExaggeration: real("style_exaggeration").notNull().default(0.15),
  speakerBoost: boolean("speaker_boost").notNull().default(true),
  speed: real("speed").notNull().default(1.0),
  audioData: text("audio_data").notNull(),
  durationMs: integer("duration_ms").notNull().default(4200),
  characterCount: integer("character_count").notNull().default(0),
  engineUsed: text("engine_used").notNull().default("studio_neural"), // 'elevenlabs_live' | 'studio_neural'
  isFavorite: boolean("is_favorite").notNull().default(false),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;

export type Voice = typeof voices.$inferSelect;
export type NewVoice = typeof voices.$inferInsert;

export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;

export type Generation = typeof generations.$inferSelect;
export type NewGeneration = typeof generations.$inferInsert;
