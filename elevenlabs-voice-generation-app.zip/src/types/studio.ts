export interface StudioUser {
  id: number;
  email: string;
  name: string;
  preferredEngine: string;
  characterQuota: number;
  charactersUsed: number;
  hasPersonalApiKey: boolean;
  maskedApiKey: string | null;
}

export interface VoiceProfile {
  id: number;
  name: string;
  elevenlabsVoiceId: string;
  category: string; // 'cloned' | 'premade' | 'designed'
  accent: string;
  gender: string;
  age: string;
  description: string;
  useCase: string;
  previewAudioUrl: string;
  defaultStability: number;
  defaultSimilarity: number;
  defaultStyle: number;
  speakerBoost: boolean;
  pitchShift: number;
  isFavorite: boolean;
  sampleCount: number;
  qualityScore: number;
  /** 'none' | 'elevenlabs_cloned' | 'local_profile' */
  cloneStatus: string;
  measuredPitchHz: number | null;
  hasSamples: boolean;
  createdAt: string;
}

export interface StudioProject {
  id: number;
  title: string;
  description: string;
  category: string;
  status: string; // 'active' | 'completed' | 'archived'
  targetLanguage: string;
  createdAt: string;
}

export interface VoiceGeneration {
  id: number;
  voiceId: number;
  projectId: number | null;
  title: string;
  promptText: string;
  modelId: string;
  stability: number;
  similarityBoost: number;
  styleExaggeration: number;
  speakerBoost: boolean;
  speed: number;
  audioData: string;
  durationMs: number;
  characterCount: number;
  engineUsed: string; // 'elevenlabs_live' | 'studio_neural'
  isFavorite: boolean;
  notes: string;
  createdAt: string;
}

export interface ActiveTrack {
  id: string;
  title: string;
  subtitle: string;
  promptText: string;
  audioData: string;
  durationMs: number;
  voiceName: string;
  gender: string;
  pitchShift: number;
  speed: number;
  engineUsed: string;
}
