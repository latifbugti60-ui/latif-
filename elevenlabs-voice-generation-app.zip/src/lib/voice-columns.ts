import { getTableColumns, sql } from "drizzle-orm";
import { voices } from "@/db/schema";

// All voice columns EXCEPT the heavy `sample_files` blob (uploaded reference audio).
// A cheap boolean `hasSamples` is returned instead so the UI knows samples exist.
const { sampleFiles: _omitSampleFiles, ...voiceColumnsWithoutSamples } =
  getTableColumns(voices);
void _omitSampleFiles;

export const publicVoiceColumns = {
  ...voiceColumnsWithoutSamples,
  hasSamples: sql<boolean>`(${voices.sampleFiles} is not null)`.as(
    "has_samples"
  ),
};
