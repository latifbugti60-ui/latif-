export interface StoredSample {
  name: string;
  mime: string;
  data: string; // base64 (no data: prefix)
}

export type CloneResult =
  | { ok: true; voiceId: string; requiresVerification: boolean }
  | { ok: false; status: number; message: string };

function extractErrorMessage(body: unknown, fallback: string): string {
  if (!body || typeof body !== "object") return fallback;
  const detail = (body as { detail?: unknown }).detail;
  if (typeof detail === "string") return detail;
  if (detail && typeof detail === "object" && !Array.isArray(detail)) {
    const msg = (detail as { message?: unknown }).message;
    if (typeof msg === "string") return msg;
  }
  if (Array.isArray(detail) && detail.length > 0) {
    const first = detail[0] as { msg?: unknown };
    if (typeof first?.msg === "string") return first.msg;
  }
  return fallback;
}

/**
 * Real Instant Voice Cloning via ElevenLabs: POST /v1/voices/add (multipart).
 * Returns the new voice_id which can then be used with text-to-speech.
 */
export async function cloneVoiceOnElevenLabs(params: {
  apiKey: string;
  name: string;
  description?: string;
  samples: StoredSample[];
}): Promise<CloneResult> {
  try {
    const form = new FormData();
    form.append("name", params.name.slice(0, 80));
    if (params.description) {
      form.append("description", params.description.slice(0, 480));
    }
    form.append("remove_background_noise", "false");

    for (const sample of params.samples) {
      const bytes = Uint8Array.from(Buffer.from(sample.data, "base64"));
      form.append(
        "files",
        new Blob([bytes], { type: sample.mime || "audio/mpeg" }),
        sample.name || "sample.mp3"
      );
    }

    const res = await fetch("https://api.elevenlabs.io/v1/voices/add", {
      method: "POST",
      headers: { "xi-api-key": params.apiKey },
      body: form,
    });

    const json: unknown = await res.json().catch(() => null);

    if (!res.ok) {
      return {
        ok: false,
        status: res.status,
        message: extractErrorMessage(
          json,
          `ElevenLabs returned HTTP ${res.status}`
        ),
      };
    }

    const voiceId = (json as { voice_id?: unknown } | null)?.voice_id;
    if (typeof voiceId !== "string" || !voiceId) {
      return {
        ok: false,
        status: 502,
        message: "ElevenLabs did not return a voice_id",
      };
    }

    return {
      ok: true,
      voiceId,
      requiresVerification: Boolean(
        (json as { requires_verification?: unknown }).requires_verification
      ),
    };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      message:
        err instanceof Error
          ? `Could not reach ElevenLabs: ${err.message}`
          : "Could not reach ElevenLabs",
    };
  }
}
