export interface SynthesisParams {
  text: string;
  elevenlabsVoiceId: string;
  voiceName?: string;
  gender?: string;
  pitchShift?: number;
  modelId: string;
  stability: number;
  similarityBoost: number;
  styleExaggeration: number;
  speakerBoost: boolean;
  speed?: number;
  apiKey?: string | null;
  /** Skip ElevenLabs entirely (built-in live speech / local pitch-matched profiles). */
  forceLocal?: boolean;
  /** Measured fundamental frequency of the user's own voice sample. */
  baseF0Hz?: number | null;
}

export interface SynthesisResult {
  audioData: string;
  durationMs: number;
  engineUsed: "elevenlabs_live" | "studio_neural";
  errorNote?: string;
}

export interface PlaceholderParams {
  text: string;
  gender?: string;
  pitchShift?: number;
  stability?: number;
  style?: number;
  speed?: number;
  seedOffset?: number;
  baseF0Hz?: number | null;
}

/** Rough spoken duration of a script in ms (≈2.6 words per second at 1x). */
export function estimateSpeechDurationMs(text: string, speed = 1): number {
  const words = (text || "").trim().split(/\s+/).filter(Boolean).length;
  const rate = Math.max(0.5, Math.min(2, speed));
  const seconds = Math.max(1.2, Math.min(300, words / (2.6 * rate) + 0.4));
  return Math.round(seconds * 1000);
}

// 0.1 s of pure silence (16-bit mono, 8 kHz). No tones, no buzz.
function buildSilentWavDataUri(): string {
  const sampleRate = 8000;
  const numSamples = 800;
  const buffer = Buffer.alloc(44 + numSamples * 2); // zero-filled = silence
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + numSamples * 2, 4);
  buffer.write("WAVE", 8);
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write("data", 36);
  buffer.writeUInt32LE(numSamples * 2, 40);
  return `data:audio/wav;base64,${buffer.toString("base64")}`;
}

const SILENT_WAV = buildSilentWavDataUri();

/**
 * Built-in engine placeholder.
 *
 * The built-in engine speaks live through the browser's own speech voice, so there is
 * no audio file to store. This returns a silent stub (never a beep/tone) plus the
 * estimated duration so the UI timeline and history still work.
 */
export function generateSilentPlaceholderWav(params: PlaceholderParams): {
  audioData: string;
  durationMs: number;
} {
  return {
    audioData: SILENT_WAV,
    durationMs: estimateSpeechDurationMs(params.text, params.speed ?? 1),
  };
}

function localResult(params: SynthesisParams, errorNote?: string): SynthesisResult {
  const placeholder = generateSilentPlaceholderWav({
    text: params.text,
    speed: params.speed,
  });
  return {
    ...placeholder,
    engineUsed: "studio_neural",
    errorNote,
  };
}

/**
 * Synthesizes speech with the live ElevenLabs API when a valid key is available.
 * Otherwise returns a silent placeholder and the client speaks the script live
 * with the browser's speech voice (no generated tone).
 */
export async function synthesizeVoiceAudio(
  params: SynthesisParams
): Promise<SynthesisResult> {
  const effectiveApiKey = (
    params.apiKey ||
    process.env.ELEVENLABS_API_KEY ||
    ""
  ).trim();

  if (params.forceLocal || effectiveApiKey.length <= 10) {
    return localResult(params);
  }

  try {
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(
      params.elevenlabsVoiceId
    )}`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "xi-api-key": effectiveApiKey,
        "Content-Type": "application/json",
        Accept: "audio/mpeg",
      },
      body: JSON.stringify({
        text: params.text,
        model_id: params.modelId || "eleven_multilingual_v2",
        voice_settings: {
          stability: params.stability,
          similarity_boost: params.similarityBoost,
          style: params.styleExaggeration,
          use_speaker_boost: params.speakerBoost,
        },
      }),
    });

    if (response.ok) {
      const arrayBuffer = await response.arrayBuffer();
      const base64Audio = Buffer.from(arrayBuffer).toString("base64");
      // Estimate duration from MP3 byte size (~16KB/sec at 128kbps)
      const estimatedDurationMs = Math.max(
        1500,
        Math.round((arrayBuffer.byteLength / 16000) * 1000)
      );
      return {
        audioData: `data:audio/mpeg;base64,${base64Audio}`,
        durationMs: estimatedDurationMs,
        engineUsed: "elevenlabs_live",
      };
    }

    const errText = await response.text().catch(() => "API Error");
    return localResult(
      params,
      `ElevenLabs API returned ${response.status} (${errText.slice(
        0,
        120
      )}). Spoke it with the built-in live voice instead.`
    );
  } catch (err) {
    return localResult(
      params,
      err instanceof Error
        ? `ElevenLabs connection problem: ${err.message}. Spoke it with the built-in live voice instead.`
        : "Spoke it with the built-in live voice."
    );
  }
}
