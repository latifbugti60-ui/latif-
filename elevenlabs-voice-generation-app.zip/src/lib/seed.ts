import { db, pool } from "@/db";
import { users, voices, projects, generations } from "@/db/schema";
import { generateSilentPlaceholderWav } from "@/lib/audio-engine";
import { count } from "drizzle-orm";

let isInitialized = false;

const globalForSeed = globalThis as typeof globalThis & {
  __latifSeedPromise?: Promise<void>;
};

const SEED_LOCK_ID = 84720011;

/**
 * Idempotent, race-proof initialisation. Concurrent requests (several API calls fire
 * together on first page load) share one promise in-process, and a Postgres advisory lock
 * serialises any separate module instances so demo data is never inserted twice.
 */
export function ensureSeeded(): Promise<void> {
  if (isInitialized) return Promise.resolve();
  if (!globalForSeed.__latifSeedPromise) {
    globalForSeed.__latifSeedPromise = runSeedWithLock().finally(() => {
      globalForSeed.__latifSeedPromise = undefined;
    });
  }
  return globalForSeed.__latifSeedPromise;
}

async function runSeedWithLock() {
  const client = await pool.connect();
  try {
    await client.query("SELECT pg_advisory_lock($1)", [SEED_LOCK_ID]);
    await seedInner();
  } finally {
    await client
      .query("SELECT pg_advisory_unlock($1)", [SEED_LOCK_ID])
      .catch(() => {});
    client.release();
  }
}

async function seedInner() {
  if (isInitialized) return;

  try {
    // Ensure tables exist idempotently
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        elevenlabs_api_key TEXT,
        preferred_engine TEXT NOT NULL DEFAULT 'auto',
        character_quota INTEGER NOT NULL DEFAULT 100000,
        characters_used INTEGER NOT NULL DEFAULT 14820,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS voices (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        elevenlabs_voice_id TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'cloned',
        accent TEXT NOT NULL DEFAULT 'American',
        gender TEXT NOT NULL DEFAULT 'Neutral',
        age TEXT NOT NULL DEFAULT 'Young',
        description TEXT NOT NULL,
        use_case TEXT NOT NULL DEFAULT 'Personal Voice Clone',
        preview_audio_url TEXT NOT NULL,
        default_stability REAL NOT NULL DEFAULT 0.5,
        default_similarity REAL NOT NULL DEFAULT 0.75,
        default_style REAL NOT NULL DEFAULT 0.15,
        speaker_boost BOOLEAN NOT NULL DEFAULT TRUE,
        pitch_shift REAL NOT NULL DEFAULT 1.0,
        is_favorite BOOLEAN NOT NULL DEFAULT FALSE,
        sample_count INTEGER NOT NULL DEFAULT 3,
        quality_score INTEGER NOT NULL DEFAULT 98,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS projects (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Audiobook',
        status TEXT NOT NULL DEFAULT 'active',
        target_language TEXT NOT NULL DEFAULT 'English & Urdu',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS generations (
        id SERIAL PRIMARY KEY,
        voice_id INTEGER NOT NULL REFERENCES voices(id) ON DELETE CASCADE,
        project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
        title TEXT NOT NULL DEFAULT 'Studio Take',
        prompt_text TEXT NOT NULL,
        model_id TEXT NOT NULL DEFAULT 'eleven_multilingual_v2',
        stability REAL NOT NULL DEFAULT 0.5,
        similarity_boost REAL NOT NULL DEFAULT 0.75,
        style_exaggeration REAL NOT NULL DEFAULT 0.15,
        speaker_boost BOOLEAN NOT NULL DEFAULT TRUE,
        speed REAL NOT NULL DEFAULT 1.0,
        audio_data TEXT NOT NULL,
        duration_ms INTEGER NOT NULL DEFAULT 4200,
        character_count INTEGER NOT NULL DEFAULT 0,
        engine_used TEXT NOT NULL DEFAULT 'studio_neural',
        is_favorite BOOLEAN NOT NULL DEFAULT FALSE,
        notes TEXT NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_data TEXT;
      ALTER TABLE voices ADD COLUMN IF NOT EXISTS clone_status TEXT NOT NULL DEFAULT 'none';
      ALTER TABLE voices ADD COLUMN IF NOT EXISTS measured_pitch_hz REAL;
      ALTER TABLE voices ADD COLUMN IF NOT EXISTS sample_files TEXT;
    `);

    const existingUsers = await db.select({ value: count() }).from(users);
    if ((existingUsers[0]?.value ?? 0) === 0) {
      await db.insert(users).values({
        email: "latifbugti@latifai.studio",
        name: "Latif Bugti (Latif AI Studio)",
        passwordHash: "demo_studio_hash_2026",
        elevenlabsApiKey: process.env.ELEVENLABS_API_KEY || null,
        preferredEngine: "auto",
        characterQuota: 100000,
        charactersUsed: 18450,
      });
    } else {
      await pool.query(`
        UPDATE users
        SET name = 'Latif Bugti (Latif AI Studio)',
            email = 'latifbugti@latifai.studio'
        WHERE id = 1;
      `);
    }

    const existingVoices = await db.select({ value: count() }).from(voices);
    if ((existingVoices[0]?.value ?? 0) === 0) {
      const v1Audio = generateSilentPlaceholderWav({
        text: "Assalam-o-Alaikum, main Latif Bugti hoon. This is my personal Latif AI voice clone calibrated for red and black neural studio narration.",
        gender: "Male",
        pitchShift: 0.98,
        stability: 0.55,
        style: 0.2,
      });
      const v2Audio = generateSilentPlaceholderWav({
        text: "Hello, I am Rachel. Every story deserves a clear, warm, and resonant voice.",
        gender: "Female",
        pitchShift: 1.05,
        stability: 0.65,
        style: 0.15,
      });
      const v3Audio = generateSilentPlaceholderWav({
        text: "Hey everyone! Welcome back to Latif Bugti AI studio for another bilingual storytelling session.",
        gender: "Female",
        pitchShift: 1.12,
        stability: 0.45,
        style: 0.35,
      });
      const v4Audio = generateSilentPlaceholderWav({
        text: "Across the vast silence of deep space, only a single frequency remained active.",
        gender: "Male",
        pitchShift: 0.85,
        stability: 0.72,
        style: 0.1,
      });
      const v5Audio = generateSilentPlaceholderWav({
        text: "Hi there! I am Elena, your low-latency conversational voice assistant powered by Latif Bugti AI.",
        gender: "Female",
        pitchShift: 1.02,
        stability: 0.6,
        style: 0.2,
      });
      const v6Audio = generateSilentPlaceholderWav({
        text: "Raat ke is sannate mein, aaiye Latif Bugti AI ke sath ek nayi kahani ka aaghaz karte hain.",
        gender: "Male",
        pitchShift: 0.92,
        stability: 0.5,
        style: 0.25,
      });

      const insertedVoices = await db
        .insert(voices)
        .values([
          {
            name: "Latif Bugti — Personal Voice Clone",
            elevenlabsVoiceId: "pNInz6obpgDQGcFmaJgB",
            category: "cloned",
            accent: "Urdu / International English",
            gender: "Male",
            age: "Young",
            description:
              "Demo placeholder using a stock ElevenLabs voice ID. Open Voice Lab → New Voice Clone and upload or record your own voice sample to create your real cloned voice.",
            useCase: "Personal Voice Clone",
            previewAudioUrl: v1Audio.audioData,
            defaultStability: 0.52,
            defaultSimilarity: 0.86,
            defaultStyle: 0.22,
            speakerBoost: true,
            pitchShift: 0.98,
            isFavorite: true,
            sampleCount: 5,
            qualityScore: 99,
          },
          {
            name: "Rachel — Studio Narrator",
            elevenlabsVoiceId: "21m00Tcm4TlvDq8ikWAM",
            category: "premade",
            accent: "American",
            gender: "Female",
            age: "Young",
            description:
              "Velvet-toned American studio narrator crafted for long-form audiobooks, cinema essays, and crisp product explainers.",
            useCase: "Narration & Audiobooks",
            previewAudioUrl: v2Audio.audioData,
            defaultStability: 0.65,
            defaultSimilarity: 0.8,
            defaultStyle: 0.12,
            speakerBoost: true,
            pitchShift: 1.05,
            isFavorite: true,
            sampleCount: 8,
            qualityScore: 98,
          },
          {
            name: "Zoya — Latif AI Bilingual",
            elevenlabsVoiceId: "EXAVITQu4vr4xnSDxMaL",
            category: "cloned",
            accent: "South Asian / British",
            gender: "Female",
            age: "Young",
            description:
              "High-retention expressive personal clone tailored for YouTube Shorts, Reels, and bilingual English-Urdu commentary.",
            useCase: "YouTube & Reels",
            previewAudioUrl: v3Audio.audioData,
            defaultStability: 0.44,
            defaultSimilarity: 0.84,
            defaultStyle: 0.34,
            speakerBoost: true,
            pitchShift: 1.12,
            isFavorite: true,
            sampleCount: 4,
            qualityScore: 97,
          },
          {
            name: "Marcus — Deep Documentary",
            elevenlabsVoiceId: "onwK4e9ZLuTAKqWW03F9",
            category: "premade",
            accent: "British",
            gender: "Male",
            age: "Mature",
            description:
              "Resonant British baritone with rich low-end proximity effect, subtle breath pacing, and cinematic authority.",
            useCase: "Documentary & Trailers",
            previewAudioUrl: v4Audio.audioData,
            defaultStability: 0.72,
            defaultSimilarity: 0.78,
            defaultStyle: 0.1,
            speakerBoost: true,
            pitchShift: 0.85,
            isFavorite: false,
            sampleCount: 6,
            qualityScore: 99,
          },
          {
            name: "Elena — Conversational AI",
            elevenlabsVoiceId: "XrExE9yKIg1WjnnlVkGX",
            category: "designed",
            accent: "American",
            gender: "Female",
            age: "Middle-Aged",
            description:
              "Ultra-low latency voice design optimized for real-time AI agents, interactive SaaS walkthroughs, and voice bots.",
            useCase: "Conversational AI",
            previewAudioUrl: v5Audio.audioData,
            defaultStability: 0.6,
            defaultSimilarity: 0.75,
            defaultStyle: 0.18,
            speakerBoost: true,
            pitchShift: 1.02,
            isFavorite: false,
            sampleCount: 3,
            qualityScore: 96,
          },
          {
            name: "Kabir — Late Night Podcast",
            elevenlabsVoiceId: "ErXwobaYiN019PkySvjV",
            category: "cloned",
            accent: "Urdu / South Asian",
            gender: "Male",
            age: "Middle-Aged",
            description:
              "Intimate close-mic Shure SM7B clone with warm mid-bass presence for storytelling, poetry, and founder podcasts.",
            useCase: "Podcast Host",
            previewAudioUrl: v6Audio.audioData,
            defaultStability: 0.5,
            defaultSimilarity: 0.82,
            defaultStyle: 0.25,
            speakerBoost: true,
            pitchShift: 0.92,
            isFavorite: false,
            sampleCount: 5,
            qualityScore: 98,
          },
        ])
        .returning();

      const insertedProjects = await db
        .insert(projects)
        .values([
          {
            title: "Latif Bugti — YouTube Automation & Tech Reviews",
            description:
              "Bilingual voiceovers (English & Roman Urdu) using Latif Bugti personal voice clone for weekly AI & software engineering deep-dives.",
            category: "YouTube Automation",
            status: "active",
            targetLanguage: "English & Urdu",
          },
          {
            title: "The Midnight Architect — Audiobook Master",
            description:
              "12-chapter sci-fi thriller audiobook narration with multi-character acoustic profiles and chapter markers.",
            category: "Audiobook",
            status: "active",
            targetLanguage: "English (US/UK)",
          },
          {
            title: "Latif AI SaaS Launch Spots",
            description:
              "High-impact 30-second broadcast and social ad reads calibrated with Speaker Boost and high similarity.",
            category: "Commercial",
            status: "active",
            targetLanguage: "Multilingual v2",
          },
          {
            title: "Founder's Late Night Audio Journal",
            description:
              "Intimate weekly reflections on product design, voice AI, and creative engineering in Urdu and English.",
            category: "Podcast",
            status: "completed",
            targetLanguage: "Urdu & English",
          },
        ])
        .returning();

      const latifVoice = insertedVoices[0];
      const rachelVoice = insertedVoices[1] || insertedVoices[0];
      const zoyaVoice = insertedVoices[2] || insertedVoices[0];
      const marcusVoice = insertedVoices[3] || insertedVoices[0];
      const elenaVoice = insertedVoices[4] || insertedVoices[0];

      const pYoutube = insertedProjects[0];
      const pAudiobook = insertedProjects[1] || insertedProjects[0];
      const pCommercial = insertedProjects[2] || insertedProjects[0];
      const pPodcast = insertedProjects[3] || insertedProjects[0];

      const g1Text =
        "Assalam-o-Alaikum! Main Latif Bugti hoon. Is Latif AI Red & Black Neural Studio app se 100% real voice generate hoti hai. Aap apni personal ElevenLabs API key lagakar live neural MP3 generate kar sakte hain, aur bina API key ke bhi Latif AI Real Speech Engine aapke har sentence ko asali bolti hui aawaz mein sunata hai!";
      const g2Text =
        "Welcome back to Latif Bugti Personal Voice Studio! Today we're testing my custom red and black neural voice clone with ElevenLabs Multilingual v2. Notice how adjusting Stability to 52% and Similarity Boost to 86% keeps every natural breath and inflection intact.";
      const g3Text =
        "The rain against the glass of the high-altitude observatory wasn't merely weather; it was a relentless metronome counting down the final hours before the first transmission arrived from Kepler-442b.";
      const g4Text =
        "Assalam-o-Alaikum dosto! Aaj ki is video mein hum dekhenge ke kis tarah aap Latif Bugti AI mein apni khud ki aawaz ko clone kar ke YouTube aur Reels ke liye professional studio-grade voiceovers chand seconds mein tayyar kar sakte hain.";
      const g5Text =
        "In a world flooded with synthetic noise, authentic acoustic presence sets your story apart. Master your personal voice with Latif Bugti AI sub-second latency and precision formant control.";
      const g6Text =
        "Hello! I'm Elena on the Latif Bugti AI neural engine. Your microphone calibration looks great—signal-to-noise ratio is at 68 decibels with zero clipping. Ready to synthesize your next script whenever you are.";

      const g1Wav = generateSilentPlaceholderWav({
        text: g1Text,
        gender: "Male",
        pitchShift: 0.98,
        stability: 0.52,
        style: 0.22,
      });
      const g2Wav = generateSilentPlaceholderWav({
        text: g2Text,
        gender: "Male",
        pitchShift: 0.98,
        stability: 0.55,
        style: 0.2,
      });
      const g3Wav = generateSilentPlaceholderWav({
        text: g3Text,
        gender: "Female",
        pitchShift: 1.05,
        stability: 0.65,
        style: 0.12,
      });
      const g4Wav = generateSilentPlaceholderWav({
        text: g4Text,
        gender: "Female",
        pitchShift: 1.12,
        stability: 0.44,
        style: 0.34,
      });
      const g5Wav = generateSilentPlaceholderWav({
        text: g5Text,
        gender: "Male",
        pitchShift: 0.85,
        stability: 0.72,
        style: 0.1,
      });
      const g6Wav = generateSilentPlaceholderWav({
        text: g6Text,
        gender: "Female",
        pitchShift: 1.02,
        stability: 0.6,
        style: 0.18,
      });

      await db.insert(generations).values([
        {
          voiceId: latifVoice.id,
          projectId: pYoutube.id,
          title: "Latif Bugti — Real Voice Confirmation (Roman Urdu + English)",
          promptText: g1Text,
          modelId: "eleven_multilingual_v2",
          stability: 0.52,
          similarityBoost: 0.86,
          styleExaggeration: 0.22,
          speakerBoost: true,
          speed: 1.0,
          audioData: g1Wav.audioData,
          durationMs: g1Wav.durationMs,
          characterCount: g1Text.length,
          engineUsed: "studio_neural",
          isFavorite: true,
          notes: "Latif Bugti confirmation in Roman Urdu & English.",
        },
        {
          voiceId: latifVoice.id,
          projectId: pYoutube.id,
          title: "Latif Bugti Tech Review Intro — Personal Clone Take 1",
          promptText: g2Text,
          modelId: "eleven_multilingual_v2",
          stability: 0.55,
          similarityBoost: 0.86,
          styleExaggeration: 0.2,
          speakerBoost: true,
          speed: 1.0,
          audioData: g2Wav.audioData,
          durationMs: g2Wav.durationMs,
          characterCount: g2Text.length,
          engineUsed: "studio_neural",
          isFavorite: true,
          notes: "Locked intro take for Friday upload.",
        },
        {
          voiceId: rachelVoice.id,
          projectId: pAudiobook.id,
          title: "Chapter 1 Opening — Kepler Observatory",
          promptText: g3Text,
          modelId: "eleven_multilingual_v2",
          stability: 0.65,
          similarityBoost: 0.8,
          styleExaggeration: 0.12,
          speakerBoost: true,
          speed: 0.96,
          audioData: g3Wav.audioData,
          durationMs: g3Wav.durationMs,
          characterCount: g3Text.length,
          engineUsed: "studio_neural",
          isFavorite: true,
          notes: "Warm pacing with slight slowdown.",
        },
        {
          voiceId: zoyaVoice.id,
          projectId: pPodcast.id,
          title: "Latif AI Bilingual Episode Hook (Urdu)",
          promptText: g4Text,
          modelId: "eleven_multilingual_v2",
          stability: 0.44,
          similarityBoost: 0.84,
          styleExaggeration: 0.34,
          speakerBoost: true,
          speed: 1.04,
          audioData: g4Wav.audioData,
          durationMs: g4Wav.durationMs,
          characterCount: g4Text.length,
          engineUsed: "studio_neural",
          isFavorite: false,
          notes: "High energy reel hook.",
        },
        {
          voiceId: marcusVoice.id,
          projectId: pCommercial.id,
          title: "Trailer Voiceover — Deep Baritone Master",
          promptText: g5Text,
          modelId: "eleven_turbo_v2_5",
          stability: 0.72,
          similarityBoost: 0.78,
          styleExaggeration: 0.1,
          speakerBoost: true,
          speed: 0.94,
          audioData: g5Wav.audioData,
          durationMs: g5Wav.durationMs,
          characterCount: g5Text.length,
          engineUsed: "studio_neural",
          isFavorite: false,
          notes: "Broadcast trailer cut.",
        },
        {
          voiceId: elenaVoice.id,
          projectId: pCommercial.id,
          title: "Interactive Onboarding Assistant Greeting",
          promptText: g6Text,
          modelId: "eleven_flash_v2_5",
          stability: 0.6,
          similarityBoost: 0.75,
          styleExaggeration: 0.18,
          speakerBoost: true,
          speed: 1.0,
          audioData: g6Wav.audioData,
          durationMs: g6Wav.durationMs,
          characterCount: g6Text.length,
          engineUsed: "studio_neural",
          isFavorite: false,
          notes: "Sub-75ms flash model test.",
        },
      ]);
    } else {
      await pool.query(`
        UPDATE voices
        SET name = 'Latif Bugti — Personal Voice Clone',
            description = 'Demo placeholder using a stock ElevenLabs voice ID. Open Voice Lab → New Voice Clone and upload or record your own voice sample to create your real cloned voice.'
        WHERE (id = 1 OR name LIKE 'Latif AI%' OR name LIKE 'Ayan%') AND clone_status = 'none';
      `);
    }

    isInitialized = true;
  } catch (error) {
    console.error("Database initialization/seed warning:", error);
  }
}
