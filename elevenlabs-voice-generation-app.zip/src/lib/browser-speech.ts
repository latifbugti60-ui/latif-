"use client";

export interface BrowserSpeakOptions {
  text: string;
  gender?: string;
  pitchShift?: number;
  speed?: number;
  volume?: number;
  onStart?: () => void;
  onEnd?: () => void;
  /** Fires on each word with the character index inside `text`. */
  onBoundary?: (charIndex: number) => void;
}

export function isBrowserSpeechSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function stopBrowserSpeech() {
  if (isBrowserSpeechSupported()) {
    window.speechSynthesis.cancel();
  }
}

export function speakWithBrowserNeural(options: BrowserSpeakOptions): boolean {
  if (!isBrowserSpeechSupported()) {
    return false;
  }

  try {
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(options.text);
    const voices = window.speechSynthesis.getVoices();

    const genderLower = (options.gender || "neutral").toLowerCase();
    const isUrduOrHindi =
      /\b(haan|nahi|aap|mein|hai|hain|kar|sakte|aawaz|dosto|kya|kiya|bilkul)\b/i.test(
        options.text
      );

    // Pick best matching system voice
    let chosenVoice = voices.find((v) => {
      if (
        isUrduOrHindi &&
        (v.lang.includes("hi") || v.lang.includes("ur") || v.lang.includes("en-IN"))
      ) {
        return true;
      }
      return false;
    });

    if (!chosenVoice && voices.length > 0) {
      if (genderLower === "female") {
        chosenVoice =
          voices.find((v) =>
            /samantha|victoria|zira|google us english|aria|jenny|female|natural/i.test(
              v.name
            )
          ) || voices.find((v) => v.lang.startsWith("en"));
      } else if (genderLower === "male") {
        chosenVoice =
          voices.find((v) =>
            /daniel|alex|david|guy|christopher|google uk english male|male/i.test(
              v.name
            )
          ) || voices.find((v) => v.lang.startsWith("en"));
      } else {
        chosenVoice = voices.find((v) => v.lang.startsWith("en")) || voices[0];
      }
    }

    if (chosenVoice) {
      utterance.voice = chosenVoice;
    }

    const basePitch =
      genderLower === "female" ? 1.12 : genderLower === "male" ? 0.9 : 1.0;
    utterance.pitch = Math.max(
      0.5,
      Math.min(1.8, basePitch * (options.pitchShift ?? 1.0))
    );
    utterance.rate = Math.max(0.65, Math.min(1.5, options.speed ?? 1.0));
    utterance.volume = Math.max(0, Math.min(1, options.volume ?? 1));

    if (options.onStart) utterance.onstart = options.onStart;
    if (options.onBoundary) {
      const onBoundary = options.onBoundary;
      utterance.onboundary = (e) => onBoundary(e.charIndex);
    }
    if (options.onEnd) {
      utterance.onend = options.onEnd;
      utterance.onerror = options.onEnd;
    }

    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    return false;
  }
}
