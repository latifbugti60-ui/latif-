"use client";

export interface SampleAnalysis {
  durationSec: number;
  pitchHz: number | null;
  voicedRatio: number;
}

function getAudioContext(): AudioContext {
  const Ctor =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  return new Ctor();
}

/**
 * Decodes an audio blob and estimates the speaker's average fundamental frequency (F0)
 * using normalized autocorrelation on voiced frames. Runs fully in the browser.
 */
export async function analyzeVoiceSample(blob: Blob): Promise<SampleAnalysis> {
  const ctx = getAudioContext();
  try {
    const audio = await ctx.decodeAudioData(await blob.arrayBuffer());
    const raw = audio.getChannelData(0);
    const maxSamples = Math.min(raw.length, Math.floor(audio.sampleRate * 40));

    // Downsample (box filter) to ~11 kHz so autocorrelation stays cheap.
    const factor = Math.max(1, Math.round(audio.sampleRate / 11025));
    const sr = audio.sampleRate / factor;
    const n = Math.floor(maxSamples / factor);
    const x = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      let sum = 0;
      for (let j = 0; j < factor; j++) sum += raw[i * factor + j];
      x[i] = sum / factor;
    }

    const frame = Math.floor(sr * 0.05);
    const hop = Math.floor(sr * 0.025);
    const minLag = Math.floor(sr / 400);
    const maxLag = Math.min(Math.floor(sr / 70), Math.floor(frame * 0.6));
    const win = frame - maxLag;

    if (n < frame * 3 || win < 32) {
      return { durationSec: audio.duration, pitchHz: null, voicedRatio: 0 };
    }

    // Frame energies
    const starts: number[] = [];
    const rms: number[] = [];
    for (let s = 0; s + frame <= n; s += hop) {
      let e = 0;
      for (let i = 0; i < frame; i++) e += x[s + i] * x[s + i];
      starts.push(s);
      rms.push(Math.sqrt(e / frame));
    }
    const sorted = [...rms].sort((a, b) => a - b);
    const loud = sorted[Math.floor(sorted.length * 0.95)] || 0;
    const threshold = Math.max(0.004, loud * 0.3);

    const f0s: number[] = [];
    let considered = 0;
    for (let f = 0; f < starts.length; f++) {
      if (rms[f] < threshold) continue;
      considered++;
      const s = starts[f];

      let e0 = 0;
      for (let i = 0; i < win; i++) e0 += x[s + i] * x[s + i];
      if (e0 <= 0) continue;

      const r = new Float32Array(maxLag + 2);
      let bestR = 0;
      for (let lag = minLag; lag <= maxLag; lag++) {
        let c = 0;
        let e1 = 0;
        for (let i = 0; i < win; i++) {
          c += x[s + i] * x[s + i + lag];
          e1 += x[s + i + lag] * x[s + i + lag];
        }
        const norm = c / Math.sqrt(e0 * e1 + 1e-12);
        r[lag] = norm;
        if (norm > bestR) bestR = norm;
      }
      if (bestR < 0.6) continue;

      // Prefer the first strong local peak (avoids octave-down errors).
      let chosen = -1;
      for (let lag = minLag + 1; lag < maxLag; lag++) {
        if (r[lag] >= bestR * 0.9 && r[lag] >= r[lag - 1] && r[lag] >= r[lag + 1]) {
          chosen = lag;
          break;
        }
      }
      if (chosen > 0) f0s.push(sr / chosen);
    }

    if (f0s.length < 5) {
      return { durationSec: audio.duration, pitchHz: null, voicedRatio: 0 };
    }
    f0s.sort((a, b) => a - b);
    const median = f0s[Math.floor(f0s.length / 2)];
    return {
      durationSec: audio.duration,
      pitchHz: Math.round(median),
      voicedRatio: considered ? f0s.length / considered : 0,
    };
  } finally {
    void ctx.close().catch(() => {});
  }
}

/** Maps a measured pitch to the gender + pitch-shift values used by the studio engine. */
export function pitchToVoiceProfile(hz: number): {
  gender: "Male" | "Female";
  pitchShift: number;
} {
  const gender = hz >= 165 ? "Female" : "Male";
  const base = gender === "Female" ? 205 : 118;
  const pitchShift = Math.max(0.6, Math.min(1.5, Math.round((hz / base) * 100) / 100));
  return { gender, pitchShift };
}

/** Re-encodes any decodable audio blob as a 16-bit mono WAV file (max 44.1 kHz). */
export async function convertBlobToWavFile(
  blob: Blob,
  fileName: string
): Promise<File> {
  const ctx = getAudioContext();
  try {
    const audio = await ctx.decodeAudioData(await blob.arrayBuffer());
    const length = audio.length;
    const channels = audio.numberOfChannels;
    const mono = new Float32Array(length);
    for (let c = 0; c < channels; c++) {
      const data = audio.getChannelData(c);
      for (let i = 0; i < length; i++) mono[i] += data[i] / channels;
    }

    const sampleRate = audio.sampleRate;
    const buffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(buffer);
    const writeStr = (offset: number, text: string) => {
      for (let i = 0; i < text.length; i++) {
        view.setUint8(offset + i, text.charCodeAt(i));
      }
    };
    writeStr(0, "RIFF");
    view.setUint32(4, 36 + length * 2, true);
    writeStr(8, "WAVE");
    writeStr(12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(36, "data");
    view.setUint32(40, length * 2, true);
    for (let i = 0; i < length; i++) {
      const s = Math.max(-1, Math.min(1, mono[i]));
      view.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return new File([buffer], fileName, { type: "audio/wav" });
  } finally {
    void ctx.close().catch(() => {});
  }
}
